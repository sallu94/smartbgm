<div class="container col-md-4">
    <ul class="list-group">
        <li class="list-group-item list-group-item-success">
            Quick Links
        </li>
        <li class="list-group-item list-group-item-text">
            <a href="homepage.php"><span class="glyphicon glyphicon-home"></span> Go Home</a>
        </li>
        <li class="list-group-item list-group-item-text">
            <a href="change_credentials.php"><span class="glyphicon glyphicon-lock"></span> Change Credentials</a>
        </li>
    </ul>
    <ul class="list-group">
        <li class="list-group-item">
            <div>
                <form class="form-inline" action="?search" method="get">
                    <input type="search" name="query" placeholder="Search" class="form-control"/>
                    <input type="submit" name="search" value="Search" class="btn btn-success"/>
                </form>

                <?php
                if (isset($_GET['search'])){
                include_once "../includes/database_function.php";
                connect();

                $search_qr = $_GET['query'];

                $rs = getTableData("problem WHERE description LIKE '%$search_qr%'");
                while ($search_result = mysql_fetch_array($rs)){ ?>
                <br/>
                <a href="update_status.php?id=<?php echo $search_result['id']; ?>"><?php echo $search_result['title'];
                    }

                    }
                    ?>
            </div>
        </li>
    </ul>
    <ul class="list-group">
        <li class="list-group-item">

                <iframe frameborder="0"
                        src="http://ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=ss_til&ad_type=product_link&tracking_id=httpsfaceb065-21&marketplace=amazon&region=IN&placement=B00QAHAZYI&asins=B00QAHAZYI&linkId=&show_border=true&link_opens_in_new_window=true"
                        title="Advertisement goes here">
                </iframe>
                <iframe  frameborder="0"
                        src="http://ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=ss_til&ad_type=product_link&tracking_id=httpsfaceb065-21&marketplace=amazon&region=IN&placement=B00ZFDD3YM&asins=B00ZFDD3YM&linkId=&show_border=true&link_opens_in_new_window=true&price_color=3A9B11&title_color=9B0C49&bg_color=FFFFFF">
                </iframe>

        </li>
    </ul>
</div>
