<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <div class="container">
        <div class="container col-md-8 text-center">
            <center>
                <form action="" method="post">
                    <ul class="list-group text-left">

                        <?php

                        include_once "../includes/database_function.php";
                        connect();

                        $id = $_GET['id'];
                        $_SESSION['problem_id'] = $id;

                        $rs = getTableData("problem WHERE id='$id'");
                        $data = mysql_fetch_array($rs);

                        ?>
                        <li class="list-group-item list-group-item-success"><?php echo $data['title']; ?></li>
                        <li class="list-group-item">
                            <img src="<?php echo '../users/' . $data['img_path']; ?>"
                                 class="img-responsive img-circle"/>
                        </li>
                        <li class="list-group-item">Description - <?php echo $data['description']; ?></li>
                        <li class="list-group-item">Area - <?php echo $data['area']; ?></li>
                        <li class="list-group-item">User - <?php echo $data['user']; ?></li>
                        <li class="list-group-item">Status -
                            <span class="bg-primary"><?php echo $data['status']; ?></span></li>
                        <li class="list-group-item">
                            <div class="progress">
                                <div class="progress-bar progress-bar-info" role="progressbar"
                                     aria-valuemin="0" aria-valuemax="100"
                                     style="width:<?php echo $data['progress'] . '%'; ?>">
                                    <?php echo $data['progress'] . '%'; ?>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <select name="status" class="form-control" required>
                                <option value="">Update Status</option>
                                <option value="pending">Pending</option>
                                <option value="approved">Approved</option>
                                <option value="Work In Progress">Work In Progress</option>
                                <option value="completed">Completed</option>
                                <option value="rejected">Rejected</option>
                            </select>
                        </li>

                        <li class="list-group-item">
                            <select name="progress" class="form-control" required>
                                <option value="">Update Progress</option>
                                <option value="0">0%</option>
                                <option value="10">10%</option>
                                <option value="20">20%</option>
                                <option value="30">30%</option>
                                <option value="40">40%</option>
                                <option value="50">50%</option>
                                <option value="60">60%</option>
                                <option value="70">70%</option>
                                <option value="80">80%</option>
                                <option value="90">90%</option>
                                <option value="100">100%</option>
                            </select>
                        </li>
                        <li class="list-group-item">
                            <input type="submit" name="update_status" value="Update" class="btn btn-primary"/>
                        </li>
                    </ul>
                    </table>
                </form>
                <?php
                if (isset($_POST['update_status'])) {
                    $problem_id = $_SESSION['problem_id'];
                    $status = $_POST['status'];
                    $progress = $_POST['progress'];

                    include_once "../includes/database_function.php";
                    connect();

                    $q = "UPDATE problem SET status = '$status', progress = '$progress' WHERE id='$problem_id';";
                    mysql_query($q) or die(mysql_error());
                    //showAlert("Smart Belagavi", "Status Updated successfully", "Okay");
                }
                ?>
            </center>
        </div>
    </div>

    <!-- Footer -->
    <?php include_once("leader_footer.php"); ?>
</body>
</html>