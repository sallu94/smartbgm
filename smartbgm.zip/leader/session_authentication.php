<?php
session_start();
   if(!isset( $_SESSION['leader'] ) )
   {
      echo '<script>window.location="./index.php";</script>';
   }
?>