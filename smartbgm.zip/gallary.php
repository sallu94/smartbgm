<!DOCTYPE HTML>
<html>
<head>
    <title>My Wedding a Wedding Category Flat Bootstrap Responsive Website Template | Wedding :: w3layouts</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="My Wedding Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <script src="js/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/bootstrap.js"></script>
    <link rel="stylesheet" href="css/swipebox.css">
    <script src="js/jquery.swipebox.min.js"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            $(".swipebox").swipebox();
        });
    </script>


</head>
<body>
<!--header-->
<div class="">
    <div class="container">
        <div class="header-top">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand">
                            <h1><a href="index.php">Smart Belagavi</a></h1>
                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">
                            <li><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="wedding.php">Gallary</a></li>
                            <li><a href="typo.php">Services</a></li>
                            <li><a href="contact.php">Contact</a></li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                   aria-haspopup="true" aria-expanded="false">Log in <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <li><a href="admin/index.php">Admin</a></li>
                                    <li><a href="leader/index.php">Leader</a></li>
                                    <li><a href="login.php">Member</a></li>
                                </ul>
                            </li>
                        </ul>

                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-fluid -->
            </nav>
        </div>

        <!-- FlexSlider -->
    </div>

</div>
<br/>
<!--header-->
<div class="content">
    <!--wedding-->
    <div class="wedding-section">
        <div class="container">
            <h2>Smart Belagavi Gallary</h2>

            <div class="gallery-grids">
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g1.jpg"><img src="images/g1.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>

                    </div>
                </div>
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g2.jpg"><img src="images/g2.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g3.jpg"><img src="images/g3.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="gallery-grids">
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g4.jpg"><img src="images/g4.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g5.jpg"><img src="images/g5.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g6.jpg"><img src="images/g6.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="gallery-grids">
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g7.jpg"><img src="images/g7.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g8.jpg"><img src="images/g8.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="col-md-4 gallery-grid">
                    <div class="gallery-grd">
                        <a class="swipebox" href="images/g9.jpg"><img src="images/g9.jpg" class="img-style row6" alt=""><span
                                class="zoom-icon"></span></a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>

</div>


<div class="indicate">
    <div class="container">
        <div class="indicate-grids">
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Belagavi, Karnataka India</p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>Telephone : +91 831 321 654
                </p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Email : <a
                        href=""> info@smartBelagavi.com</a></p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-send" aria-hidden="true"></span>FAX : +91 831 123 456</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer-section">
    <div class="container">
        <div class="footer-top">
            <p> &copy; 2016 Smart Belagavi . All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                    href="http://jainbgm.in"> JCE</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>