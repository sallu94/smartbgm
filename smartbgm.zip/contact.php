<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Public Forum</title>

    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<!-- Navigation -->
<?php include_once "navbar.php"; ?>
<div class="">
    <div class="container">


        <!-- FlexSlider -->
    </div>

</div>

<!-- end of Navigation -->

<div class="OurLove-section">
    <div class="container">
        <h2>Why not contact us ?</h2>

        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <h3 class="text-primary">Your feedback</h3><hr />
                <form method="" action="">
                    <input type="text" class="form-control" placeholder="Your E-mail" required="required"><br/>
                    <textarea name="message" id="" cols="30" rows="10" class="form-control"
                              placeholder="Type your message here..."></textarea><br />
                    <input type="submit" value="Submit" class="btn btn-primary" />
                </form>
            </div>
            <div class="col-md-7 OurLove-grid1">
                <span class="label label-primary">Find Us on Map</span>
                <br/>
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d30702.795876617496!2d74.50012379812715!3d15.864506224176605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1smedical+stores+nearby+Belagavi!5e0!3m2!1sen!2sin!4v1460194543384"
                    width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>

<div class="indicate">
    <div class="container">
        <div class="indicate-grids">
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Belagavi, Karnataka India</p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>Telephone : +91 831 321 654
                </p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Email : <a
                        href=""> info@smartBelagavi.com</a></p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-send" aria-hidden="true"></span>FAX : +91 831 123 456</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer-section">
    <div class="container">
        <div class="footer-top">
            <p> &copy; 2016 Smart Belagavi . All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                    href="http://jainbgm.in"> JCE</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>