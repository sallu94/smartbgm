<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart Belagavi</title>

    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>


    <link href="css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<!-- Navigation -->
<div class="">
    <div class="container">
        <div class="header-top">
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                                data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <div class="navbar-brand">
                            <h1><a href="index.php">Smart Belagavi</a></h1>
                        </div>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="explore.php">Explore Bgm</a></li>					
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="social.php">Social Media</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                           aria-haspopup="true" aria-expanded="false">Log in <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="admin/index.php">Admin</a></li>
                            <li><a href="leader/index.php">Leader</a></li>
                            <li><a href="login.php">Member</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-fluid -->
            </nav>
        </div>

        <!-- FlexSlider -->
    </div>

</div>
<!-- end of Navigation -->

<div class="Belagavi-section">
    <div class="container">
        <h2>Explore the beautiful places of Belagavi</h2>
        <div class="Smart Belagavi-grids">
            <div class="col-md-50 Smart Belagavi-grid">
                <div class="panel panel-default">

                </div>

                <div class="col-md-50 Smart Belagavi-grid1">
                    <div class="panel panel-default">
                        <div class="panel-heading">Explore the Smart Belagavi</div>
                        <div class="panel-body">
                            <img src="images/g5.jpg" class=""/>
                            <span class="text-success h4"><br /><br />Some Interesting Facts about Belagavi</span> <br/>
                            Belgaum, officially known as Belagavi (earlier known "Venugrama" or the "Bamboo Village") is a city in the Indian state of Karnataka. It is the administrative headquarters of the eponymous Belgaum division and Belgaum district. The Government of Karnataka has proposed making Belgaum the second capital of Karnataka, hence a second state administrative building Suvarna Vidhana Soudha was inaugurated on 11 October 2012.

                            Belgaum has been selected in first phase out of 20 cities, as one of the hundred Indian cities to be developed as a smart city under PM Narendra Modi's flagship Smart Cities Mission.<br /> <a href="https://en.wikipedia.org/wiki/Belgaum">read more...</a>
                        </div>
                        <div class="panel-body">
                            <span class="text-success h4"><br />Things to do in Belagavi</span> <br/>
                            Evidences of Belgaum�s rich historical past will spoil you for choices. The list of Belgaum�s things to do features a lot of sightseeing. Belgaum can also be termed as a temple town. Religious travellers and history buffs can visit the old stone fort in Belgaum that has beautiful shrines, Safa Masjid, Jain temple and an old settlement�Kamala Basti�within the fort. Check out the colonial architecture by visiting various churches in the Cantonment area or enjoy visiting well-maintained parks of the town. Shop for amazing handmade wooden toys, pottery or leather goods and try some authentic biryani and sweet Kunda dish in Belagavi.<br /> <a href="http://journeymart.com/de/india/karnataka/belgaum-things-to-do.aspx">read more...</a>
                        </div>
						 <img src="images/img3.jpg" class=""/>
                        <div class="panel-body">
                            <span class="text-success h4">Engineering Colleges</span> <br/>
                            Belagavi has a chain of the most beautiful and popular engineering colleges and campuses are great with good engineers every year. Check out all the engineering colleges<a href="http://www.karnataka.com/education/engg/belgaum-engineering-colleges/"> here...</a>
                        </div>
						 <img src="images/img4.jpg" class=""/>

                        <div class="panel-body">
                            <span class="text-success h4">Medical Colleges</span> <br/>
                           Well, Belagavi is also famous for its education two big medical universities are present in the heart of the city. Check out all the medical colleges<a href="https://targetstudy.com/colleges/private-medical-colleges-in-belgaum.html"> here...</a>
                        </div>
						 <img src="images/img5.jpg" class=""/>

                        <div class="panel-body">
                            <span class="text-success h4">Restaurants</span> <br/>
                           Fill ur tummy with delicious food of Belagavi. Check out all the restaurants <a href="https://www.tripadvisor.in/Restaurants-g737165-Belgaum_Karnataka.html">here...</a>
                        </div>
						 <img src="images/img6.jpg" class=""/>

                        <div class="panel-body">
                            <span class="text-success h4">Tourist attraction places</span> <br/>
                            Belagavi is 502 km from Bangalore and 154 km from Panaji. Nestled in the foothills of the Western Ghats, it enjoys a cool, salubrious climate and is surrounded by natural beauty in the form of rivers, hills and dense evergreen forests. In the vicinity there are popular tourists places like Amboli, Sindhudurg district and Jamboti.

                            A wide variety of historical sites, temples and churches exist in and around the city, most notably the Kamala Basti fort, Kapileshwar temple (South Kashi), the hills of Vaijyanath, Ramtirth waterfalls, Revan Siddeshwr Temple at Hunshevari in the valleys of Kakati, Siddeshwar Temple in Kanbargi, the aerodrome at Sambra,kittur fort,Suvarna soudha..<br/> Check out all the places <a href="https://www.tripadvisor.in/Attractions-g737165-Activities-Belgaum_Karnataka.html">here...</a>
                        </div>
						 <img src="images/img2.jpg" class=""/>

                        <div class="panel-body">
                            <span class="text-success h4">Theatres/Malls</span> <br/>
                            Bored at home or work, dont you worry Belagavi have some finest malls and theatres. Grab your popcorn tub and chilled coke and check some movies out.Check out all the theatres <a href="http://www.justdial.com/Belgaum/Cinema-Halls/ct-10099752">here...</a>
                        </div>
						 <img src="images/img7.jpg" class=""/>
                    </div>
                </div>



                <div class="clearfix"></div>
            </div>
        </div>
    </div>

    <div class="indicate">
        <div class="container">
            <div class="indicate-grids">
                <div class="col-md-3 indicate-grid">
                    <p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Belagavi, Karnataka India</p>
                </div>
                <div class="col-md-3 indicate-grid">
                    <p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>Telephone : +91 831 321 654
                    </p>
                </div>
                <div class="col-md-3 indicate-grid">
                    <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Email : <a
                            href=""> info@smartbelagavi.com</a></p>
                </div>
                <div class="col-md-3 indicate-grid">
                    <p><span class="glyphicon glyphicon-send" aria-hidden="true"></span>FAX : +91 831 123 456</p>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <div class="footer-section">
        <div class="container">
            <div class="footer-top">
                <p> &copy; 2016 Smart Belagavi. All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                        href="http://jainbgm.in"> JCE</a>
                </p>
            </div>
        </div>
    </div>
</body>
</html>