<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Public Forum</title>

    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<!-- Navigation -->
<?php include_once "navbar.php"; ?>
<!-- end of Navigation -->

<div class="OurLove-section">
    <div class="container">
        <h2>We are socially active too</h2>

        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <h3 class="text-primary">Facebook Page</h3>
                <hr/>
                <div style="height:10px; width:500px;" class="fb-page"
                     data-href="https://www.facebook.com/smarantechnology" data-small-header="false"
                     data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
                     data-show-posts="true">
                    <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="https://www.facebook.com/smarantechnology">
                            <a href="https://www.facebook.com/smarantechnology" target="_blank">Smart Belgaum Facebook Page</a>
                        </blockquote>
                    </div>
                </div>
            </div>
            <div class="col-md-7 OurLove-grid1">
                <span class="label label-primary">Youtube Channel</span>
                <br/>
                <iframe
                    src="https://www.youtube.com/watch?v=_Zcq2h0H2n4?autoplay=1"
                    width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <h3 class="text-primary">Twitter Page</h3>
                <hr/>
                <div style="height:10px; width:500px;" class="fb-page"
                     data-href="https://www.facebook.com/smarantechnology" data-small-header="false"
                     data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
                     data-show-posts="true">
                    <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="https://www.facebook.com/smarantechnology">
                            <a href="https://twitter.com/dalpats3" target="_blank">Smart Belgaum Twitter
                                Page</a>
                        </blockquote>
                    </div>
                </div>
            </div>
            <div class="col-md-5 OurLove-grid">
                <h3 class="text-primary">Google+</h3>
                <hr/>
                <div style="height:10px; width:500px;" class="fb-page"
                     data-href="https://www.facebook.com/smarantechnology" data-small-header="false"
                     data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
                     data-show-posts="true">
                    <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="https://www.facebook.com/smarantechnology">
                            <a href="https://www.twitter.com/smartbgm" target="_blank">Smart Belgaum G+
                                Page</a>
                        </blockquote>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>
        </div>
        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <h3 class="text-primary">All About Belgaum Page</h3>
                <hr/>
                <div style="height:10px; width:500px;" class="fb-page"
                     data-href="https://www.facebook.com/smarantechnology" data-small-header="false"
                     data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
                     data-show-posts="true">
                    <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="https://www.facebook.com/smarantechnology">
                            <a href="https://www.twitter.com/smartbgm" target="_blank">All About Belgaum
                                Page</a>
                        </blockquote>
                    </div>
                </div>
            </div>
            <div class="col-md-5 OurLove-grid">
                <h3 class="text-primary">Google Map</h3>
                <hr/>
                <div style="height:10px; width:500px;" class="fb-page"
                     data-href="https://www.facebook.com/smarantechnology" data-small-header="false"
                     data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"
                     data-show-posts="true">
                    <div class="fb-xfbml-parse-ignore">
                        <blockquote cite="https://www.facebook.com/smarantechnology">
                            <a href="https://www.twitter.com/smartbgm" target="_blank">Smart Belgaum on Map</a>
                        </blockquote>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>
        </div>

    </div>
</div>

<div class="indicate">
    <div class="container">
        <div class="indicate-grids">
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Belgaum, Karnataka India</p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>Telephone : +91 831 321 654
                </p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Email : <a
                        href=""> info@smartbelgaum.com</a></p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-send" aria-hidden="true"></span>FAX : +91 831 123 456</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer-section">
    <div class="container">
        <div class="footer-top">
            <p> &copy; 2016 Smart Belgaum . All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                    href="http://jainbgm.in"> JCE</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>