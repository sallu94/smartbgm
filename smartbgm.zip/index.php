<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>SmartBGM</title>

    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>


    <link href="css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once "navbar.php"; ?>
<div class="header">
    <div class="container">

        <section class="slider">
            <div class="flexslider">
                <ul class="slides">
                    <li>
                        <div class="slider-info">
                            <h3>Smart Belagavi</h3>

                            <p>A dream to becoming reality</p>

                            <div class="button">
                                <a href="about.php" class="button1 hvr-rectangle-in">What are we ?</a>
                                <a href="contact.php" class="button2 hvr-rectangle-in">Get in touch</a>
                            </div>

                        </div>
                    </li>
                    <li>
                        <div class="slider-info">
                            <h3>Smart Belagavi</h3>

                            <p>A dream to becoming reality</p>

                            <div class="button">
                                <a href="gallery.php" class="button1 hvr-rectangle-in">Gallery</a>
                                <a href="explore.php" class="button2 hvr-rectangle-in">Explore Bgm</a>
                            </div>

                        </div>
                    </li>

                </ul>
            </div>
        </section>
        <script defer src="js/jquery.flexslider.js"></script>
        <script type="text/javascript">
            $(function () {
                SyntaxHighlighter.all();
            });
            $(window).load(function () {
                $('.flexslider').flexslider({
                    animation: "slide",
                    start: function (slider) {
                        $('body').removeClass('loading');
                    }
                });
            });
        </script>
        <!-- FlexSlider -->
    </div>

</div>
<br/>

<div class="OurLove-section">
    <div class="container">
        <h2>Smart Belagavi</h2>

        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <img src="images/banner2.jpg" class="img-responsive img-circle"/>
            </div>
            <div class="col-md-7 OurLove-grid1">
                <h4>Registration</h4>
                <hr/>
                <form class="form-horizontal" method="post" action="">
                    <input type="text" name="full_name" placeholder="Full Name" class="form-control" required/><br/>
					  <input type="email" name="email" placeholder="Email" class="form-control"required/><br/>
                    <input type="text" name="username" placeholder="Username" class="form-control"required/><br/>
                    <input type="password" name="password" placeholder="Password" class="form-control"required/><br/>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" class="form-control"required/><br/>
                    <input type="date" class="form-control" name="bday" max="2000-01-01"/><br/>

                    <select name="gender" class="form-control">
                        <option class="label label-info">---Select Gender---</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select><br/>
                    <input type="submit" value="Become a member" class="btn btn-primary" name="signup"/><br/>
                </form>
                <a href="login.php">I am already a member.</a>

                <?php
                if (isset($_POST['signup'])) {
                    include_once("includes/database_function.php");
                    connect();

                    $full_name = $_POST['full_name'];
                    $username = $_POST['username'];
                    $password = $_POST['password'];
                    $bday = $_POST['bday'];
                    $gender = $_POST['gender'];

                    $q = "INSERT INTO users (full_name,username,password,birth_date,gender) VALUES ('$full_name','$username','$password','$bday','$gender');";
                    mysql_query($q) or die(mysql_error());


                    echo '<script>alert("Successfully Registered"); location.href="login.php";</script>';
                }
                ?>
            </div>
			
         <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php include_once "includes/footer.php"; ?>
</body>
</html>