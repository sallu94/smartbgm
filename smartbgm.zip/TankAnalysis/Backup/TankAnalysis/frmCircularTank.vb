﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmCircularTank
    Dim xlApp As New Excel.Application
    Dim xlWorkBook As Excel.Workbook

    Dim xlAppNew As New Excel.Application
    Dim xlWorkBookNew As Excel.Workbook

    Dim dt As String
    Dim filename As String

    Private Sub btnSaveCircularData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveCircularData.Click
        '.....Open the original complete excel file and save as
        xlWorkBook = xlApp.Workbooks.Open("D:\TankAnalysis\complete.xlsx")
        dt = Now.Day & "_" & Now.Month & "_" & Now.Year & "_" & Now.Hour & "_" & Now.Minute & "_" & Now.Second
        filename = "D:\TankAnalysis\SavedFiles\" & gbltanktype & "_" & dt & ".xlsx"
        xlWorkBook.SaveAs(Filename:=filename)
        xlWorkBook.Close()
        xlApp.Quit()

        '...open the new file and save data from the vb.net form to excel
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(10).Cells(2, 7) = txtCapacity.Text
        xlWorkBookNew.Sheets(10).Cells(3, 7) = txtDiameter.Text
        xlWorkBookNew.Sheets(10).Cells(4, 7) = txtfreeboard.Text
        xlWorkBookNew.Sheets(10).Cells(5, 7) = txtheight.Text
        xlWorkBookNew.Sheets(10).Cells(6, 7) = txtwallthick.Text
        xlWorkBookNew.Sheets(10).Cells(7, 7) = txtbaseslab.Text
        xlWorkBookNew.Sheets(10).Cells(8, 7) = txtDensityofConcrete.Text
        xlWorkBookNew.Sheets(10).Cells(9, 7) = cmbzone.Text
        xlWorkBookNew.Sheets(10).Cells(10, 7) = txtgradeofconcrete.Text
        xlWorkBookNew.Sheets(10).Cells(11, 7) = txtgradeofsteel.Text
        xlWorkBookNew.Sheets(10).Cells(12, 7) = cmbtypeofsoil.Text
        xlWorkBookNew.Sheets(10).Cells(13, 7) = txtVolumeofwater.Text
        xlWorkBookNew.Sheets(10).Cells(14, 7) = txtbaseslab.Text
        xlWorkBookNew.Sheets(10).Cells(15, 7) = txtOffset.Text
        xlWorkBookNew.Sheets(10).Cells(16, 7) = txtdomethickness.Text
        xlWorkBookNew.Sheets(10).Cells(17, 7) = txtLiveLoad.Text
        xlWorkBookNew.Sheets(10).Cells(18, 7) = txtFinishingLoad.Text
        xlWorkBookNew.Sheets(10).Cells(19, 6) = txtRingBeam1.Text
        xlWorkBookNew.Sheets(10).Cells(19, 8) = txtRingBeam2.Text



        xlWorkBookNew.Sheets(10).Cells(22, 7) = txtDrydensity.Text
        xlWorkBookNew.Sheets(10).Cells(23, 7) = txtspecificgravity.Text
        xlWorkBookNew.Sheets(10).Cells(24, 7) = txtvoidratio.Text
        xlWorkBookNew.Sheets(10).Cells(25, 7) = txtdensityofwater.Text
        xlWorkBookNew.Sheets(10).Cells(26, 7) = txtfy.Text
        xlWorkBookNew.Sheets(10).Cells(27, 7) = txtSBC.Text
        xlWorkBookNew.Sheets(10).Cells(28, 7) = txtHeightOfsoil.Text
        xlWorkBookNew.Sheets(10).Cells(29, 7) = txtSubmergedDensity.Text
        xlWorkBookNew.Sheets(10).Cells(30, 7) = txtSaturatedDensity.Text

        xlWorkBookNew.Sheets(10).Cells(33, 7) = txtMainBar.Text
        xlWorkBookNew.Sheets(10).Cells(34, 7) = txtDistributionBar.Text

        xlWorkBookNew.Close(SaveChanges:=True)
        xlAppNew.Quit()
        MsgBox("Data saved successfully", MsgBoxStyle.Information)
        btnRCC.Visible = True
        btnSeismic.Visible = True
        btnSummary.Visible = True
        btnDataSheet.Visible = True
    End Sub

    Private Sub btnSeismic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSeismic.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Seismic.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(11).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(11)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnRCC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRCC.Click
        Dim pdf_filename_RCC As String
        pdf_filename_RCC = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_RCC.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(12).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(12)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_RCC, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnSummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSummary.Click
        Dim pdf_filename_Summary As String
        pdf_filename_Summary = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Summary.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(13).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(13)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_Summary, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnDataSheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataSheet.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_DataSheet.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(10).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(10)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub
End Class