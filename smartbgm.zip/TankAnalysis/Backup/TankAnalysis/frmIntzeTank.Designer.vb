﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmIntzeTank
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtNoofcolumns = New System.Windows.Forms.ComboBox
        Me.txtdistancebtwncolumns = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtdiaofbottomdome = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtdiaoftopdome = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtfreeboard = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtdeptoftank = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtdensityofconcrete = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.cmbzone = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.cmbtypeofsoil = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtdeptoffooting = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtgradeofsteel = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.txtgradeofconcreete = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtnooflevels = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtCapacity = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtspacingofbracing = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.txtscb = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.txttensilestress = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtQ = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.txtUnitWt = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtbearingcapacity = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtwtofwater = New System.Windows.Forms.TextBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.txtfinishesload = New System.Windows.Forms.TextBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.txtdepthbydiameterratio = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.txtnominalcover = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.txtresistancetocraking = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.txtintensityofwind = New System.Windows.Forms.TextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.txtliveload = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.txtheightoftower = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.txtSecondaryBar = New System.Windows.Forms.TextBox
        Me.Label46 = New System.Windows.Forms.Label
        Me.btnSaveIntzeData = New System.Windows.Forms.Button
        Me.txtDistributionBar = New System.Windows.Forms.TextBox
        Me.Label42 = New System.Windows.Forms.Label
        Me.txtPrimaryBar = New System.Windows.Forms.TextBox
        Me.Label44 = New System.Windows.Forms.Label
        Me.txtMainBar = New System.Windows.Forms.TextBox
        Me.Label45 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.btnSeismic = New System.Windows.Forms.Button
        Me.btnSummary = New System.Windows.Forms.Button
        Me.btnRCC = New System.Windows.Forms.Button
        Me.btnDataSheet = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtNoofcolumns)
        Me.GroupBox1.Controls.Add(Me.txtdistancebtwncolumns)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtdiaofbottomdome)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtdiaoftopdome)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtfreeboard)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtdeptoftank)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtdensityofconcrete)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.cmbzone)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.cmbtypeofsoil)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtdeptoffooting)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtgradeofsteel)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.txtgradeofconcreete)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txtnooflevels)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtCapacity)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(326, 548)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Design Data"
        '
        'txtNoofcolumns
        '
        Me.txtNoofcolumns.FormattingEnabled = True
        Me.txtNoofcolumns.Items.AddRange(New Object() {"4", "5", "6", "8", "9", "10", "12"})
        Me.txtNoofcolumns.Location = New System.Drawing.Point(158, 57)
        Me.txtNoofcolumns.Name = "txtNoofcolumns"
        Me.txtNoofcolumns.Size = New System.Drawing.Size(121, 21)
        Me.txtNoofcolumns.TabIndex = 50
        '
        'txtdistancebtwncolumns
        '
        Me.txtdistancebtwncolumns.Location = New System.Drawing.Point(163, 503)
        Me.txtdistancebtwncolumns.Name = "txtdistancebtwncolumns"
        Me.txtdistancebtwncolumns.Size = New System.Drawing.Size(121, 20)
        Me.txtdistancebtwncolumns.TabIndex = 49
        Me.txtdistancebtwncolumns.Text = "1000"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(-1, 506)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(161, 13)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "Distance btwn 2 adjcnt columns:"
        '
        'txtdiaofbottomdome
        '
        Me.txtdiaofbottomdome.Location = New System.Drawing.Point(159, 466)
        Me.txtdiaofbottomdome.Name = "txtdiaofbottomdome"
        Me.txtdiaofbottomdome.Size = New System.Drawing.Size(121, 20)
        Me.txtdiaofbottomdome.TabIndex = 47
        Me.txtdiaofbottomdome.Text = "1000"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 469)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 13)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "Dia of Bottom Dome:"
        '
        'txtdiaoftopdome
        '
        Me.txtdiaoftopdome.Location = New System.Drawing.Point(159, 428)
        Me.txtdiaoftopdome.Name = "txtdiaoftopdome"
        Me.txtdiaoftopdome.Size = New System.Drawing.Size(121, 20)
        Me.txtdiaoftopdome.TabIndex = 45
        Me.txtdiaoftopdome.Text = "1000"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 431)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 13)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Dia of Top Dome:"
        '
        'txtfreeboard
        '
        Me.txtfreeboard.Location = New System.Drawing.Point(159, 391)
        Me.txtfreeboard.Name = "txtfreeboard"
        Me.txtfreeboard.Size = New System.Drawing.Size(121, 20)
        Me.txtfreeboard.TabIndex = 43
        Me.txtfreeboard.Text = "1000"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(41, 393)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 42
        Me.Label5.Text = "Freeboard:"
        '
        'txtdeptoftank
        '
        Me.txtdeptoftank.Location = New System.Drawing.Point(158, 355)
        Me.txtdeptoftank.Name = "txtdeptoftank"
        Me.txtdeptoftank.Size = New System.Drawing.Size(121, 20)
        Me.txtdeptoftank.TabIndex = 41
        Me.txtdeptoftank.Text = "1000"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(35, 362)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 13)
        Me.Label3.TabIndex = 40
        Me.Label3.Text = "Depth of Tank:"
        '
        'txtdensityofconcrete
        '
        Me.txtdensityofconcrete.Location = New System.Drawing.Point(158, 317)
        Me.txtdensityofconcrete.Name = "txtdensityofconcrete"
        Me.txtdensityofconcrete.Size = New System.Drawing.Size(121, 20)
        Me.txtdensityofconcrete.TabIndex = 39
        Me.txtdensityofconcrete.Text = "1000"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(15, 323)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(105, 13)
        Me.Label32.TabIndex = 38
        Me.Label32.Text = "Density Of Concrete:"
        '
        'cmbzone
        '
        Me.cmbzone.FormattingEnabled = True
        Me.cmbzone.Items.AddRange(New Object() {"II", "III", "IV", "V"})
        Me.cmbzone.Location = New System.Drawing.Point(158, 282)
        Me.cmbzone.Name = "cmbzone"
        Me.cmbzone.Size = New System.Drawing.Size(121, 21)
        Me.cmbzone.TabIndex = 37
        Me.cmbzone.Text = "II"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(64, 289)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 13)
        Me.Label14.TabIndex = 36
        Me.Label14.Text = "Zone:"
        '
        'cmbtypeofsoil
        '
        Me.cmbtypeofsoil.FormattingEnabled = True
        Me.cmbtypeofsoil.Items.AddRange(New Object() {"Hard Soil", "Medium Soil", "Soft Soil"})
        Me.cmbtypeofsoil.Location = New System.Drawing.Point(158, 245)
        Me.cmbtypeofsoil.Name = "cmbtypeofsoil"
        Me.cmbtypeofsoil.Size = New System.Drawing.Size(121, 21)
        Me.cmbtypeofsoil.TabIndex = 35
        Me.cmbtypeofsoil.Text = "Hard Soil"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(31, 252)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(68, 13)
        Me.Label13.TabIndex = 34
        Me.Label13.Text = "Type Of Soil:"
        '
        'txtdeptoffooting
        '
        Me.txtdeptoffooting.Location = New System.Drawing.Point(159, 209)
        Me.txtdeptoffooting.Name = "txtdeptoffooting"
        Me.txtdeptoffooting.Size = New System.Drawing.Size(121, 20)
        Me.txtdeptoffooting.TabIndex = 33
        Me.txtdeptoffooting.Text = "1000"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 213)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Depth of Footing:"
        '
        'txtgradeofsteel
        '
        Me.txtgradeofsteel.Location = New System.Drawing.Point(159, 170)
        Me.txtgradeofsteel.Name = "txtgradeofsteel"
        Me.txtgradeofsteel.Size = New System.Drawing.Size(121, 20)
        Me.txtgradeofsteel.TabIndex = 31
        Me.txtgradeofsteel.Text = "1000"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(29, 176)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(80, 13)
        Me.Label33.TabIndex = 30
        Me.Label33.Text = "Grade Of Steel:"
        '
        'txtgradeofconcreete
        '
        Me.txtgradeofconcreete.Location = New System.Drawing.Point(158, 134)
        Me.txtgradeofconcreete.Name = "txtgradeofconcreete"
        Me.txtgradeofconcreete.Size = New System.Drawing.Size(121, 20)
        Me.txtgradeofconcreete.TabIndex = 23
        Me.txtgradeofconcreete.Text = "1000"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(15, 140)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(99, 13)
        Me.Label15.TabIndex = 22
        Me.Label15.Text = "Grade Of Concrete:"
        '
        'txtnooflevels
        '
        Me.txtnooflevels.Location = New System.Drawing.Point(158, 97)
        Me.txtnooflevels.Name = "txtnooflevels"
        Me.txtnooflevels.Size = New System.Drawing.Size(121, 20)
        Me.txtnooflevels.TabIndex = 21
        Me.txtnooflevels.Text = "3"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(24, 103)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 13)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "No. Of Levels:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(15, 66)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "No. Of Columns:"
        '
        'txtCapacity
        '
        Me.txtCapacity.Location = New System.Drawing.Point(158, 27)
        Me.txtCapacity.Name = "txtCapacity"
        Me.txtCapacity.Size = New System.Drawing.Size(121, 20)
        Me.txtCapacity.TabIndex = 17
        Me.txtCapacity.Text = "400"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Capacity of Tank :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtspacingofbracing)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.txtscb)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.txttensilestress)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.txtQ)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.txtUnitWt)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.txtbearingcapacity)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.txtwtofwater)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.txtfinishesload)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.txtdepthbydiameterratio)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.txtnominalcover)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.txtresistancetocraking)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.txtintensityofwind)
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.txtliveload)
        Me.GroupBox2.Controls.Add(Me.Label30)
        Me.GroupBox2.Controls.Add(Me.txtheightoftower)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Location = New System.Drawing.Point(347, 38)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(324, 548)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Design Data"
        '
        'txtspacingofbracing
        '
        Me.txtspacingofbracing.Location = New System.Drawing.Point(141, 488)
        Me.txtspacingofbracing.Name = "txtspacingofbracing"
        Me.txtspacingofbracing.Size = New System.Drawing.Size(121, 20)
        Me.txtspacingofbracing.TabIndex = 75
        Me.txtspacingofbracing.Text = "1000"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(38, 493)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(100, 13)
        Me.Label17.TabIndex = 74
        Me.Label17.Text = "Spacing of Bracing:"
        '
        'txtscb
        '
        Me.txtscb.Location = New System.Drawing.Point(141, 449)
        Me.txtscb.Name = "txtscb"
        Me.txtscb.Size = New System.Drawing.Size(121, 20)
        Me.txtscb.TabIndex = 73
        Me.txtscb.Text = "1000"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(107, 453)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(27, 13)
        Me.Label19.TabIndex = 72
        Me.Label19.Text = "scb:"
        '
        'txttensilestress
        '
        Me.txttensilestress.Location = New System.Drawing.Point(141, 412)
        Me.txttensilestress.Name = "txttensilestress"
        Me.txttensilestress.Size = New System.Drawing.Size(121, 20)
        Me.txttensilestress.TabIndex = 71
        Me.txttensilestress.Text = "1000"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(26, 415)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(108, 13)
        Me.Label20.TabIndex = 70
        Me.Label20.Text = "Tensile stress (Tank):"
        '
        'txtQ
        '
        Me.txtQ.Location = New System.Drawing.Point(141, 379)
        Me.txtQ.Name = "txtQ"
        Me.txtQ.Size = New System.Drawing.Size(121, 20)
        Me.txtQ.TabIndex = 69
        Me.txtQ.Text = "1000"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(110, 383)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(18, 13)
        Me.Label21.TabIndex = 68
        Me.Label21.Text = "Q:"
        '
        'txtUnitWt
        '
        Me.txtUnitWt.Location = New System.Drawing.Point(141, 347)
        Me.txtUnitWt.Name = "txtUnitWt"
        Me.txtUnitWt.Size = New System.Drawing.Size(121, 20)
        Me.txtUnitWt.TabIndex = 67
        Me.txtUnitWt.Text = "1000"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(67, 350)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(66, 13)
        Me.Label11.TabIndex = 66
        Me.Label11.Text = "Unit Weight:"
        '
        'txtbearingcapacity
        '
        Me.txtbearingcapacity.Location = New System.Drawing.Point(141, 314)
        Me.txtbearingcapacity.Name = "txtbearingcapacity"
        Me.txtbearingcapacity.Size = New System.Drawing.Size(121, 20)
        Me.txtbearingcapacity.TabIndex = 65
        Me.txtbearingcapacity.Text = "1000"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(10, 317)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(125, 13)
        Me.Label22.TabIndex = 64
        Me.Label22.Text = "Bearing capcity of earth :"
        '
        'txtwtofwater
        '
        Me.txtwtofwater.Location = New System.Drawing.Point(141, 279)
        Me.txtwtofwater.Name = "txtwtofwater"
        Me.txtwtofwater.Size = New System.Drawing.Size(121, 20)
        Me.txtwtofwater.TabIndex = 63
        Me.txtwtofwater.Text = "1000"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(67, 282)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(65, 13)
        Me.Label23.TabIndex = 62
        Me.Label23.Text = "wt of water :"
        '
        'txtfinishesload
        '
        Me.txtfinishesload.Location = New System.Drawing.Point(141, 243)
        Me.txtfinishesload.Name = "txtfinishesload"
        Me.txtfinishesload.Size = New System.Drawing.Size(121, 20)
        Me.txtfinishesload.TabIndex = 61
        Me.txtfinishesload.Text = "1000"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(59, 247)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(74, 13)
        Me.Label25.TabIndex = 60
        Me.Label25.Text = "Finishes load :"
        '
        'txtdepthbydiameterratio
        '
        Me.txtdepthbydiameterratio.Location = New System.Drawing.Point(143, 206)
        Me.txtdepthbydiameterratio.Name = "txtdepthbydiameterratio"
        Me.txtdepthbydiameterratio.Size = New System.Drawing.Size(121, 20)
        Me.txtdepthbydiameterratio.TabIndex = 59
        Me.txtdepthbydiameterratio.Text = "1000"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(19, 209)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(118, 13)
        Me.Label26.TabIndex = 58
        Me.Label26.Text = "Depth / diameter Ratio:"
        '
        'txtnominalcover
        '
        Me.txtnominalcover.Location = New System.Drawing.Point(143, 169)
        Me.txtnominalcover.Name = "txtnominalcover"
        Me.txtnominalcover.Size = New System.Drawing.Size(121, 20)
        Me.txtnominalcover.TabIndex = 57
        Me.txtnominalcover.Text = "1000"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(52, 173)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(85, 13)
        Me.Label27.TabIndex = 56
        Me.Label27.Text = "Nominal  Cover :"
        '
        'txtresistancetocraking
        '
        Me.txtresistancetocraking.Location = New System.Drawing.Point(143, 131)
        Me.txtresistancetocraking.Name = "txtresistancetocraking"
        Me.txtresistancetocraking.Size = New System.Drawing.Size(121, 20)
        Me.txtresistancetocraking.TabIndex = 55
        Me.txtresistancetocraking.Text = "1000"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(2, 134)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(136, 13)
        Me.Label28.TabIndex = 54
        Me.Label28.Text = "Resistance to cracking sct:"
        '
        'txtintensityofwind
        '
        Me.txtintensityofwind.Location = New System.Drawing.Point(143, 94)
        Me.txtintensityofwind.Name = "txtintensityofwind"
        Me.txtintensityofwind.Size = New System.Drawing.Size(121, 20)
        Me.txtintensityofwind.TabIndex = 53
        Me.txtintensityofwind.Text = "1000"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(44, 97)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(89, 13)
        Me.Label29.TabIndex = 52
        Me.Label29.Text = "Intensity of wind :"
        '
        'txtliveload
        '
        Me.txtliveload.Location = New System.Drawing.Point(144, 58)
        Me.txtliveload.Name = "txtliveload"
        Me.txtliveload.Size = New System.Drawing.Size(121, 20)
        Me.txtliveload.TabIndex = 51
        Me.txtliveload.Text = "1000"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(33, 63)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(99, 13)
        Me.Label30.TabIndex = 50
        Me.Label30.Text = "Live load on Dome:"
        '
        'txtheightoftower
        '
        Me.txtheightoftower.Location = New System.Drawing.Point(145, 24)
        Me.txtheightoftower.Name = "txtheightoftower"
        Me.txtheightoftower.Size = New System.Drawing.Size(121, 20)
        Me.txtheightoftower.TabIndex = 49
        Me.txtheightoftower.Text = "54"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 27)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(126, 13)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "Height of Tower from GL:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtSecondaryBar)
        Me.GroupBox4.Controls.Add(Me.Label46)
        Me.GroupBox4.Controls.Add(Me.btnSaveIntzeData)
        Me.GroupBox4.Controls.Add(Me.txtDistributionBar)
        Me.GroupBox4.Controls.Add(Me.Label42)
        Me.GroupBox4.Controls.Add(Me.txtPrimaryBar)
        Me.GroupBox4.Controls.Add(Me.Label44)
        Me.GroupBox4.Controls.Add(Me.txtMainBar)
        Me.GroupBox4.Controls.Add(Me.Label45)
        Me.GroupBox4.Location = New System.Drawing.Point(677, 38)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(301, 270)
        Me.GroupBox4.TabIndex = 76
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Diameter of Reinforcement Bars"
        '
        'txtSecondaryBar
        '
        Me.txtSecondaryBar.Location = New System.Drawing.Point(143, 114)
        Me.txtSecondaryBar.Name = "txtSecondaryBar"
        Me.txtSecondaryBar.Size = New System.Drawing.Size(121, 20)
        Me.txtSecondaryBar.TabIndex = 41
        Me.txtSecondaryBar.Text = "10"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(4, 152)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(141, 13)
        Me.Label46.TabIndex = 40
        Me.Label46.Text = "Diameter of Distribution Bar :"
        '
        'btnSaveIntzeData
        '
        Me.btnSaveIntzeData.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSaveIntzeData.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveIntzeData.Location = New System.Drawing.Point(13, 195)
        Me.btnSaveIntzeData.Name = "btnSaveIntzeData"
        Me.btnSaveIntzeData.Size = New System.Drawing.Size(247, 31)
        Me.btnSaveIntzeData.TabIndex = 5
        Me.btnSaveIntzeData.Text = "Save Intze Data"
        Me.btnSaveIntzeData.UseVisualStyleBackColor = False
        '
        'txtDistributionBar
        '
        Me.txtDistributionBar.Location = New System.Drawing.Point(143, 149)
        Me.txtDistributionBar.Name = "txtDistributionBar"
        Me.txtDistributionBar.Size = New System.Drawing.Size(121, 20)
        Me.txtDistributionBar.TabIndex = 39
        Me.txtDistributionBar.Text = "10"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(2, 117)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(140, 13)
        Me.Label42.TabIndex = 34
        Me.Label42.Text = "Diameter of Secondary Bar :"
        '
        'txtPrimaryBar
        '
        Me.txtPrimaryBar.Location = New System.Drawing.Point(142, 75)
        Me.txtPrimaryBar.Name = "txtPrimaryBar"
        Me.txtPrimaryBar.Size = New System.Drawing.Size(121, 20)
        Me.txtPrimaryBar.TabIndex = 38
        Me.txtPrimaryBar.Text = "12"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(2, 78)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(122, 13)
        Me.Label44.TabIndex = 35
        Me.Label44.Text = "Diameter of primary Bar :"
        '
        'txtMainBar
        '
        Me.txtMainBar.Location = New System.Drawing.Point(142, 40)
        Me.txtMainBar.Name = "txtMainBar"
        Me.txtMainBar.Size = New System.Drawing.Size(121, 20)
        Me.txtMainBar.TabIndex = 37
        Me.txtMainBar.Text = "16"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(10, 43)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(111, 13)
        Me.Label45.TabIndex = 36
        Me.Label45.Text = "Diameter of main Bar :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Courier New", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Blue
        Me.Label24.Location = New System.Drawing.Point(356, -2)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(205, 36)
        Me.Label24.TabIndex = 77
        Me.Label24.Text = "Intze Tank"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnDataSheet)
        Me.GroupBox5.Controls.Add(Me.btnSeismic)
        Me.GroupBox5.Controls.Add(Me.btnSummary)
        Me.GroupBox5.Controls.Add(Me.btnRCC)
        Me.GroupBox5.Location = New System.Drawing.Point(172, 592)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(722, 67)
        Me.GroupBox5.TabIndex = 78
        Me.GroupBox5.TabStop = False
        '
        'btnSeismic
        '
        Me.btnSeismic.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSeismic.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeismic.Location = New System.Drawing.Point(203, 19)
        Me.btnSeismic.Name = "btnSeismic"
        Me.btnSeismic.Size = New System.Drawing.Size(128, 31)
        Me.btnSeismic.TabIndex = 9
        Me.btnSeismic.Text = "SEISMIC"
        Me.btnSeismic.UseVisualStyleBackColor = False
        Me.btnSeismic.Visible = False
        '
        'btnSummary
        '
        Me.btnSummary.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSummary.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSummary.Location = New System.Drawing.Point(549, 19)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(128, 31)
        Me.btnSummary.TabIndex = 11
        Me.btnSummary.Text = "SUMMARY"
        Me.btnSummary.UseVisualStyleBackColor = False
        Me.btnSummary.Visible = False
        '
        'btnRCC
        '
        Me.btnRCC.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnRCC.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRCC.Location = New System.Drawing.Point(377, 19)
        Me.btnRCC.Name = "btnRCC"
        Me.btnRCC.Size = New System.Drawing.Size(128, 31)
        Me.btnRCC.TabIndex = 10
        Me.btnRCC.Text = "RCC"
        Me.btnRCC.UseVisualStyleBackColor = False
        Me.btnRCC.Visible = False
        '
        'btnDataSheet
        '
        Me.btnDataSheet.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnDataSheet.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataSheet.Location = New System.Drawing.Point(39, 19)
        Me.btnDataSheet.Name = "btnDataSheet"
        Me.btnDataSheet.Size = New System.Drawing.Size(128, 31)
        Me.btnDataSheet.TabIndex = 12
        Me.btnDataSheet.Text = "Data Sheet"
        Me.btnDataSheet.UseVisualStyleBackColor = False
        Me.btnDataSheet.Visible = False
        '
        'frmIntzeTank
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(990, 668)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmIntzeTank"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MTech ""Tank Analysis""  - Intze Tank"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCapacity As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtnooflevels As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtgradeofconcreete As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtgradeofsteel As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtdeptoffooting As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbtypeofsoil As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents cmbzone As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtdensityofconcrete As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents txtdeptoftank As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtfreeboard As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtdiaofbottomdome As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtdiaoftopdome As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtdistancebtwncolumns As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtheightoftower As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtliveload As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtintensityofwind As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtresistancetocraking As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtnominalcover As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtdepthbydiameterratio As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtfinishesload As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtwtofwater As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtbearingcapacity As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtUnitWt As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtQ As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txttensilestress As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtscb As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtspacingofbracing As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSecondaryBar As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents btnSaveIntzeData As System.Windows.Forms.Button
    Friend WithEvents txtDistributionBar As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtPrimaryBar As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtMainBar As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSeismic As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button
    Friend WithEvents btnRCC As System.Windows.Forms.Button
    Friend WithEvents txtNoofcolumns As System.Windows.Forms.ComboBox
    Friend WithEvents btnDataSheet As System.Windows.Forms.Button
End Class
