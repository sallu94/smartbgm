﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmRectangularTankData
    Dim xlApp As New Excel.Application
    Dim xlWorkBook As Excel.Workbook

    Dim xlAppNew As New Excel.Application
    Dim xlWorkBookNew As Excel.Workbook

    Dim dt As String
    Dim filename As String

    Private Sub btnSaveRectData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveRectData.Click
        '.....Open the original complete excel file and save as
        xlWorkBook = xlApp.Workbooks.Open("D:\TankAnalysis\complete.xlsx")
        dt = Now.Day & "_" & Now.Month & "_" & Now.Year & "_" & Now.Hour & "_" & Now.Minute & "_" & Now.Second
        filename = "D:\TankAnalysis\SavedFiles\" & gbltanktype & "_" & dt & ".xlsx"
        xlWorkBook.SaveAs(Filename:=filename)
        xlWorkBook.Close()
        xlApp.Quit()

        '...open the new file and save data from the vb.net form to excel
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(3).Cells(2, 8) = txtCapacity.Text
        xlWorkBookNew.Sheets(3).Cells(3, 8) = txtlength.Text
        xlWorkBookNew.Sheets(3).Cells(4, 8) = txtbreadth.Text
        xlWorkBookNew.Sheets(3).Cells(5, 8) = txtheight.Text
        xlWorkBookNew.Sheets(3).Cells(6, 8) = txtfreeboard.Text
        xlWorkBookNew.Sheets(3).Cells(7, 8) = txtwallthick.Text
        xlWorkBookNew.Sheets(3).Cells(8, 8) = txtbaseslab.Text
        xlWorkBookNew.Sheets(3).Cells(9, 8) = cmbzone.Text
        xlWorkBookNew.Sheets(3).Cells(10, 8) = cmbtypeofsoil.Text
        xlWorkBookNew.Sheets(3).Cells(11, 8) = txtgradeofconcrete.Text
        xlWorkBookNew.Sheets(3).Cells(12, 8) = txtgradeofsteel.Text
        xlWorkBookNew.Sheets(3).Cells(13, 8) = txtwallthickness.Text
        xlWorkBookNew.Sheets(3).Cells(14, 8) = txtthickbaseslab.Text
        xlWorkBookNew.Sheets(3).Cells(17, 8) = txtDrydensity.Text
        xlWorkBookNew.Sheets(3).Cells(18, 8) = txtspecificgravity.Text
        xlWorkBookNew.Sheets(3).Cells(19, 8) = txtvoidratio.Text
        xlWorkBookNew.Sheets(3).Cells(20, 8) = txtdensityofwater.Text
        xlWorkBookNew.Sheets(3).Cells(21, 8) = txtfy.Text
        xlWorkBookNew.Sheets(3).Cells(22, 8) = txtSBC.Text
        xlWorkBookNew.Sheets(3).Cells(23, 8) = txtangleofrepose.Text
        xlWorkBookNew.Sheets(3).Cells(26, 8) = txtMainBar.Text
        xlWorkBookNew.Sheets(3).Cells(27, 8) = txtPrimaryBar.Text
        xlWorkBookNew.Sheets(3).Cells(28, 8) = txtDistributionBar.Text

        xlWorkBookNew.Close(SaveChanges:=True)
        xlAppNew.Quit()
        MsgBox("Data saved successfully", MsgBoxStyle.Information)
        btnRCC.Visible = True
        btnSeismic.Visible = True
        btnSummary.Visible = True
        btnDataSheet.Visible = True
    End Sub

    Private Sub btnSeismic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSeismic.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Seismic.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(4).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(4)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)

    End Sub

    Private Sub btnRCC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRCC.Click
        Dim LbyB As Decimal
        LbyB = Val(txtlength.Text) / Val(txtbreadth.Text)
        If (LbyB < 2) Then
            Dim pdf_filename_RCC As String
            pdf_filename_RCC = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_RCC.pdf"
            xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
            xlWorkBookNew.Sheets(5).activate()
            Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(5)
            mySheet.ExportAsFixedFormat( _
            Excel.XlFixedFormatType.xlTypePDF, _
            pdf_filename_RCC, _
            Excel.XlFixedFormatQuality.xlQualityStandard, _
            False, _
            False, _
            1, _
            10, _
            True)
        Else
            Dim pdf_filename_RCC As String
            pdf_filename_RCC = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_RCC.pdf"
            xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
            xlWorkBookNew.Sheets(7).activate()
            Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(7)
            mySheet.ExportAsFixedFormat( _
            Excel.XlFixedFormatType.xlTypePDF, _
            pdf_filename_RCC, _
            Excel.XlFixedFormatQuality.xlQualityStandard, _
            False, _
            False, _
            1, _
            10, _
            True)
        End If
    End Sub

    Private Sub btnSummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSummary.Click
        Dim LbyB As Decimal
        LbyB = Val(txtlength.Text) / Val(txtbreadth.Text)
        If (LbyB < 2) Then
            Dim pdf_filename_Summary As String
            pdf_filename_Summary = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Summary.pdf"
            xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
            xlWorkBookNew.Sheets(6).activate()
            Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(6)
            mySheet.ExportAsFixedFormat( _
            Excel.XlFixedFormatType.xlTypePDF, _
            pdf_filename_Summary, _
            Excel.XlFixedFormatQuality.xlQualityStandard, _
            False, _
            False, _
            1, _
            10, _
            True)
        Else
            Dim pdf_filename_Summary As String
            pdf_filename_Summary = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Summary.pdf"
            xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
            xlWorkBookNew.Sheets(8).activate()
            Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(8)
            mySheet.ExportAsFixedFormat( _
            Excel.XlFixedFormatType.xlTypePDF, _
            pdf_filename_Summary, _
            Excel.XlFixedFormatQuality.xlQualityStandard, _
            False, _
            False, _
            1, _
            10, _
            True)
        End If
    End Sub

    Private Sub btnDataSheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataSheet.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_DataSheet.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(3).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(3)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)

    End Sub
End Class