﻿Public Class frmSymbols

    Private Sub btnNextPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNextPage.Click
        frmSymbols2.Show()
    End Sub
End Class