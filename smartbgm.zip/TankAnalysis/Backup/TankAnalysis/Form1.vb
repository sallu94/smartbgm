﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class Form1
    Dim xlApp As New Excel.Application
    Dim xlWorkBook As Excel.Workbook

    Dim xlAppNew As New Excel.Application
    Dim xlWorkBookNew As Excel.Workbook

    Dim dt As String
    Dim filename As String
    
    Private Sub btnDataSheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataSheet.Click
        gbltanktype = cmbTType.Text
        If (gbltanktype = "RECTANGULAR TANK") Then
            frmRectangularTankData.Show()
        ElseIf (gbltanktype = "CIRCULAR TANK") Then
            frmCircularTank.Show()
        ElseIf (gbltanktype = "OVERHEAD TANK") Then
            frmOverHead.Show()
        ElseIf (gbltanktype = "INTZE TANK") Then
            frmIntzeTank.Show()
        Else
            MsgBox("Invalid Selection", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnSymbols_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSymbols.Click
        frmSymbols.Show()
    End Sub
End Class
