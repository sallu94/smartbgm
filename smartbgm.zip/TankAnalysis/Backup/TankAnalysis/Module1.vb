﻿Module Module1
    Public gbltanktype As String
End Module
