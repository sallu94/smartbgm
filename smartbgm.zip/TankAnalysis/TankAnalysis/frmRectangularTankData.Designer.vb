﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRectangularTankData
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnSaveRectData = New System.Windows.Forms.Button()
        Me.txtDistributionBar = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtPrimaryBar = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtMainBar = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtangleofrepose = New System.Windows.Forms.TextBox()
        Me.txtSBC = New System.Windows.Forms.TextBox()
        Me.txtfy = New System.Windows.Forms.TextBox()
        Me.txtdensityofwater = New System.Windows.Forms.TextBox()
        Me.txtvoidratio = New System.Windows.Forms.TextBox()
        Me.txtspecificgravity = New System.Windows.Forms.TextBox()
        Me.txtDrydensity = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtgradeofsteel = New System.Windows.Forms.TextBox()
        Me.txtgradeofconcrete = New System.Windows.Forms.TextBox()
        Me.cmbtypeofsoil = New System.Windows.Forms.ComboBox()
        Me.cmbzone = New System.Windows.Forms.ComboBox()
        Me.txtbaseslab = New System.Windows.Forms.TextBox()
        Me.txtwallthick = New System.Windows.Forms.TextBox()
        Me.txtfreeboard = New System.Windows.Forms.TextBox()
        Me.txtheight = New System.Windows.Forms.TextBox()
        Me.txtbreadth = New System.Windows.Forms.TextBox()
        Me.txtlength = New System.Windows.Forms.TextBox()
        Me.txtCapacity = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSeismic = New System.Windows.Forms.Button()
        Me.btnRCC = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnDataSheet = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Courier New", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Blue
        Me.Label24.Location = New System.Drawing.Point(179, 11)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(319, 36)
        Me.Label24.TabIndex = 4
        Me.Label24.Text = "Rectangular Tank"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label40)
        Me.GroupBox3.Controls.Add(Me.Label39)
        Me.GroupBox3.Controls.Add(Me.Label38)
        Me.GroupBox3.Controls.Add(Me.btnSaveRectData)
        Me.GroupBox3.Controls.Add(Me.txtDistributionBar)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.txtPrimaryBar)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.txtMainBar)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Location = New System.Drawing.Point(408, 351)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(331, 220)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Diameter of Reinforcement Bars"
        '
        'btnSaveRectData
        '
        Me.btnSaveRectData.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSaveRectData.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveRectData.Location = New System.Drawing.Point(62, 150)
        Me.btnSaveRectData.Name = "btnSaveRectData"
        Me.btnSaveRectData.Size = New System.Drawing.Size(247, 31)
        Me.btnSaveRectData.TabIndex = 5
        Me.btnSaveRectData.Text = "Save Rectangular Data"
        Me.btnSaveRectData.UseVisualStyleBackColor = False
        '
        'txtDistributionBar
        '
        Me.txtDistributionBar.Location = New System.Drawing.Point(143, 114)
        Me.txtDistributionBar.Name = "txtDistributionBar"
        Me.txtDistributionBar.Size = New System.Drawing.Size(121, 20)
        Me.txtDistributionBar.TabIndex = 39
        Me.txtDistributionBar.Text = "10"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(2, 117)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(141, 13)
        Me.Label23.TabIndex = 34
        Me.Label23.Text = "Diameter of Distribution Bar :"
        '
        'txtPrimaryBar
        '
        Me.txtPrimaryBar.Location = New System.Drawing.Point(142, 75)
        Me.txtPrimaryBar.Name = "txtPrimaryBar"
        Me.txtPrimaryBar.Size = New System.Drawing.Size(121, 20)
        Me.txtPrimaryBar.TabIndex = 38
        Me.txtPrimaryBar.Text = "12"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(2, 78)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(122, 13)
        Me.Label22.TabIndex = 35
        Me.Label22.Text = "Diameter of primary Bar :"
        '
        'txtMainBar
        '
        Me.txtMainBar.Location = New System.Drawing.Point(142, 40)
        Me.txtMainBar.Name = "txtMainBar"
        Me.txtMainBar.Size = New System.Drawing.Size(121, 20)
        Me.txtMainBar.TabIndex = 37
        Me.txtMainBar.Text = "16"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(10, 43)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(111, 13)
        Me.Label21.TabIndex = 36
        Me.Label21.Text = "Diameter of main Bar :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label37)
        Me.GroupBox2.Controls.Add(Me.Label36)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.Label32)
        Me.GroupBox2.Controls.Add(Me.txtangleofrepose)
        Me.GroupBox2.Controls.Add(Me.txtSBC)
        Me.GroupBox2.Controls.Add(Me.txtfy)
        Me.GroupBox2.Controls.Add(Me.txtdensityofwater)
        Me.GroupBox2.Controls.Add(Me.txtvoidratio)
        Me.GroupBox2.Controls.Add(Me.txtspecificgravity)
        Me.GroupBox2.Controls.Add(Me.txtDrydensity)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Location = New System.Drawing.Point(408, 70)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(331, 275)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Soil Characteristics"
        '
        'txtangleofrepose
        '
        Me.txtangleofrepose.Location = New System.Drawing.Point(106, 240)
        Me.txtangleofrepose.Name = "txtangleofrepose"
        Me.txtangleofrepose.Size = New System.Drawing.Size(121, 20)
        Me.txtangleofrepose.TabIndex = 33
        Me.txtangleofrepose.Text = "30"
        '
        'txtSBC
        '
        Me.txtSBC.Location = New System.Drawing.Point(105, 201)
        Me.txtSBC.Name = "txtSBC"
        Me.txtSBC.Size = New System.Drawing.Size(121, 20)
        Me.txtSBC.TabIndex = 32
        Me.txtSBC.Text = "150"
        '
        'txtfy
        '
        Me.txtfy.Location = New System.Drawing.Point(105, 166)
        Me.txtfy.Name = "txtfy"
        Me.txtfy.Size = New System.Drawing.Size(121, 20)
        Me.txtfy.TabIndex = 31
        Me.txtfy.Text = "13"
        '
        'txtdensityofwater
        '
        Me.txtdensityofwater.Location = New System.Drawing.Point(106, 130)
        Me.txtdensityofwater.Name = "txtdensityofwater"
        Me.txtdensityofwater.Size = New System.Drawing.Size(121, 20)
        Me.txtdensityofwater.TabIndex = 30
        Me.txtdensityofwater.Text = "10"
        '
        'txtvoidratio
        '
        Me.txtvoidratio.Location = New System.Drawing.Point(107, 92)
        Me.txtvoidratio.Name = "txtvoidratio"
        Me.txtvoidratio.Size = New System.Drawing.Size(121, 20)
        Me.txtvoidratio.TabIndex = 29
        Me.txtvoidratio.Text = "0.7"
        '
        'txtspecificgravity
        '
        Me.txtspecificgravity.Location = New System.Drawing.Point(107, 60)
        Me.txtspecificgravity.Name = "txtspecificgravity"
        Me.txtspecificgravity.Size = New System.Drawing.Size(121, 20)
        Me.txtspecificgravity.TabIndex = 28
        Me.txtspecificgravity.Text = "2.55"
        '
        'txtDrydensity
        '
        Me.txtDrydensity.Location = New System.Drawing.Point(107, 24)
        Me.txtDrydensity.Name = "txtDrydensity"
        Me.txtDrydensity.Size = New System.Drawing.Size(121, 20)
        Me.txtDrydensity.TabIndex = 27
        Me.txtDrydensity.Text = "150"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(13, 66)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(87, 13)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "Specific Gravity :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(37, 98)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(62, 13)
        Me.Label15.TabIndex = 25
        Me.Label15.Text = "Void Ratio :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 133)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(89, 13)
        Me.Label16.TabIndex = 24
        Me.Label16.Text = "Density of water :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(76, 169)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(23, 13)
        Me.Label17.TabIndex = 23
        Me.Label17.Text = "Φ :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(59, 204)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(40, 13)
        Me.Label18.TabIndex = 22
        Me.Label18.Text = "S.B.C :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(8, 243)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(92, 13)
        Me.Label19.TabIndex = 21
        Me.Label19.Text = "Angle of Repose :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(32, 26)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(67, 13)
        Me.Label20.TabIndex = 20
        Me.Label20.Text = "Dry Density :"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.txtgradeofsteel)
        Me.GroupBox1.Controls.Add(Me.txtgradeofconcrete)
        Me.GroupBox1.Controls.Add(Me.cmbtypeofsoil)
        Me.GroupBox1.Controls.Add(Me.cmbzone)
        Me.GroupBox1.Controls.Add(Me.txtbaseslab)
        Me.GroupBox1.Controls.Add(Me.txtwallthick)
        Me.GroupBox1.Controls.Add(Me.txtfreeboard)
        Me.GroupBox1.Controls.Add(Me.txtheight)
        Me.GroupBox1.Controls.Add(Me.txtbreadth)
        Me.GroupBox1.Controls.Add(Me.txtlength)
        Me.GroupBox1.Controls.Add(Me.txtCapacity)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(50, 65)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(341, 506)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = " Seismic Design"
        '
        'txtgradeofsteel
        '
        Me.txtgradeofsteel.Location = New System.Drawing.Point(127, 395)
        Me.txtgradeofsteel.Name = "txtgradeofsteel"
        Me.txtgradeofsteel.Size = New System.Drawing.Size(121, 20)
        Me.txtgradeofsteel.TabIndex = 23
        Me.txtgradeofsteel.Text = "415"
        '
        'txtgradeofconcrete
        '
        Me.txtgradeofconcrete.Location = New System.Drawing.Point(127, 357)
        Me.txtgradeofconcrete.Name = "txtgradeofconcrete"
        Me.txtgradeofconcrete.Size = New System.Drawing.Size(121, 20)
        Me.txtgradeofconcrete.TabIndex = 22
        Me.txtgradeofconcrete.Text = "20"
        '
        'cmbtypeofsoil
        '
        Me.cmbtypeofsoil.FormattingEnabled = True
        Me.cmbtypeofsoil.Items.AddRange(New Object() {"Hard Soil", "Medium Soil", "Soft Soil"})
        Me.cmbtypeofsoil.Location = New System.Drawing.Point(128, 319)
        Me.cmbtypeofsoil.Name = "cmbtypeofsoil"
        Me.cmbtypeofsoil.Size = New System.Drawing.Size(121, 21)
        Me.cmbtypeofsoil.TabIndex = 21
        Me.cmbtypeofsoil.Text = "Hard Soil"
        '
        'cmbzone
        '
        Me.cmbzone.FormattingEnabled = True
        Me.cmbzone.Items.AddRange(New Object() {"II", "III", "IV", "V"})
        Me.cmbzone.Location = New System.Drawing.Point(128, 282)
        Me.cmbzone.Name = "cmbzone"
        Me.cmbzone.Size = New System.Drawing.Size(121, 21)
        Me.cmbzone.TabIndex = 20
        Me.cmbzone.Text = "II"
        '
        'txtbaseslab
        '
        Me.txtbaseslab.Location = New System.Drawing.Point(128, 244)
        Me.txtbaseslab.Name = "txtbaseslab"
        Me.txtbaseslab.Size = New System.Drawing.Size(121, 20)
        Me.txtbaseslab.TabIndex = 19
        Me.txtbaseslab.Text = "0.5"
        '
        'txtwallthick
        '
        Me.txtwallthick.Location = New System.Drawing.Point(127, 205)
        Me.txtwallthick.Name = "txtwallthick"
        Me.txtwallthick.Size = New System.Drawing.Size(121, 20)
        Me.txtwallthick.TabIndex = 18
        Me.txtwallthick.Text = "0.4"
        '
        'txtfreeboard
        '
        Me.txtfreeboard.Location = New System.Drawing.Point(127, 170)
        Me.txtfreeboard.Name = "txtfreeboard"
        Me.txtfreeboard.Size = New System.Drawing.Size(121, 20)
        Me.txtfreeboard.TabIndex = 17
        Me.txtfreeboard.Text = "0.25"
        '
        'txtheight
        '
        Me.txtheight.Location = New System.Drawing.Point(128, 134)
        Me.txtheight.Name = "txtheight"
        Me.txtheight.Size = New System.Drawing.Size(121, 20)
        Me.txtheight.TabIndex = 16
        Me.txtheight.Text = "2"
        '
        'txtbreadth
        '
        Me.txtbreadth.Location = New System.Drawing.Point(129, 96)
        Me.txtbreadth.Name = "txtbreadth"
        Me.txtbreadth.Size = New System.Drawing.Size(121, 20)
        Me.txtbreadth.TabIndex = 15
        Me.txtbreadth.Text = "5"
        '
        'txtlength
        '
        Me.txtlength.Location = New System.Drawing.Point(129, 64)
        Me.txtlength.Name = "txtlength"
        Me.txtlength.Size = New System.Drawing.Size(121, 20)
        Me.txtlength.TabIndex = 14
        Me.txtlength.Text = "10"
        '
        'txtCapacity
        '
        Me.txtCapacity.Location = New System.Drawing.Point(129, 30)
        Me.txtCapacity.Name = "txtCapacity"
        Me.txtCapacity.Size = New System.Drawing.Size(121, 20)
        Me.txtCapacity.TabIndex = 13
        Me.txtCapacity.Text = "600"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(76, 67)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(46, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Length :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(72, 100)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(50, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Breadth :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(78, 137)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Height :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(54, 173)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Free Board  :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(36, 208)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Wall Thickness :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(84, 286)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Zone :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(53, 322)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Type of Soil :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(63, 247)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Base slab :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 398)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Grade of Steel :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(22, 360)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Grade of Concrete :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Capacity of Tank :"
        '
        'btnSeismic
        '
        Me.btnSeismic.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSeismic.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeismic.Location = New System.Drawing.Point(174, 30)
        Me.btnSeismic.Name = "btnSeismic"
        Me.btnSeismic.Size = New System.Drawing.Size(128, 31)
        Me.btnSeismic.TabIndex = 9
        Me.btnSeismic.Text = "SEISMIC"
        Me.btnSeismic.UseVisualStyleBackColor = False
        Me.btnSeismic.Visible = False
        '
        'btnRCC
        '
        Me.btnRCC.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnRCC.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRCC.Location = New System.Drawing.Point(348, 30)
        Me.btnRCC.Name = "btnRCC"
        Me.btnRCC.Size = New System.Drawing.Size(128, 31)
        Me.btnRCC.TabIndex = 10
        Me.btnRCC.Text = "RCC"
        Me.btnRCC.UseVisualStyleBackColor = False
        Me.btnRCC.Visible = False
        '
        'btnSummary
        '
        Me.btnSummary.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSummary.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSummary.Location = New System.Drawing.Point(520, 30)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(128, 31)
        Me.btnSummary.TabIndex = 11
        Me.btnSummary.Text = "SUMMARY"
        Me.btnSummary.UseVisualStyleBackColor = False
        Me.btnSummary.Visible = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnDataSheet)
        Me.GroupBox4.Controls.Add(Me.btnSeismic)
        Me.GroupBox4.Controls.Add(Me.btnSummary)
        Me.GroupBox4.Controls.Add(Me.btnRCC)
        Me.GroupBox4.Location = New System.Drawing.Point(50, 577)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(689, 87)
        Me.GroupBox4.TabIndex = 12
        Me.GroupBox4.TabStop = False
        '
        'btnDataSheet
        '
        Me.btnDataSheet.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnDataSheet.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataSheet.Location = New System.Drawing.Point(25, 31)
        Me.btnDataSheet.Name = "btnDataSheet"
        Me.btnDataSheet.Size = New System.Drawing.Size(128, 31)
        Me.btnDataSheet.TabIndex = 12
        Me.btnDataSheet.Text = "Data Sheet"
        Me.btnDataSheet.UseVisualStyleBackColor = False
        Me.btnDataSheet.Visible = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(256, 34)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(27, 13)
        Me.Label25.TabIndex = 26
        Me.Label25.Text = "cum"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(256, 67)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(15, 13)
        Me.Label26.TabIndex = 27
        Me.Label26.Text = "m"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(256, 100)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(15, 13)
        Me.Label27.TabIndex = 28
        Me.Label27.Text = "m"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(254, 248)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(15, 13)
        Me.Label28.TabIndex = 29
        Me.Label28.Text = "m"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(254, 212)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(15, 13)
        Me.Label29.TabIndex = 30
        Me.Label29.Text = "m"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(254, 173)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(15, 13)
        Me.Label30.TabIndex = 31
        Me.Label30.Text = "m"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(256, 138)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(15, 13)
        Me.Label31.TabIndex = 32
        Me.Label31.Text = "m"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(234, 27)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(46, 13)
        Me.Label32.TabIndex = 36
        Me.Label32.Text = "kN/cum"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(233, 137)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(46, 13)
        Me.Label35.TabIndex = 37
        Me.Label35.Text = "kN/cum"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(234, 204)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(45, 13)
        Me.Label36.TabIndex = 38
        Me.Label36.Text = "kN/sqm"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(233, 243)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(40, 13)
        Me.Label37.TabIndex = 39
        Me.Label37.Text = "degree"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(269, 43)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(23, 13)
        Me.Label38.TabIndex = 36
        Me.Label38.Text = "mm"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(270, 117)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(23, 13)
        Me.Label39.TabIndex = 40
        Me.Label39.Text = "mm"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(269, 82)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(23, 13)
        Me.Label40.TabIndex = 41
        Me.Label40.Text = "mm"
        '
        'frmRectangularTankData
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(781, 676)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label24)
        Me.Name = "frmRectangularTankData"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MTech ""Tank Analysis""  - Rectangular Tank"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveRectData As System.Windows.Forms.Button
    Friend WithEvents txtDistributionBar As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtPrimaryBar As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtMainBar As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtangleofrepose As System.Windows.Forms.TextBox
    Friend WithEvents txtSBC As System.Windows.Forms.TextBox
    Friend WithEvents txtfy As System.Windows.Forms.TextBox
    Friend WithEvents txtdensityofwater As System.Windows.Forms.TextBox
    Friend WithEvents txtvoidratio As System.Windows.Forms.TextBox
    Friend WithEvents txtspecificgravity As System.Windows.Forms.TextBox
    Friend WithEvents txtDrydensity As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtgradeofsteel As System.Windows.Forms.TextBox
    Friend WithEvents txtgradeofconcrete As System.Windows.Forms.TextBox
    Friend WithEvents cmbtypeofsoil As System.Windows.Forms.ComboBox
    Friend WithEvents cmbzone As System.Windows.Forms.ComboBox
    Friend WithEvents txtbaseslab As System.Windows.Forms.TextBox
    Friend WithEvents txtwallthick As System.Windows.Forms.TextBox
    Friend WithEvents txtfreeboard As System.Windows.Forms.TextBox
    Friend WithEvents txtheight As System.Windows.Forms.TextBox
    Friend WithEvents txtbreadth As System.Windows.Forms.TextBox
    Friend WithEvents txtlength As System.Windows.Forms.TextBox
    Friend WithEvents txtCapacity As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnSeismic As System.Windows.Forms.Button
    Friend WithEvents btnRCC As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnDataSheet As System.Windows.Forms.Button
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
End Class
