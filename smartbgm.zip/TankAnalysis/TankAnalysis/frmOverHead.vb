﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmOverHead
    Dim xlApp As New Excel.Application
    Dim xlWorkBook As Excel.Workbook

    Dim xlAppNew As New Excel.Application
    Dim xlWorkBookNew As Excel.Workbook

    Dim dt As String
    Dim filename As String

  
    Private Sub btnSaveOverheadData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveOverheadData.Click
        '.....Open the original complete excel file and save as
        xlWorkBook = xlApp.Workbooks.Open("D:\TankAnalysis\complete.xlsx")
        dt = Now.Day & "_" & Now.Month & "_" & Now.Year & "_" & Now.Hour & "_" & Now.Minute & "_" & Now.Second
        filename = "D:\TankAnalysis\SavedFiles\" & gbltanktype & "_" & dt & ".xlsx"
        xlWorkBook.SaveAs(Filename:=filename)
        xlWorkBook.Close()
        xlApp.Quit()

        '...open the new file and save data from the vb.net form to excel
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)

        xlWorkBookNew.Sheets(15).Cells(3, 7) = txtCapacity.Text
        xlWorkBookNew.Sheets(15).Cells(4, 7) = txtInternalDiameter.Text
        xlWorkBookNew.Sheets(15).Cells(5, 7) = txtwallthickness.Text
        xlWorkBookNew.Sheets(15).Cells(6, 7) = txthieghtoftank.Text
        xlWorkBookNew.Sheets(15).Cells(7, 7) = txtfreeboard.Text
        xlWorkBookNew.Sheets(15).Cells(8, 7) = cmbNoofcolumns.Text
        xlWorkBookNew.Sheets(15).Cells(9, 7) = txtdiameterofcolumn.Text
        xlWorkBookNew.Sheets(15).Cells(10, 7) = txtdistancebtwncolumns.Text
        xlWorkBookNew.Sheets(15).Cells(11, 7) = txtnooflevels.Text
        xlWorkBookNew.Sheets(15).Cells(12, 7) = txtlowersupplylevel.Text
        xlWorkBookNew.Sheets(15).Cells(13, 7) = txtcentertocenterdistance.Text
        xlWorkBookNew.Sheets(15).Cells(14, 7) = txtdeptoffooting.Text
        xlWorkBookNew.Sheets(15).Cells(15, 7) = cmbtypeofsoil.Text
        xlWorkBookNew.Sheets(15).Cells(16, 7) = cmbzone.Text
        xlWorkBookNew.Sheets(15).Cells(17, 7) = txtgradeofconcreete.Text
        xlWorkBookNew.Sheets(15).Cells(18, 7) = txtgradeofsteel.Text
        xlWorkBookNew.Sheets(15).Cells(19, 7) = txtdensityofconcrete.Text
        xlWorkBookNew.Sheets(15).Cells(20, 7) = txtheightoftower.Text
        xlWorkBookNew.Sheets(15).Cells(21, 7) = txtliveload.Text
        xlWorkBookNew.Sheets(15).Cells(22, 7) = txtintensityofwind.Text
        xlWorkBookNew.Sheets(15).Cells(23, 7) = txtresistancetocraking.Text
        xlWorkBookNew.Sheets(15).Cells(24, 7) = txtnominalcover.Text
        xlWorkBookNew.Sheets(15).Cells(25, 7) = txtdepthbydiameterratio.Text
        xlWorkBookNew.Sheets(15).Cells(26, 7) = txtfinishesload.Text
        xlWorkBookNew.Sheets(15).Cells(27, 7) = txtwtofwater.Text
        xlWorkBookNew.Sheets(15).Cells(28, 7) = txtbearingcapacity.Text
        xlWorkBookNew.Sheets(15).Cells(29, 7) = txtQ.Text
        xlWorkBookNew.Sheets(15).Cells(30, 7) = txttensilestress.Text
        xlWorkBookNew.Sheets(15).Cells(31, 7) = txtscb.Text
        xlWorkBookNew.Sheets(15).Cells(32, 7) = txtefectivecover.Text
        xlWorkBookNew.Sheets(15).Cells(33, 7) = txtspacingofbracing.Text
        xlWorkBookNew.Sheets(15).Cells(34, 7) = txtbottomdia.Text
        xlWorkBookNew.Sheets(15).Cells(35, 7) = txtdeflection.Text
        xlWorkBookNew.Sheets(15).Cells(36, 7) = txtarbitaryload.Text

        xlWorkBookNew.Sheets(15).Cells(39, 4) = txtRoofSlab.Text
        xlWorkBookNew.Sheets(15).Cells(40, 4) = txtWall.Text
        xlWorkBookNew.Sheets(15).Cells(41, 4) = txtFloorslab.Text
        xlWorkBookNew.Sheets(15).Cells(42, 4) = txtgallery.Text
        xlWorkBookNew.Sheets(15).Cells(43, 4) = txtfloorbeams1.Text
        xlWorkBookNew.Sheets(15).Cells(43, 6) = txtfloorbeams2.Text
        xlWorkBookNew.Sheets(15).Cells(44, 4) = txtbraces1.Text
        xlWorkBookNew.Sheets(15).Cells(44, 6) = txtbraces2.Text
        xlWorkBookNew.Sheets(15).Cells(45, 4) = txtcolumns.Text

        xlWorkBookNew.Sheets(15).Cells(48, 7) = txtMainBar.Text
        xlWorkBookNew.Sheets(15).Cells(49, 7) = txtPrimaryBar.Text
        xlWorkBookNew.Sheets(15).Cells(50, 7) = txtSecondaryBar.Text
        xlWorkBookNew.Sheets(15).Cells(51, 7) = txtDistributionBar.Text


        xlWorkBookNew.Close(SaveChanges:=True)
        xlAppNew.Quit()
        MsgBox("Data saved successfully", MsgBoxStyle.Information)

        btnRCC.Visible = True
        btnSeismic.Visible = True
        btnSummary.Visible = True
        btnDataSheet.Visible = True
    End Sub

    Private Sub btnSeismic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSeismic.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Seismic.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(16).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(16)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnRCC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRCC.Click
        Dim pdf_filename_RCC As String
        pdf_filename_RCC = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_RCC.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(17).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(17)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_RCC, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnSummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSummary.Click
        Dim pdf_filename_Summary As String
        pdf_filename_Summary = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Summary.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(18).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(18)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_Summary, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnDataSheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataSheet.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_DataSheet.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(15).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(15)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub txtNoofcolumns_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Function cmbNoofcolumns() As Object
        Throw New NotImplementedException
    End Function

    Private Sub GroupBox3_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox3.Enter

    End Sub
End Class