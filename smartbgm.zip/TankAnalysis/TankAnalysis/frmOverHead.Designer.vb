﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOverHead
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.cmbtypeofsoil = New System.Windows.Forms.ComboBox()
        Me.cmbzone = New System.Windows.Forms.ComboBox()
        Me.txtdensityofconcrete = New System.Windows.Forms.TextBox()
        Me.txtgradeofsteel = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtgradeofconcreete = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtdeptoffooting = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtcentertocenterdistance = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtlowersupplylevel = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtnooflevels = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtdistancebtwncolumns = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtdiameterofcolumn = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtfreeboard = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txthieghtoftank = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtwallthickness = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtInternalDiameter = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCapacity = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.txtarbitaryload = New System.Windows.Forms.TextBox()
        Me.txtdeflection = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtbottomdia = New System.Windows.Forms.TextBox()
        Me.txtspacingofbracing = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtefectivecover = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtscb = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txttensilestress = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtQ = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtbearingcapacity = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtwtofwater = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtfinishesload = New System.Windows.Forms.TextBox()
        Me.txtdepthbydiameterratio = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtnominalcover = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtresistancetocraking = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtintensityofwind = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtliveload = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtheightoftower = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtbraces2 = New System.Windows.Forms.TextBox()
        Me.txtfloorbeams2 = New System.Windows.Forms.TextBox()
        Me.txtcolumns = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtbraces1 = New System.Windows.Forms.TextBox()
        Me.txtfloorbeams1 = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtgallery = New System.Windows.Forms.TextBox()
        Me.txtFloorslab = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtWall = New System.Windows.Forms.TextBox()
        Me.txtRoofSlab = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtSecondaryBar = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.btnSaveOverheadData = New System.Windows.Forms.Button()
        Me.txtDistributionBar = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txtPrimaryBar = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.txtMainBar = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.btnDataSheet = New System.Windows.Forms.Button()
        Me.btnSeismic = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.btnRCC = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Courier New", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Blue
        Me.Label24.Location = New System.Drawing.Point(347, -4)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(262, 36)
        Me.Label24.TabIndex = 5
        Me.Label24.Text = "Overhead Tank"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label60)
        Me.GroupBox1.Controls.Add(Me.Label59)
        Me.GroupBox1.Controls.Add(Me.Label58)
        Me.GroupBox1.Controls.Add(Me.Label57)
        Me.GroupBox1.Controls.Add(Me.Label56)
        Me.GroupBox1.Controls.Add(Me.Label55)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Controls.Add(Me.Label54)
        Me.GroupBox1.Controls.Add(Me.Label53)
        Me.GroupBox1.Controls.Add(Me.Label51)
        Me.GroupBox1.Controls.Add(Me.Label50)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Controls.Add(Me.cmbtypeofsoil)
        Me.GroupBox1.Controls.Add(Me.cmbzone)
        Me.GroupBox1.Controls.Add(Me.txtdensityofconcrete)
        Me.GroupBox1.Controls.Add(Me.txtgradeofsteel)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.txtgradeofconcreete)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtdeptoffooting)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.txtcentertocenterdistance)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.txtlowersupplylevel)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtnooflevels)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtdistancebtwncolumns)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtdiameterofcolumn)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtfreeboard)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txthieghtoftank)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtwallthickness)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtInternalDiameter)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtCapacity)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 35)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(367, 570)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Seismic Data"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(310, 88)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(15, 13)
        Me.Label51.TabIndex = 34
        Me.Label51.Text = "m"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(309, 58)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(15, 13)
        Me.Label50.TabIndex = 33
        Me.Label50.Text = "m"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(310, 23)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(27, 13)
        Me.Label49.TabIndex = 32
        Me.Label49.Text = "cum"
        '
        'cmbtypeofsoil
        '
        Me.cmbtypeofsoil.FormattingEnabled = True
        Me.cmbtypeofsoil.Items.AddRange(New Object() {"Hard Soil", "Medium Soil", "Soft Soil"})
        Me.cmbtypeofsoil.Location = New System.Drawing.Point(201, 406)
        Me.cmbtypeofsoil.Name = "cmbtypeofsoil"
        Me.cmbtypeofsoil.Size = New System.Drawing.Size(102, 21)
        Me.cmbtypeofsoil.TabIndex = 31
        Me.cmbtypeofsoil.Text = "Hard Soil"
        '
        'cmbzone
        '
        Me.cmbzone.FormattingEnabled = True
        Me.cmbzone.Items.AddRange(New Object() {"II", "III", "IV", "V"})
        Me.cmbzone.Location = New System.Drawing.Point(201, 439)
        Me.cmbzone.Name = "cmbzone"
        Me.cmbzone.Size = New System.Drawing.Size(102, 21)
        Me.cmbzone.TabIndex = 30
        Me.cmbzone.Text = "II"
        '
        'txtdensityofconcrete
        '
        Me.txtdensityofconcrete.Location = New System.Drawing.Point(201, 532)
        Me.txtdensityofconcrete.Name = "txtdensityofconcrete"
        Me.txtdensityofconcrete.Size = New System.Drawing.Size(99, 20)
        Me.txtdensityofconcrete.TabIndex = 28
        Me.txtdensityofconcrete.Text = "25"
        '
        'txtgradeofsteel
        '
        Me.txtgradeofsteel.Location = New System.Drawing.Point(201, 502)
        Me.txtgradeofsteel.Name = "txtgradeofsteel"
        Me.txtgradeofsteel.Size = New System.Drawing.Size(99, 20)
        Me.txtgradeofsteel.TabIndex = 29
        Me.txtgradeofsteel.Text = "415"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(86, 538)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(105, 13)
        Me.Label32.TabIndex = 26
        Me.Label32.Text = "Density Of Concrete:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(99, 508)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(80, 13)
        Me.Label33.TabIndex = 27
        Me.Label33.Text = "Grade Of Steel:"
        '
        'txtgradeofconcreete
        '
        Me.txtgradeofconcreete.Location = New System.Drawing.Point(201, 470)
        Me.txtgradeofconcreete.Name = "txtgradeofconcreete"
        Me.txtgradeofconcreete.Size = New System.Drawing.Size(102, 20)
        Me.txtgradeofconcreete.TabIndex = 15
        Me.txtgradeofconcreete.Text = "20"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(86, 476)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(99, 13)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Grade Of Concrete:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(135, 446)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(35, 13)
        Me.Label14.TabIndex = 14
        Me.Label14.Text = "Zone:"
        '
        'txtdeptoffooting
        '
        Me.txtdeptoffooting.Location = New System.Drawing.Point(201, 380)
        Me.txtdeptoffooting.Name = "txtdeptoffooting"
        Me.txtdeptoffooting.Size = New System.Drawing.Size(102, 20)
        Me.txtdeptoffooting.TabIndex = 15
        Me.txtdeptoffooting.Text = "2.5"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(102, 413)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(68, 13)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "Type Of Soil:"
        '
        'txtcentertocenterdistance
        '
        Me.txtcentertocenterdistance.Location = New System.Drawing.Point(201, 348)
        Me.txtcentertocenterdistance.Name = "txtcentertocenterdistance"
        Me.txtcentertocenterdistance.Size = New System.Drawing.Size(102, 20)
        Me.txtcentertocenterdistance.TabIndex = 15
        Me.txtcentertocenterdistance.Text = "3"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 382)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(184, 13)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Depth Of Footing From Ground Level:"
        '
        'txtlowersupplylevel
        '
        Me.txtlowersupplylevel.Location = New System.Drawing.Point(201, 315)
        Me.txtlowersupplylevel.Name = "txtlowersupplylevel"
        Me.txtlowersupplylevel.Size = New System.Drawing.Size(102, 20)
        Me.txtlowersupplylevel.TabIndex = 15
        Me.txtlowersupplylevel.Text = "12"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 350)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(162, 13)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "C/C Distance Between Columns:"
        '
        'txtnooflevels
        '
        Me.txtnooflevels.Location = New System.Drawing.Point(201, 283)
        Me.txtnooflevels.Name = "txtnooflevels"
        Me.txtnooflevels.Size = New System.Drawing.Size(102, 20)
        Me.txtnooflevels.TabIndex = 15
        Me.txtnooflevels.Text = "4"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 317)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(159, 13)
        Me.Label10.TabIndex = 14
        Me.Label10.Text = "Lowest Supply Level Above GL:"
        '
        'txtdistancebtwncolumns
        '
        Me.txtdistancebtwncolumns.Location = New System.Drawing.Point(201, 252)
        Me.txtdistancebtwncolumns.Name = "txtdistancebtwncolumns"
        Me.txtdistancebtwncolumns.Size = New System.Drawing.Size(102, 20)
        Me.txtdistancebtwncolumns.TabIndex = 25
        Me.txtdistancebtwncolumns.Text = "3"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(95, 289)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "No. Of Levels:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 254)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(162, 13)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "C/C Distance Between Columns:"
        '
        'txtdiameterofcolumn
        '
        Me.txtdiameterofcolumn.Location = New System.Drawing.Point(201, 217)
        Me.txtdiameterofcolumn.Name = "txtdiameterofcolumn"
        Me.txtdiameterofcolumn.Size = New System.Drawing.Size(102, 20)
        Me.txtdiameterofcolumn.TabIndex = 15
        Me.txtdiameterofcolumn.Text = "450"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(86, 220)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Diameter Of Column:"
        '
        'txtfreeboard
        '
        Me.txtfreeboard.Location = New System.Drawing.Point(201, 154)
        Me.txtfreeboard.Name = "txtfreeboard"
        Me.txtfreeboard.Size = New System.Drawing.Size(102, 20)
        Me.txtfreeboard.TabIndex = 23
        Me.txtfreeboard.Text = "0.3"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(86, 189)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "No. Of Columns:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(111, 156)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 22
        Me.Label5.Text = "Freeboard:"
        '
        'txthieghtoftank
        '
        Me.txthieghtoftank.Location = New System.Drawing.Point(201, 118)
        Me.txthieghtoftank.Name = "txthieghtoftank"
        Me.txthieghtoftank.Size = New System.Drawing.Size(102, 20)
        Me.txthieghtoftank.TabIndex = 21
        Me.txthieghtoftank.Text = "3.85"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(86, 121)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Height Of Tank:"
        '
        'txtwallthickness
        '
        Me.txtwallthickness.Location = New System.Drawing.Point(201, 83)
        Me.txtwallthickness.Name = "txtwallthickness"
        Me.txtwallthickness.Size = New System.Drawing.Size(102, 20)
        Me.txtwallthickness.TabIndex = 19
        Me.txtwallthickness.Text = "0.2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(86, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Wall Thickness:"
        '
        'txtInternalDiameter
        '
        Me.txtInternalDiameter.Location = New System.Drawing.Point(201, 52)
        Me.txtInternalDiameter.Name = "txtInternalDiameter"
        Me.txtInternalDiameter.Size = New System.Drawing.Size(102, 20)
        Me.txtInternalDiameter.TabIndex = 17
        Me.txtInternalDiameter.Text = "9"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(86, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 13)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Internal Diameter :"
        '
        'txtCapacity
        '
        Me.txtCapacity.Location = New System.Drawing.Point(201, 19)
        Me.txtCapacity.Name = "txtCapacity"
        Me.txtCapacity.Size = New System.Drawing.Size(102, 20)
        Me.txtCapacity.TabIndex = 15
        Me.txtCapacity.Text = "200"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(86, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Capacity of Tank :"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label91)
        Me.GroupBox2.Controls.Add(Me.Label90)
        Me.GroupBox2.Controls.Add(Me.Label87)
        Me.GroupBox2.Controls.Add(Me.Label88)
        Me.GroupBox2.Controls.Add(Me.Label86)
        Me.GroupBox2.Controls.Add(Me.Label85)
        Me.GroupBox2.Controls.Add(Me.Label84)
        Me.GroupBox2.Controls.Add(Me.Label83)
        Me.GroupBox2.Controls.Add(Me.Label82)
        Me.GroupBox2.Controls.Add(Me.Label81)
        Me.GroupBox2.Controls.Add(Me.Label67)
        Me.GroupBox2.Controls.Add(Me.Label66)
        Me.GroupBox2.Controls.Add(Me.Label65)
        Me.GroupBox2.Controls.Add(Me.Label64)
        Me.GroupBox2.Controls.Add(Me.Label63)
        Me.GroupBox2.Controls.Add(Me.Label62)
        Me.GroupBox2.Controls.Add(Me.Label61)
        Me.GroupBox2.Controls.Add(Me.Label52)
        Me.GroupBox2.Controls.Add(Me.txtarbitaryload)
        Me.GroupBox2.Controls.Add(Me.txtdeflection)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.txtbottomdia)
        Me.GroupBox2.Controls.Add(Me.txtspacingofbracing)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.txtefectivecover)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.txtscb)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.txttensilestress)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.txtQ)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.txtbearingcapacity)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.txtwtofwater)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.txtfinishesload)
        Me.GroupBox2.Controls.Add(Me.txtdepthbydiameterratio)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.txtnominalcover)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.txtresistancetocraking)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.txtintensityofwind)
        Me.GroupBox2.Controls.Add(Me.Label29)
        Me.GroupBox2.Controls.Add(Me.txtliveload)
        Me.GroupBox2.Controls.Add(Me.Label30)
        Me.GroupBox2.Controls.Add(Me.txtheightoftower)
        Me.GroupBox2.Controls.Add(Me.Label31)
        Me.GroupBox2.Location = New System.Drawing.Point(385, 35)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(283, 570)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Seismic Data"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.Location = New System.Drawing.Point(24, 382)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(17, 15)
        Me.Label52.TabIndex = 30
        Me.Label52.Text = "cb"
        '
        'txtarbitaryload
        '
        Me.txtarbitaryload.Location = New System.Drawing.Point(150, 535)
        Me.txtarbitaryload.Name = "txtarbitaryload"
        Me.txtarbitaryload.Size = New System.Drawing.Size(74, 20)
        Me.txtarbitaryload.TabIndex = 28
        Me.txtarbitaryload.Text = "10"
        '
        'txtdeflection
        '
        Me.txtdeflection.Location = New System.Drawing.Point(150, 505)
        Me.txtdeflection.Name = "txtdeflection"
        Me.txtdeflection.Size = New System.Drawing.Size(74, 20)
        Me.txtdeflection.TabIndex = 29
        Me.txtdeflection.Text = "0.0033"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(6, 538)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(125, 13)
        Me.Label34.TabIndex = 26
        Me.Label34.Text = "Arbitrary load on Staging:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(6, 508)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(55, 13)
        Me.Label35.TabIndex = 27
        Me.Label35.Text = "Deflection"
        '
        'txtbottomdia
        '
        Me.txtbottomdia.Location = New System.Drawing.Point(150, 469)
        Me.txtbottomdia.Name = "txtbottomdia"
        Me.txtbottomdia.Size = New System.Drawing.Size(74, 20)
        Me.txtbottomdia.TabIndex = 15
        Me.txtbottomdia.Text = "4.3"
        '
        'txtspacingofbracing
        '
        Me.txtspacingofbracing.Location = New System.Drawing.Point(150, 439)
        Me.txtspacingofbracing.Name = "txtspacingofbracing"
        Me.txtspacingofbracing.Size = New System.Drawing.Size(74, 20)
        Me.txtspacingofbracing.TabIndex = 15
        Me.txtspacingofbracing.Text = "4"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 472)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(141, 13)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "Bottom dia of Circular Girder:"
        '
        'txtefectivecover
        '
        Me.txtefectivecover.Location = New System.Drawing.Point(150, 409)
        Me.txtefectivecover.Name = "txtefectivecover"
        Me.txtefectivecover.Size = New System.Drawing.Size(74, 20)
        Me.txtefectivecover.TabIndex = 15
        Me.txtefectivecover.Text = "35"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(6, 442)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(100, 13)
        Me.Label17.TabIndex = 14
        Me.Label17.Text = "Spacing of Bracing:"
        '
        'txtscb
        '
        Me.txtscb.Location = New System.Drawing.Point(150, 379)
        Me.txtscb.Name = "txtscb"
        Me.txtscb.Size = New System.Drawing.Size(74, 20)
        Me.txtscb.TabIndex = 15
        Me.txtscb.Text = "1.7"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 412)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 13)
        Me.Label18.TabIndex = 14
        Me.Label18.Text = "Effective Cover :"
        '
        'txttensilestress
        '
        Me.txttensilestress.Location = New System.Drawing.Point(150, 347)
        Me.txttensilestress.Name = "txttensilestress"
        Me.txttensilestress.Size = New System.Drawing.Size(74, 20)
        Me.txttensilestress.TabIndex = 15
        Me.txttensilestress.Text = "130"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label19.Location = New System.Drawing.Point(11, 382)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(13, 13)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "s"
        '
        'txtQ
        '
        Me.txtQ.Location = New System.Drawing.Point(150, 314)
        Me.txtQ.Name = "txtQ"
        Me.txtQ.Size = New System.Drawing.Size(74, 20)
        Me.txtQ.TabIndex = 15
        Me.txtQ.Text = "0.42"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(6, 350)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(108, 13)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "Tensile stress (Tank):"
        '
        'txtbearingcapacity
        '
        Me.txtbearingcapacity.Location = New System.Drawing.Point(150, 282)
        Me.txtbearingcapacity.Name = "txtbearingcapacity"
        Me.txtbearingcapacity.Size = New System.Drawing.Size(74, 20)
        Me.txtbearingcapacity.TabIndex = 15
        Me.txtbearingcapacity.Text = "170"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(6, 317)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(18, 13)
        Me.Label21.TabIndex = 14
        Me.Label21.Text = "Q:"
        '
        'txtwtofwater
        '
        Me.txtwtofwater.Location = New System.Drawing.Point(150, 251)
        Me.txtwtofwater.Name = "txtwtofwater"
        Me.txtwtofwater.Size = New System.Drawing.Size(74, 20)
        Me.txtwtofwater.TabIndex = 25
        Me.txtwtofwater.Text = "10"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(6, 285)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(125, 13)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "Bearing capcity of earth :"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(6, 254)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(65, 13)
        Me.Label23.TabIndex = 24
        Me.Label23.Text = "wt of water :"
        '
        'txtfinishesload
        '
        Me.txtfinishesload.Location = New System.Drawing.Point(150, 216)
        Me.txtfinishesload.Name = "txtfinishesload"
        Me.txtfinishesload.Size = New System.Drawing.Size(74, 20)
        Me.txtfinishesload.TabIndex = 15
        Me.txtfinishesload.Text = "0.1"
        '
        'txtdepthbydiameterratio
        '
        Me.txtdepthbydiameterratio.Location = New System.Drawing.Point(150, 185)
        Me.txtdepthbydiameterratio.Name = "txtdepthbydiameterratio"
        Me.txtdepthbydiameterratio.Size = New System.Drawing.Size(74, 20)
        Me.txtdepthbydiameterratio.TabIndex = 15
        Me.txtdepthbydiameterratio.Text = "1"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(6, 219)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(74, 13)
        Me.Label25.TabIndex = 14
        Me.Label25.Text = "Finishes load :"
        '
        'txtnominalcover
        '
        Me.txtnominalcover.Location = New System.Drawing.Point(150, 153)
        Me.txtnominalcover.Name = "txtnominalcover"
        Me.txtnominalcover.Size = New System.Drawing.Size(74, 20)
        Me.txtnominalcover.TabIndex = 23
        Me.txtnominalcover.Text = "25"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(6, 188)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(118, 13)
        Me.Label26.TabIndex = 14
        Me.Label26.Text = "Depth / diameter Ratio:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(6, 156)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(85, 13)
        Me.Label27.TabIndex = 22
        Me.Label27.Text = "Nominal  Cover :"
        '
        'txtresistancetocraking
        '
        Me.txtresistancetocraking.Location = New System.Drawing.Point(150, 117)
        Me.txtresistancetocraking.Name = "txtresistancetocraking"
        Me.txtresistancetocraking.Size = New System.Drawing.Size(74, 20)
        Me.txtresistancetocraking.TabIndex = 21
        Me.txtresistancetocraking.Text = "1.2"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(6, 120)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(119, 13)
        Me.Label28.TabIndex = 20
        Me.Label28.Text = "Resistance to cracking "
        '
        'txtintensityofwind
        '
        Me.txtintensityofwind.Location = New System.Drawing.Point(150, 82)
        Me.txtintensityofwind.Name = "txtintensityofwind"
        Me.txtintensityofwind.Size = New System.Drawing.Size(74, 20)
        Me.txtintensityofwind.TabIndex = 19
        Me.txtintensityofwind.Text = "1.5"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(6, 85)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(89, 13)
        Me.Label29.TabIndex = 18
        Me.Label29.Text = "Intensity of wind :"
        '
        'txtliveload
        '
        Me.txtliveload.Location = New System.Drawing.Point(150, 51)
        Me.txtliveload.Name = "txtliveload"
        Me.txtliveload.Size = New System.Drawing.Size(74, 20)
        Me.txtliveload.TabIndex = 17
        Me.txtliveload.Text = "1.5"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(6, 54)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(99, 13)
        Me.Label30.TabIndex = 16
        Me.Label30.Text = "Live load on Dome:"
        '
        'txtheightoftower
        '
        Me.txtheightoftower.Location = New System.Drawing.Point(150, 18)
        Me.txtheightoftower.Name = "txtheightoftower"
        Me.txtheightoftower.Size = New System.Drawing.Size(74, 20)
        Me.txtheightoftower.TabIndex = 15
        Me.txtheightoftower.Text = "21"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(6, 21)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(128, 13)
        Me.Label31.TabIndex = 14
        Me.Label31.Text = "Height of tower from G.L.:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label89)
        Me.GroupBox3.Controls.Add(Me.Label80)
        Me.GroupBox3.Controls.Add(Me.Label79)
        Me.GroupBox3.Controls.Add(Me.Label78)
        Me.GroupBox3.Controls.Add(Me.Label77)
        Me.GroupBox3.Controls.Add(Me.Label76)
        Me.GroupBox3.Controls.Add(Me.Label75)
        Me.GroupBox3.Controls.Add(Me.Label74)
        Me.GroupBox3.Controls.Add(Me.Label73)
        Me.GroupBox3.Controls.Add(Me.Label72)
        Me.GroupBox3.Controls.Add(Me.Label48)
        Me.GroupBox3.Controls.Add(Me.Label47)
        Me.GroupBox3.Controls.Add(Me.txtbraces2)
        Me.GroupBox3.Controls.Add(Me.txtfloorbeams2)
        Me.GroupBox3.Controls.Add(Me.txtcolumns)
        Me.GroupBox3.Controls.Add(Me.Label43)
        Me.GroupBox3.Controls.Add(Me.txtbraces1)
        Me.GroupBox3.Controls.Add(Me.txtfloorbeams1)
        Me.GroupBox3.Controls.Add(Me.Label40)
        Me.GroupBox3.Controls.Add(Me.Label41)
        Me.GroupBox3.Controls.Add(Me.txtgallery)
        Me.GroupBox3.Controls.Add(Me.txtFloorslab)
        Me.GroupBox3.Controls.Add(Me.Label38)
        Me.GroupBox3.Controls.Add(Me.Label39)
        Me.GroupBox3.Controls.Add(Me.txtWall)
        Me.GroupBox3.Controls.Add(Me.txtRoofSlab)
        Me.GroupBox3.Controls.Add(Me.Label36)
        Me.GroupBox3.Controls.Add(Me.Label37)
        Me.GroupBox3.Location = New System.Drawing.Point(682, 43)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(270, 267)
        Me.GroupBox3.TabIndex = 27
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Components"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(164, 184)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(14, 13)
        Me.Label48.TabIndex = 35
        Me.Label48.Text = "X"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(162, 148)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(14, 13)
        Me.Label47.TabIndex = 34
        Me.Label47.Text = "X"
        '
        'txtbraces2
        '
        Me.txtbraces2.Location = New System.Drawing.Point(187, 179)
        Me.txtbraces2.Name = "txtbraces2"
        Me.txtbraces2.Size = New System.Drawing.Size(50, 20)
        Me.txtbraces2.TabIndex = 33
        Me.txtbraces2.Text = "450"
        '
        'txtfloorbeams2
        '
        Me.txtfloorbeams2.Location = New System.Drawing.Point(187, 144)
        Me.txtfloorbeams2.Name = "txtfloorbeams2"
        Me.txtfloorbeams2.Size = New System.Drawing.Size(50, 20)
        Me.txtfloorbeams2.TabIndex = 32
        Me.txtfloorbeams2.Text = "600"
        '
        'txtcolumns
        '
        Me.txtcolumns.Location = New System.Drawing.Point(107, 216)
        Me.txtcolumns.Name = "txtcolumns"
        Me.txtcolumns.Size = New System.Drawing.Size(87, 20)
        Me.txtcolumns.TabIndex = 31
        Me.txtcolumns.Text = "450"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(6, 219)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(50, 13)
        Me.Label43.TabIndex = 29
        Me.Label43.Text = "Columns:"
        '
        'txtbraces1
        '
        Me.txtbraces1.Location = New System.Drawing.Point(82, 180)
        Me.txtbraces1.Name = "txtbraces1"
        Me.txtbraces1.Size = New System.Drawing.Size(50, 20)
        Me.txtbraces1.TabIndex = 26
        Me.txtbraces1.Text = "300"
        '
        'txtfloorbeams1
        '
        Me.txtfloorbeams1.Location = New System.Drawing.Point(82, 147)
        Me.txtfloorbeams1.Name = "txtfloorbeams1"
        Me.txtfloorbeams1.Size = New System.Drawing.Size(50, 20)
        Me.txtfloorbeams1.TabIndex = 27
        Me.txtfloorbeams1.Text = "250"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(6, 183)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(43, 13)
        Me.Label40.TabIndex = 24
        Me.Label40.Text = "Braces:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(6, 150)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(68, 13)
        Me.Label41.TabIndex = 25
        Me.Label41.Text = "Floor Beams:"
        '
        'txtgallery
        '
        Me.txtgallery.Location = New System.Drawing.Point(107, 112)
        Me.txtgallery.Name = "txtgallery"
        Me.txtgallery.Size = New System.Drawing.Size(87, 20)
        Me.txtgallery.TabIndex = 22
        Me.txtgallery.Text = "110"
        '
        'txtFloorslab
        '
        Me.txtFloorslab.Location = New System.Drawing.Point(107, 82)
        Me.txtFloorslab.Name = "txtFloorslab"
        Me.txtFloorslab.Size = New System.Drawing.Size(87, 20)
        Me.txtFloorslab.TabIndex = 23
        Me.txtFloorslab.Text = "200"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(6, 115)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(42, 13)
        Me.Label38.TabIndex = 20
        Me.Label38.Text = "Gallery:"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(6, 85)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(57, 13)
        Me.Label39.TabIndex = 21
        Me.Label39.Text = "Floor Slab:"
        '
        'txtWall
        '
        Me.txtWall.Location = New System.Drawing.Point(107, 52)
        Me.txtWall.Name = "txtWall"
        Me.txtWall.Size = New System.Drawing.Size(87, 20)
        Me.txtWall.TabIndex = 18
        Me.txtWall.Text = "200"
        '
        'txtRoofSlab
        '
        Me.txtRoofSlab.Location = New System.Drawing.Point(107, 22)
        Me.txtRoofSlab.Name = "txtRoofSlab"
        Me.txtRoofSlab.Size = New System.Drawing.Size(87, 20)
        Me.txtRoofSlab.TabIndex = 19
        Me.txtRoofSlab.Text = "120"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(6, 55)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(31, 13)
        Me.Label36.TabIndex = 16
        Me.Label36.Text = "Wall:"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(6, 25)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(57, 13)
        Me.Label37.TabIndex = 17
        Me.Label37.Text = "Roof Slab:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label71)
        Me.GroupBox4.Controls.Add(Me.Label70)
        Me.GroupBox4.Controls.Add(Me.Label69)
        Me.GroupBox4.Controls.Add(Me.Label68)
        Me.GroupBox4.Controls.Add(Me.txtSecondaryBar)
        Me.GroupBox4.Controls.Add(Me.Label46)
        Me.GroupBox4.Controls.Add(Me.btnSaveOverheadData)
        Me.GroupBox4.Controls.Add(Me.txtDistributionBar)
        Me.GroupBox4.Controls.Add(Me.Label42)
        Me.GroupBox4.Controls.Add(Me.txtPrimaryBar)
        Me.GroupBox4.Controls.Add(Me.Label44)
        Me.GroupBox4.Controls.Add(Me.txtMainBar)
        Me.GroupBox4.Controls.Add(Me.Label45)
        Me.GroupBox4.Location = New System.Drawing.Point(682, 324)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(270, 270)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Diameter of Reinforcement Bars"
        '
        'txtSecondaryBar
        '
        Me.txtSecondaryBar.Location = New System.Drawing.Point(153, 114)
        Me.txtSecondaryBar.Name = "txtSecondaryBar"
        Me.txtSecondaryBar.Size = New System.Drawing.Size(55, 20)
        Me.txtSecondaryBar.TabIndex = 41
        Me.txtSecondaryBar.Text = "10"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(4, 152)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(141, 13)
        Me.Label46.TabIndex = 40
        Me.Label46.Text = "Diameter of Distribution Bar :"
        '
        'btnSaveOverheadData
        '
        Me.btnSaveOverheadData.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSaveOverheadData.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveOverheadData.Location = New System.Drawing.Point(13, 195)
        Me.btnSaveOverheadData.Name = "btnSaveOverheadData"
        Me.btnSaveOverheadData.Size = New System.Drawing.Size(247, 31)
        Me.btnSaveOverheadData.TabIndex = 5
        Me.btnSaveOverheadData.Text = "Save OverHead Data"
        Me.btnSaveOverheadData.UseVisualStyleBackColor = False
        '
        'txtDistributionBar
        '
        Me.txtDistributionBar.Location = New System.Drawing.Point(153, 149)
        Me.txtDistributionBar.Name = "txtDistributionBar"
        Me.txtDistributionBar.Size = New System.Drawing.Size(55, 20)
        Me.txtDistributionBar.TabIndex = 39
        Me.txtDistributionBar.Text = "10"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(2, 117)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(140, 13)
        Me.Label42.TabIndex = 34
        Me.Label42.Text = "Diameter of Secondary Bar :"
        '
        'txtPrimaryBar
        '
        Me.txtPrimaryBar.Location = New System.Drawing.Point(152, 75)
        Me.txtPrimaryBar.Name = "txtPrimaryBar"
        Me.txtPrimaryBar.Size = New System.Drawing.Size(55, 20)
        Me.txtPrimaryBar.TabIndex = 38
        Me.txtPrimaryBar.Text = "12"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(2, 78)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(122, 13)
        Me.Label44.TabIndex = 35
        Me.Label44.Text = "Diameter of primary Bar :"
        '
        'txtMainBar
        '
        Me.txtMainBar.Location = New System.Drawing.Point(152, 40)
        Me.txtMainBar.Name = "txtMainBar"
        Me.txtMainBar.Size = New System.Drawing.Size(55, 20)
        Me.txtMainBar.TabIndex = 37
        Me.txtMainBar.Text = "16"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(10, 43)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(111, 13)
        Me.Label45.TabIndex = 36
        Me.Label45.Text = "Diameter of main Bar :"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.btnDataSheet)
        Me.GroupBox5.Controls.Add(Me.btnSeismic)
        Me.GroupBox5.Controls.Add(Me.btnSummary)
        Me.GroupBox5.Controls.Add(Me.btnRCC)
        Me.GroupBox5.Location = New System.Drawing.Point(202, 608)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(708, 67)
        Me.GroupBox5.TabIndex = 36
        Me.GroupBox5.TabStop = False
        '
        'btnDataSheet
        '
        Me.btnDataSheet.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnDataSheet.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataSheet.Location = New System.Drawing.Point(32, 19)
        Me.btnDataSheet.Name = "btnDataSheet"
        Me.btnDataSheet.Size = New System.Drawing.Size(128, 31)
        Me.btnDataSheet.TabIndex = 12
        Me.btnDataSheet.Text = "Data Sheet"
        Me.btnDataSheet.UseVisualStyleBackColor = False
        Me.btnDataSheet.Visible = False
        '
        'btnSeismic
        '
        Me.btnSeismic.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSeismic.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeismic.Location = New System.Drawing.Point(190, 19)
        Me.btnSeismic.Name = "btnSeismic"
        Me.btnSeismic.Size = New System.Drawing.Size(128, 31)
        Me.btnSeismic.TabIndex = 9
        Me.btnSeismic.Text = "SEISMIC"
        Me.btnSeismic.UseVisualStyleBackColor = False
        Me.btnSeismic.Visible = False
        '
        'btnSummary
        '
        Me.btnSummary.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSummary.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSummary.Location = New System.Drawing.Point(536, 19)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(128, 31)
        Me.btnSummary.TabIndex = 11
        Me.btnSummary.Text = "SUMMARY"
        Me.btnSummary.UseVisualStyleBackColor = False
        Me.btnSummary.Visible = False
        '
        'btnRCC
        '
        Me.btnRCC.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnRCC.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRCC.Location = New System.Drawing.Point(364, 19)
        Me.btnRCC.Name = "btnRCC"
        Me.btnRCC.Size = New System.Drawing.Size(128, 31)
        Me.btnRCC.TabIndex = 10
        Me.btnRCC.Text = "RCC"
        Me.btnRCC.UseVisualStyleBackColor = False
        Me.btnRCC.Visible = False
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(310, 125)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(15, 13)
        Me.Label53.TabIndex = 35
        Me.Label53.Text = "m"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(310, 159)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(15, 13)
        Me.Label54.TabIndex = 36
        Me.Label54.Text = "m"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"4", "5", "6", "8", "9", "10", "12"})
        Me.ComboBox1.Location = New System.Drawing.Point(205, 185)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(97, 21)
        Me.ComboBox1.TabIndex = 37
        Me.ComboBox1.Text = "6"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(306, 221)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(23, 13)
        Me.Label55.TabIndex = 38
        Me.Label55.Text = "mm"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(308, 259)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(15, 13)
        Me.Label56.TabIndex = 39
        Me.Label56.Text = "m"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(306, 319)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(15, 13)
        Me.Label57.TabIndex = 40
        Me.Label57.Text = "m"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(306, 353)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(15, 13)
        Me.Label58.TabIndex = 41
        Me.Label58.Text = "m"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(306, 387)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(15, 13)
        Me.Label59.TabIndex = 42
        Me.Label59.Text = "m"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(301, 536)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(46, 13)
        Me.Label60.TabIndex = 43
        Me.Label60.Text = "kN/cum"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(230, 22)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(15, 13)
        Me.Label61.TabIndex = 44
        Me.Label61.Text = "m"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Symbol", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Label62.Location = New System.Drawing.Point(120, 120)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(13, 13)
        Me.Label62.TabIndex = 45
        Me.Label62.Text = "s"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(230, 55)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(45, 13)
        Me.Label63.TabIndex = 46
        Me.Label63.Text = "kN/sqm"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(232, 85)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(45, 13)
        Me.Label64.TabIndex = 47
        Me.Label64.Text = "kN/sqm"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(131, 121)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(19, 13)
        Me.Label65.TabIndex = 48
        Me.Label65.Text = "ct:"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(230, 120)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(47, 13)
        Me.Label66.TabIndex = 49
        Me.Label66.Text = "N/sqmm"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(232, 159)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(23, 13)
        Me.Label67.TabIndex = 44
        Me.Label67.Text = "mm"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(213, 43)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(23, 13)
        Me.Label68.TabIndex = 50
        Me.Label68.Text = "mm"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(214, 153)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(23, 13)
        Me.Label69.TabIndex = 51
        Me.Label69.Text = "mm"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(213, 117)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(23, 13)
        Me.Label70.TabIndex = 52
        Me.Label70.Text = "mm"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(213, 78)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(23, 13)
        Me.Label71.TabIndex = 53
        Me.Label71.Text = "mm"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(200, 219)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(40, 13)
        Me.Label72.TabIndex = 45
        Me.Label72.Text = "mm dia"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(243, 183)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(23, 13)
        Me.Label73.TabIndex = 46
        Me.Label73.Text = "mm"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(243, 147)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(23, 13)
        Me.Label74.TabIndex = 47
        Me.Label74.Text = "mm"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Location = New System.Drawing.Point(200, 113)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(23, 13)
        Me.Label75.TabIndex = 48
        Me.Label75.Text = "mm"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(200, 85)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(23, 13)
        Me.Label76.TabIndex = 49
        Me.Label76.Text = "mm"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(200, 55)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(23, 13)
        Me.Label77.TabIndex = 50
        Me.Label77.Text = "mm"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(200, 25)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(23, 13)
        Me.Label78.TabIndex = 51
        Me.Label78.Text = "mm"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(138, 146)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(23, 13)
        Me.Label79.TabIndex = 52
        Me.Label79.Text = "mm"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(138, 184)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(23, 13)
        Me.Label80.TabIndex = 53
        Me.Label80.Text = "mm"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(230, 221)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(45, 13)
        Me.Label81.TabIndex = 50
        Me.Label81.Text = "kN/sqm"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(230, 255)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(46, 13)
        Me.Label82.TabIndex = 44
        Me.Label82.Text = "kN/cum"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(230, 286)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(45, 13)
        Me.Label83.TabIndex = 51
        Me.Label83.Text = "kN/sqm"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(230, 351)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(47, 13)
        Me.Label84.TabIndex = 52
        Me.Label84.Text = "N/sqmm"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Location = New System.Drawing.Point(230, 384)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(47, 13)
        Me.Label85.TabIndex = 53
        Me.Label85.Text = "N/sqmm"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(232, 416)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(23, 13)
        Me.Label86.TabIndex = 54
        Me.Label86.Text = "mm"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(230, 473)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(15, 13)
        Me.Label87.TabIndex = 44
        Me.Label87.Text = "m"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Location = New System.Drawing.Point(232, 446)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(15, 13)
        Me.Label88.TabIndex = 45
        Me.Label88.Text = "m"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(128, 127)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(15, 13)
        Me.Label89.TabIndex = 54
        Me.Label89.Text = "m"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(232, 508)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(23, 13)
        Me.Label90.TabIndex = 55
        Me.Label90.Text = "mm"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(232, 538)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(21, 13)
        Me.Label91.TabIndex = 56
        Me.Label91.Text = "kN"
        '
        'frmOverHead
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(996, 682)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label24)
        Me.Name = "frmOverHead"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MTech ""Tank Analysis""  - OverHead Tank"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtdensityofconcrete As System.Windows.Forms.TextBox
    Friend WithEvents txtgradeofsteel As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents txtgradeofconcreete As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtdeptoffooting As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtcentertocenterdistance As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtlowersupplylevel As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtnooflevels As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtdistancebtwncolumns As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtdiameterofcolumn As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtfreeboard As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txthieghtoftank As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtwallthickness As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtInternalDiameter As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCapacity As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtarbitaryload As System.Windows.Forms.TextBox
    Friend WithEvents txtdeflection As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtbottomdia As System.Windows.Forms.TextBox
    Friend WithEvents txtspacingofbracing As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtefectivecover As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtscb As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txttensilestress As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtQ As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtbearingcapacity As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtwtofwater As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtfinishesload As System.Windows.Forms.TextBox
    Friend WithEvents txtdepthbydiameterratio As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtnominalcover As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtresistancetocraking As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents txtintensityofwind As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtliveload As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtheightoftower As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtcolumns As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents txtbraces1 As System.Windows.Forms.TextBox
    Friend WithEvents txtfloorbeams1 As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtgallery As System.Windows.Forms.TextBox
    Friend WithEvents txtFloorslab As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtWall As System.Windows.Forms.TextBox
    Friend WithEvents txtRoofSlab As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveOverheadData As System.Windows.Forms.Button
    Friend WithEvents txtDistributionBar As System.Windows.Forms.TextBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents txtPrimaryBar As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents txtMainBar As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents cmbtypeofsoil As System.Windows.Forms.ComboBox
    Friend WithEvents cmbzone As System.Windows.Forms.ComboBox
    Friend WithEvents txtSecondaryBar As System.Windows.Forms.TextBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents txtfloorbeams2 As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents txtbraces2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSeismic As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button
    Friend WithEvents btnRCC As System.Windows.Forms.Button
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents btnDataSheet As System.Windows.Forms.Button
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
End Class
