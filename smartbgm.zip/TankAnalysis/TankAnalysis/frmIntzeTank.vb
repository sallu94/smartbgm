﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmIntzeTank
    Dim xlApp As New Excel.Application
    Dim xlWorkBook As Excel.Workbook

    Dim xlAppNew As New Excel.Application
    Dim xlWorkBookNew As Excel.Workbook

    Dim dt As String
    Dim filename As String

    Private Sub btnSaveIntzeData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveIntzeData.Click
        '.....Open the original complete excel file and save as
        xlWorkBook = xlApp.Workbooks.Open("D:\TankAnalysis\complete.xlsx")
        dt = Now.Day & "_" & Now.Month & "_" & Now.Year & "_" & Now.Hour & "_" & Now.Minute & "_" & Now.Second
        filename = "D:\TankAnalysis\SavedFiles\" & gbltanktype & "_" & dt & ".xlsx"
        xlWorkBook.SaveAs(Filename:=filename)
        xlWorkBook.Close()
        xlApp.Quit()

        '...open the new file and save data from the vb.net form to excel
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)

        xlWorkBookNew.Sheets(20).Cells(2, 8) = txtCapacity.Text
        xlWorkBookNew.Sheets(20).Cells(3, 8) = cmbNoofcolumns.Text
        xlWorkBookNew.Sheets(20).Cells(4, 8) = txtnooflevels.Text
        xlWorkBookNew.Sheets(20).Cells(5, 8) = txtgradeofconcreete.Text
        xlWorkBookNew.Sheets(20).Cells(6, 8) = txtgradeofsteel.Text
        xlWorkBookNew.Sheets(20).Cells(7, 8) = txtdeptoffooting.Text
        xlWorkBookNew.Sheets(20).Cells(8, 8) = cmbtypeofsoil.Text
        xlWorkBookNew.Sheets(20).Cells(9, 8) = cmbzone.Text
        xlWorkBookNew.Sheets(20).Cells(10, 8) = txtdensityofconcrete.Text
        xlWorkBookNew.Sheets(20).Cells(11, 8) = txtdeptoftank.Text
        xlWorkBookNew.Sheets(20).Cells(12, 8) = txtfreeboard.Text
        xlWorkBookNew.Sheets(20).Cells(13, 8) = txtdiaoftopdome.Text
        xlWorkBookNew.Sheets(20).Cells(14, 8) = txtdiaofbottomdome.Text
        xlWorkBookNew.Sheets(20).Cells(15, 8) = txtdistancebtwncolumns.Text
        xlWorkBookNew.Sheets(20).Cells(16, 8) = txtheightoftower.Text
        xlWorkBookNew.Sheets(20).Cells(17, 8) = txtliveload.Text
        xlWorkBookNew.Sheets(20).Cells(18, 8) = txtintensityofwind.Text
        xlWorkBookNew.Sheets(20).Cells(19, 8) = txtresistancetocraking.Text
        xlWorkBookNew.Sheets(20).Cells(20, 8) = txtnominalcover.Text
        xlWorkBookNew.Sheets(20).Cells(21, 8) = txtdepthbydiameterratio.Text
        xlWorkBookNew.Sheets(20).Cells(22, 8) = txtfinishesload.Text
        xlWorkBookNew.Sheets(20).Cells(23, 8) = txtwtofwater.Text
        xlWorkBookNew.Sheets(20).Cells(24, 8) = txtbearingcapacity.Text
        xlWorkBookNew.Sheets(20).Cells(25, 8) = txtUnitWt.Text
        xlWorkBookNew.Sheets(20).Cells(26, 8) = txtQ.Text
        xlWorkBookNew.Sheets(20).Cells(27, 8) = txttensilestress.Text
        xlWorkBookNew.Sheets(20).Cells(28, 8) = txtscb.Text
        xlWorkBookNew.Sheets(20).Cells(29, 8) = txtspacingofbracing.Text

        xlWorkBookNew.Sheets(20).Cells(33, 8) = txtMainBar.Text
        xlWorkBookNew.Sheets(20).Cells(34, 8) = txtPrimaryBar.Text
        xlWorkBookNew.Sheets(20).Cells(35, 8) = txtSecondaryBar.Text
        xlWorkBookNew.Sheets(20).Cells(36, 8) = txtDistributionBar.Text


        xlWorkBookNew.Close(SaveChanges:=True)
        xlAppNew.Quit()
        MsgBox("Data saved successfully", MsgBoxStyle.Information)

        btnRCC.Visible = True
        btnSeismic.Visible = True
        btnSummary.Visible = True
        btnDataSheet.Visible = True
    End Sub

    Private Sub btnSeismic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSeismic.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Seismic.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(21).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(21)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnRCC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRCC.Click
        Dim pdf_filename_RCC As String
        pdf_filename_RCC = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_RCC.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(22).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(22)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_RCC, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnSummary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSummary.Click
        Dim pdf_filename_Summary As String
        pdf_filename_Summary = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_Summary.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(23).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(23)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_Summary, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub btnDataSheet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDataSheet.Click
        Dim pdf_filename_seismic As String
        pdf_filename_seismic = "D:\TankAnalysis\Outputs\" & gbltanktype & "_" & dt & "_DataSheet.pdf"
        xlWorkBookNew = xlAppNew.Workbooks.Open(filename)
        xlWorkBookNew.Sheets(20).activate()
        Dim mySheet As Microsoft.Office.Interop.Excel.Worksheet = xlWorkBookNew.Sheets(20)
        mySheet.ExportAsFixedFormat( _
        Excel.XlFixedFormatType.xlTypePDF, _
        pdf_filename_seismic, _
        Excel.XlFixedFormatQuality.xlQualityStandard, _
        False, _
        False, _
        1, _
        10, _
        True)
    End Sub

    Private Sub txtNoofcolumns_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNoofcolumns.SelectedIndexChanged

    End Sub

    Private Function cmbNoofcolumns() As Object
        Throw New NotImplementedException
    End Function

End Class