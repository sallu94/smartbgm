﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCircularTank
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtRingBeam2 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtRingBeam1 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtFinishingLoad = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtOffset = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtVolumeofwater = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtLiveLoad = New System.Windows.Forms.TextBox()
        Me.txtdomethickness = New System.Windows.Forms.TextBox()
        Me.txtgradeofsteel = New System.Windows.Forms.TextBox()
        Me.txtgradeofconcrete = New System.Windows.Forms.TextBox()
        Me.cmbtypeofsoil = New System.Windows.Forms.ComboBox()
        Me.cmbzone = New System.Windows.Forms.ComboBox()
        Me.txtbaseslab = New System.Windows.Forms.TextBox()
        Me.txtwallthick = New System.Windows.Forms.TextBox()
        Me.txtfreeboard = New System.Windows.Forms.TextBox()
        Me.txtheight = New System.Windows.Forms.TextBox()
        Me.txtDensityofConcrete = New System.Windows.Forms.TextBox()
        Me.txtDiameter = New System.Windows.Forms.TextBox()
        Me.txtCapacity = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtSaturatedDensity = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.txtSubmergedDensity = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtHeightOfsoil = New System.Windows.Forms.TextBox()
        Me.txtSBC = New System.Windows.Forms.TextBox()
        Me.txtfy = New System.Windows.Forms.TextBox()
        Me.txtdensityofwater = New System.Windows.Forms.TextBox()
        Me.txtvoidratio = New System.Windows.Forms.TextBox()
        Me.txtspecificgravity = New System.Windows.Forms.TextBox()
        Me.txtDrydensity = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnSaveCircularData = New System.Windows.Forms.Button()
        Me.txtDistributionBar = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtMainBar = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnDataSheet = New System.Windows.Forms.Button()
        Me.btnSeismic = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.btnRCC = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label44)
        Me.GroupBox1.Controls.Add(Me.Label43)
        Me.GroupBox1.Controls.Add(Me.Label42)
        Me.GroupBox1.Controls.Add(Me.Label41)
        Me.GroupBox1.Controls.Add(Me.Label40)
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.Label38)
        Me.GroupBox1.Controls.Add(Me.Label37)
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.Label34)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.Label33)
        Me.GroupBox1.Controls.Add(Me.txtRingBeam2)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtRingBeam1)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.txtFinishingLoad)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtOffset)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txtVolumeofwater)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtLiveLoad)
        Me.GroupBox1.Controls.Add(Me.txtdomethickness)
        Me.GroupBox1.Controls.Add(Me.txtgradeofsteel)
        Me.GroupBox1.Controls.Add(Me.txtgradeofconcrete)
        Me.GroupBox1.Controls.Add(Me.cmbtypeofsoil)
        Me.GroupBox1.Controls.Add(Me.cmbzone)
        Me.GroupBox1.Controls.Add(Me.txtbaseslab)
        Me.GroupBox1.Controls.Add(Me.txtwallthick)
        Me.GroupBox1.Controls.Add(Me.txtfreeboard)
        Me.GroupBox1.Controls.Add(Me.txtheight)
        Me.GroupBox1.Controls.Add(Me.txtDensityofConcrete)
        Me.GroupBox1.Controls.Add(Me.txtDiameter)
        Me.GroupBox1.Controls.Add(Me.txtCapacity)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(325, 554)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = " Seismic Design"
        '
        'txtRingBeam2
        '
        Me.txtRingBeam2.Location = New System.Drawing.Point(206, 532)
        Me.txtRingBeam2.Name = "txtRingBeam2"
        Me.txtRingBeam2.Size = New System.Drawing.Size(57, 20)
        Me.txtRingBeam2.TabIndex = 35
        Me.txtRingBeam2.Text = "300"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(180, 535)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(14, 13)
        Me.Label18.TabIndex = 34
        Me.Label18.Text = "X"
        '
        'txtRingBeam1
        '
        Me.txtRingBeam1.Location = New System.Drawing.Point(98, 531)
        Me.txtRingBeam1.Name = "txtRingBeam1"
        Me.txtRingBeam1.Size = New System.Drawing.Size(57, 20)
        Me.txtRingBeam1.TabIndex = 33
        Me.txtRingBeam1.Text = "300"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(24, 533)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 13)
        Me.Label17.TabIndex = 32
        Me.Label17.Text = "Ring Beam :"
        '
        'txtFinishingLoad
        '
        Me.txtFinishingLoad.Location = New System.Drawing.Point(127, 499)
        Me.txtFinishingLoad.Name = "txtFinishingLoad"
        Me.txtFinishingLoad.Size = New System.Drawing.Size(121, 20)
        Me.txtFinishingLoad.TabIndex = 31
        Me.txtFinishingLoad.Text = "600"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(36, 502)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(81, 13)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Finishing Load :"
        '
        'txtOffset
        '
        Me.txtOffset.Location = New System.Drawing.Point(123, 399)
        Me.txtOffset.Name = "txtOffset"
        Me.txtOffset.Size = New System.Drawing.Size(121, 20)
        Me.txtOffset.TabIndex = 29
        Me.txtOffset.Text = "0.3"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(76, 402)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(41, 13)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Offset :"
        '
        'txtVolumeofwater
        '
        Me.txtVolumeofwater.Location = New System.Drawing.Point(124, 366)
        Me.txtVolumeofwater.Name = "txtVolumeofwater"
        Me.txtVolumeofwater.Size = New System.Drawing.Size(121, 20)
        Me.txtVolumeofwater.TabIndex = 27
        Me.txtVolumeofwater.Text = "1000"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(26, 368)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(92, 13)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "Volume of Water :"
        '
        'txtLiveLoad
        '
        Me.txtLiveLoad.Location = New System.Drawing.Point(127, 468)
        Me.txtLiveLoad.Name = "txtLiveLoad"
        Me.txtLiveLoad.Size = New System.Drawing.Size(121, 20)
        Me.txtLiveLoad.TabIndex = 25
        Me.txtLiveLoad.Text = "1000"
        '
        'txtdomethickness
        '
        Me.txtdomethickness.Location = New System.Drawing.Point(127, 433)
        Me.txtdomethickness.Name = "txtdomethickness"
        Me.txtdomethickness.Size = New System.Drawing.Size(121, 20)
        Me.txtdomethickness.TabIndex = 24
        Me.txtdomethickness.Text = "125"
        '
        'txtgradeofsteel
        '
        Me.txtgradeofsteel.Location = New System.Drawing.Point(124, 307)
        Me.txtgradeofsteel.Name = "txtgradeofsteel"
        Me.txtgradeofsteel.Size = New System.Drawing.Size(121, 20)
        Me.txtgradeofsteel.TabIndex = 23
        Me.txtgradeofsteel.Text = "415"
        '
        'txtgradeofconcrete
        '
        Me.txtgradeofconcrete.Location = New System.Drawing.Point(124, 278)
        Me.txtgradeofconcrete.Name = "txtgradeofconcrete"
        Me.txtgradeofconcrete.Size = New System.Drawing.Size(121, 20)
        Me.txtgradeofconcrete.TabIndex = 22
        Me.txtgradeofconcrete.Text = "20"
        '
        'cmbtypeofsoil
        '
        Me.cmbtypeofsoil.FormattingEnabled = True
        Me.cmbtypeofsoil.Items.AddRange(New Object() {"Hard Soil", "Medium Soil", "Soft Soil"})
        Me.cmbtypeofsoil.Location = New System.Drawing.Point(125, 336)
        Me.cmbtypeofsoil.Name = "cmbtypeofsoil"
        Me.cmbtypeofsoil.Size = New System.Drawing.Size(121, 21)
        Me.cmbtypeofsoil.TabIndex = 21
        Me.cmbtypeofsoil.Text = "Hard Soil"
        '
        'cmbzone
        '
        Me.cmbzone.FormattingEnabled = True
        Me.cmbzone.Items.AddRange(New Object() {"II", "III", "IV", "V"})
        Me.cmbzone.Location = New System.Drawing.Point(125, 243)
        Me.cmbzone.Name = "cmbzone"
        Me.cmbzone.Size = New System.Drawing.Size(121, 21)
        Me.cmbzone.TabIndex = 20
        Me.cmbzone.Text = "II"
        '
        'txtbaseslab
        '
        Me.txtbaseslab.Location = New System.Drawing.Point(125, 178)
        Me.txtbaseslab.Name = "txtbaseslab"
        Me.txtbaseslab.Size = New System.Drawing.Size(121, 20)
        Me.txtbaseslab.TabIndex = 19
        Me.txtbaseslab.Text = "0.5"
        '
        'txtwallthick
        '
        Me.txtwallthick.Location = New System.Drawing.Point(125, 148)
        Me.txtwallthick.Name = "txtwallthick"
        Me.txtwallthick.Size = New System.Drawing.Size(121, 20)
        Me.txtwallthick.TabIndex = 18
        Me.txtwallthick.Text = "0.4"
        '
        'txtfreeboard
        '
        Me.txtfreeboard.Location = New System.Drawing.Point(127, 90)
        Me.txtfreeboard.Name = "txtfreeboard"
        Me.txtfreeboard.Size = New System.Drawing.Size(121, 20)
        Me.txtfreeboard.TabIndex = 17
        Me.txtfreeboard.Text = "0.5"
        '
        'txtheight
        '
        Me.txtheight.Location = New System.Drawing.Point(126, 120)
        Me.txtheight.Name = "txtheight"
        Me.txtheight.Size = New System.Drawing.Size(121, 20)
        Me.txtheight.TabIndex = 16
        Me.txtheight.Text = "2"
        '
        'txtDensityofConcrete
        '
        Me.txtDensityofConcrete.Location = New System.Drawing.Point(127, 212)
        Me.txtDensityofConcrete.Name = "txtDensityofConcrete"
        Me.txtDensityofConcrete.Size = New System.Drawing.Size(121, 20)
        Me.txtDensityofConcrete.TabIndex = 15
        Me.txtDensityofConcrete.Text = "25"
        '
        'txtDiameter
        '
        Me.txtDiameter.Location = New System.Drawing.Point(129, 64)
        Me.txtDiameter.Name = "txtDiameter"
        Me.txtDiameter.Size = New System.Drawing.Size(121, 20)
        Me.txtDiameter.TabIndex = 14
        Me.txtDiameter.Text = "10"
        '
        'txtCapacity
        '
        Me.txtCapacity.Location = New System.Drawing.Point(129, 30)
        Me.txtCapacity.Name = "txtCapacity"
        Me.txtCapacity.Size = New System.Drawing.Size(121, 20)
        Me.txtCapacity.TabIndex = 13
        Me.txtCapacity.Text = "1000"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(27, 67)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(95, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Diameter of Tank :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 215)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(106, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Density of Concrete :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(76, 123)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Height :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(54, 93)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Free Board  :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(32, 151)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Wall Thickness :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(81, 247)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Zone :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(50, 340)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Type of Soil :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(57, 471)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Live Load :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 181)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Base slab thickness :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 436)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Dome Thickness :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 310)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Grade of Steel :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 281)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Grade of Concrete :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Capacity of Tank :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Courier New", 24.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Blue
        Me.Label24.Location = New System.Drawing.Point(177, 3)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(262, 36)
        Me.Label24.TabIndex = 7
        Me.Label24.Text = "Circular Tank"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label51)
        Me.GroupBox2.Controls.Add(Me.Label50)
        Me.GroupBox2.Controls.Add(Me.Label48)
        Me.GroupBox2.Controls.Add(Me.Label47)
        Me.GroupBox2.Controls.Add(Me.Label46)
        Me.GroupBox2.Controls.Add(Me.Label45)
        Me.GroupBox2.Controls.Add(Me.txtSaturatedDensity)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.txtSubmergedDensity)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.txtHeightOfsoil)
        Me.GroupBox2.Controls.Add(Me.txtSBC)
        Me.GroupBox2.Controls.Add(Me.txtfy)
        Me.GroupBox2.Controls.Add(Me.txtdensityofwater)
        Me.GroupBox2.Controls.Add(Me.txtvoidratio)
        Me.GroupBox2.Controls.Add(Me.txtspecificgravity)
        Me.GroupBox2.Controls.Add(Me.txtDrydensity)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Location = New System.Drawing.Point(366, 38)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(317, 353)
        Me.GroupBox2.TabIndex = 36
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Soil Characteristics"
        '
        'txtSaturatedDensity
        '
        Me.txtSaturatedDensity.Location = New System.Drawing.Point(106, 309)
        Me.txtSaturatedDensity.Name = "txtSaturatedDensity"
        Me.txtSaturatedDensity.Size = New System.Drawing.Size(121, 20)
        Me.txtSaturatedDensity.TabIndex = 37
        Me.txtSaturatedDensity.Text = "200882.4"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(6, 312)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(94, 13)
        Me.Label28.TabIndex = 36
        Me.Label28.Text = "Saturated Density:"
        '
        'txtSubmergedDensity
        '
        Me.txtSubmergedDensity.Location = New System.Drawing.Point(106, 275)
        Me.txtSubmergedDensity.Name = "txtSubmergedDensity"
        Me.txtSubmergedDensity.Size = New System.Drawing.Size(121, 20)
        Me.txtSubmergedDensity.TabIndex = 35
        Me.txtSubmergedDensity.Text = "9117.6"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(1, 278)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(102, 13)
        Me.Label27.TabIndex = 34
        Me.Label27.Text = "Submerged Density:"
        '
        'txtHeightOfsoil
        '
        Me.txtHeightOfsoil.Location = New System.Drawing.Point(106, 240)
        Me.txtHeightOfsoil.Name = "txtHeightOfsoil"
        Me.txtHeightOfsoil.Size = New System.Drawing.Size(121, 20)
        Me.txtHeightOfsoil.TabIndex = 33
        Me.txtHeightOfsoil.Text = "1.5"
        '
        'txtSBC
        '
        Me.txtSBC.Location = New System.Drawing.Point(105, 201)
        Me.txtSBC.Name = "txtSBC"
        Me.txtSBC.Size = New System.Drawing.Size(121, 20)
        Me.txtSBC.TabIndex = 32
        Me.txtSBC.Text = "150"
        '
        'txtfy
        '
        Me.txtfy.Location = New System.Drawing.Point(105, 166)
        Me.txtfy.Name = "txtfy"
        Me.txtfy.Size = New System.Drawing.Size(121, 20)
        Me.txtfy.TabIndex = 31
        Me.txtfy.Text = "13"
        '
        'txtdensityofwater
        '
        Me.txtdensityofwater.Location = New System.Drawing.Point(106, 130)
        Me.txtdensityofwater.Name = "txtdensityofwater"
        Me.txtdensityofwater.Size = New System.Drawing.Size(121, 20)
        Me.txtdensityofwater.TabIndex = 30
        Me.txtdensityofwater.Text = "10000"
        '
        'txtvoidratio
        '
        Me.txtvoidratio.Location = New System.Drawing.Point(107, 92)
        Me.txtvoidratio.Name = "txtvoidratio"
        Me.txtvoidratio.Size = New System.Drawing.Size(121, 20)
        Me.txtvoidratio.TabIndex = 29
        Me.txtvoidratio.Text = "0.7"
        '
        'txtspecificgravity
        '
        Me.txtspecificgravity.Location = New System.Drawing.Point(107, 60)
        Me.txtspecificgravity.Name = "txtspecificgravity"
        Me.txtspecificgravity.Size = New System.Drawing.Size(121, 20)
        Me.txtspecificgravity.TabIndex = 28
        Me.txtspecificgravity.Text = "2.55"
        '
        'txtDrydensity
        '
        Me.txtDrydensity.Location = New System.Drawing.Point(107, 26)
        Me.txtDrydensity.Name = "txtDrydensity"
        Me.txtDrydensity.Size = New System.Drawing.Size(121, 20)
        Me.txtDrydensity.TabIndex = 27
        Me.txtDrydensity.Text = "15000"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(13, 66)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(87, 13)
        Me.Label19.TabIndex = 26
        Me.Label19.Text = "Specific Gravity :"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(37, 98)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 13)
        Me.Label20.TabIndex = 25
        Me.Label20.Text = "Void Ratio :"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(10, 133)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(89, 13)
        Me.Label21.TabIndex = 24
        Me.Label21.Text = "Density of water :"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(76, 169)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(23, 13)
        Me.Label22.TabIndex = 23
        Me.Label22.Text = "Φ :"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(59, 204)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(40, 13)
        Me.Label23.TabIndex = 22
        Me.Label23.Text = "S.B.C :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(24, 243)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(76, 13)
        Me.Label25.TabIndex = 21
        Me.Label25.Text = "Height of Soil :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(32, 29)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(67, 13)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "Dry Density :"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label52)
        Me.GroupBox3.Controls.Add(Me.Label53)
        Me.GroupBox3.Controls.Add(Me.btnSaveCircularData)
        Me.GroupBox3.Controls.Add(Me.txtDistributionBar)
        Me.GroupBox3.Controls.Add(Me.Label29)
        Me.GroupBox3.Controls.Add(Me.txtMainBar)
        Me.GroupBox3.Controls.Add(Me.Label31)
        Me.GroupBox3.Location = New System.Drawing.Point(366, 395)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(317, 191)
        Me.GroupBox3.TabIndex = 38
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Diameter of Reinforcement Bars"
        '
        'btnSaveCircularData
        '
        Me.btnSaveCircularData.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSaveCircularData.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveCircularData.Location = New System.Drawing.Point(39, 126)
        Me.btnSaveCircularData.Name = "btnSaveCircularData"
        Me.btnSaveCircularData.Size = New System.Drawing.Size(203, 31)
        Me.btnSaveCircularData.TabIndex = 5
        Me.btnSaveCircularData.Text = "Save Circular Data"
        Me.btnSaveCircularData.UseVisualStyleBackColor = False
        '
        'txtDistributionBar
        '
        Me.txtDistributionBar.Location = New System.Drawing.Point(143, 74)
        Me.txtDistributionBar.Name = "txtDistributionBar"
        Me.txtDistributionBar.Size = New System.Drawing.Size(121, 20)
        Me.txtDistributionBar.TabIndex = 39
        Me.txtDistributionBar.Text = "10"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(2, 77)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(141, 13)
        Me.Label29.TabIndex = 34
        Me.Label29.Text = "Diameter of Distribution Bar :"
        '
        'txtMainBar
        '
        Me.txtMainBar.Location = New System.Drawing.Point(142, 40)
        Me.txtMainBar.Name = "txtMainBar"
        Me.txtMainBar.Size = New System.Drawing.Size(121, 20)
        Me.txtMainBar.TabIndex = 37
        Me.txtMainBar.Text = "16"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(29, 43)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(111, 13)
        Me.Label31.TabIndex = 36
        Me.Label31.Text = "Diameter of main Bar :"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnDataSheet)
        Me.GroupBox4.Controls.Add(Me.btnSeismic)
        Me.GroupBox4.Controls.Add(Me.btnSummary)
        Me.GroupBox4.Controls.Add(Me.btnRCC)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 591)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(671, 87)
        Me.GroupBox4.TabIndex = 39
        Me.GroupBox4.TabStop = False
        '
        'btnDataSheet
        '
        Me.btnDataSheet.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnDataSheet.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDataSheet.Location = New System.Drawing.Point(12, 32)
        Me.btnDataSheet.Name = "btnDataSheet"
        Me.btnDataSheet.Size = New System.Drawing.Size(128, 31)
        Me.btnDataSheet.TabIndex = 13
        Me.btnDataSheet.Text = "Data Sheet"
        Me.btnDataSheet.UseVisualStyleBackColor = False
        Me.btnDataSheet.Visible = False
        '
        'btnSeismic
        '
        Me.btnSeismic.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSeismic.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeismic.Location = New System.Drawing.Point(167, 32)
        Me.btnSeismic.Name = "btnSeismic"
        Me.btnSeismic.Size = New System.Drawing.Size(128, 31)
        Me.btnSeismic.TabIndex = 9
        Me.btnSeismic.Text = "SEISMIC"
        Me.btnSeismic.UseVisualStyleBackColor = False
        Me.btnSeismic.Visible = False
        '
        'btnSummary
        '
        Me.btnSummary.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnSummary.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSummary.Location = New System.Drawing.Point(513, 32)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(128, 31)
        Me.btnSummary.TabIndex = 11
        Me.btnSummary.Text = "SUMMARY"
        Me.btnSummary.UseVisualStyleBackColor = False
        Me.btnSummary.Visible = False
        '
        'btnRCC
        '
        Me.btnRCC.BackColor = System.Drawing.Color.FromArgb(CType(CType(146, Byte), Integer), CType(CType(228, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.btnRCC.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRCC.Location = New System.Drawing.Point(341, 32)
        Me.btnRCC.Name = "btnRCC"
        Me.btnRCC.Size = New System.Drawing.Size(128, 31)
        Me.btnRCC.TabIndex = 10
        Me.btnRCC.Text = "RCC"
        Me.btnRCC.UseVisualStyleBackColor = False
        Me.btnRCC.Visible = False
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(256, 33)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(27, 13)
        Me.Label33.TabIndex = 40
        Me.Label33.Text = "cum"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(256, 68)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(15, 13)
        Me.Label30.TabIndex = 41
        Me.Label30.Text = "m"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(256, 181)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(15, 13)
        Me.Label32.TabIndex = 42
        Me.Label32.Text = "m"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(256, 151)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(15, 13)
        Me.Label34.TabIndex = 43
        Me.Label34.Text = "m"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(256, 123)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(15, 13)
        Me.Label35.TabIndex = 44
        Me.Label35.Text = "m"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(256, 97)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(15, 13)
        Me.Label36.TabIndex = 45
        Me.Label36.Text = "m"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(256, 215)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(46, 13)
        Me.Label37.TabIndex = 46
        Me.Label37.Text = "kN/cum"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(251, 369)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(27, 13)
        Me.Label38.TabIndex = 47
        Me.Label38.Text = "cum"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(251, 406)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(15, 13)
        Me.Label39.TabIndex = 48
        Me.Label39.Text = "m"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(251, 436)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(23, 13)
        Me.Label40.TabIndex = 49
        Me.Label40.Text = "mm"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(269, 534)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(23, 13)
        Me.Label41.TabIndex = 50
        Me.Label41.Text = "mm"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(254, 471)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(39, 13)
        Me.Label42.TabIndex = 51
        Me.Label42.Text = "N/sqm"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(254, 502)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(39, 13)
        Me.Label43.TabIndex = 52
        Me.Label43.Text = "N/sqm"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(157, 535)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(23, 13)
        Me.Label44.TabIndex = 53
        Me.Label44.Text = "mm"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(234, 29)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(40, 13)
        Me.Label45.TabIndex = 51
        Me.Label45.Text = "N/cum"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(233, 133)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(40, 13)
        Me.Label46.TabIndex = 52
        Me.Label46.Text = "N/cum"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(233, 278)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(40, 13)
        Me.Label47.TabIndex = 53
        Me.Label47.Text = "N/cum"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(233, 312)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(40, 13)
        Me.Label48.TabIndex = 54
        Me.Label48.Text = "N/cum"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(232, 204)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(45, 13)
        Me.Label50.TabIndex = 56
        Me.Label50.Text = "kN/sqm"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(234, 246)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(15, 13)
        Me.Label51.TabIndex = 57
        Me.Label51.Text = "m"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(269, 77)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(23, 13)
        Me.Label52.TabIndex = 58
        Me.Label52.Text = "mm"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(269, 45)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(23, 13)
        Me.Label53.TabIndex = 59
        Me.Label53.Text = "mm"
        '
        'frmCircularTank
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(720, 682)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmCircularTank"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MTech ""Tank Analysis""  - Circular Tank"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtLiveLoad As System.Windows.Forms.TextBox
    Friend WithEvents txtdomethickness As System.Windows.Forms.TextBox
    Friend WithEvents txtgradeofsteel As System.Windows.Forms.TextBox
    Friend WithEvents txtgradeofconcrete As System.Windows.Forms.TextBox
    Friend WithEvents cmbtypeofsoil As System.Windows.Forms.ComboBox
    Friend WithEvents cmbzone As System.Windows.Forms.ComboBox
    Friend WithEvents txtbaseslab As System.Windows.Forms.TextBox
    Friend WithEvents txtwallthick As System.Windows.Forms.TextBox
    Friend WithEvents txtfreeboard As System.Windows.Forms.TextBox
    Friend WithEvents txtheight As System.Windows.Forms.TextBox
    Friend WithEvents txtDensityofConcrete As System.Windows.Forms.TextBox
    Friend WithEvents txtDiameter As System.Windows.Forms.TextBox
    Friend WithEvents txtCapacity As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtVolumeofwater As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtOffset As System.Windows.Forms.TextBox
    Friend WithEvents txtFinishingLoad As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtRingBeam1 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtRingBeam2 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSubmergedDensity As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents txtHeightOfsoil As System.Windows.Forms.TextBox
    Friend WithEvents txtSBC As System.Windows.Forms.TextBox
    Friend WithEvents txtfy As System.Windows.Forms.TextBox
    Friend WithEvents txtdensityofwater As System.Windows.Forms.TextBox
    Friend WithEvents txtvoidratio As System.Windows.Forms.TextBox
    Friend WithEvents txtspecificgravity As System.Windows.Forms.TextBox
    Friend WithEvents txtDrydensity As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtSaturatedDensity As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSaveCircularData As System.Windows.Forms.Button
    Friend WithEvents txtDistributionBar As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtMainBar As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnSeismic As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button
    Friend WithEvents btnRCC As System.Windows.Forms.Button
    Friend WithEvents btnDataSheet As System.Windows.Forms.Button
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
End Class
