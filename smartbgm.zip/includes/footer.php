<br/><br/><br/><br/>

<!-- advertisement -->
<div class="indicate">
    <div class="container">
        <div class="indicate-grids">
            <marquee>
                <?php
                include_once "includes/database_function.php";
                connect();
                $rs = getTableData("ads");
                $i = 1;
                while ($ad = mysql_fetch_array($rs)) {
                ?>

                    <span class="h3" style="color: #ffff00;">
                            <span class="glyphicon glyphicon-flash"></span>
                        <?php echo $ad['ad_title']; ?>
                        </span>
                    <span class="bg-primary"> <?php echo $ad['ad_desc']; ?></span>
                <?php } ?>
                <div class="clearfix"></div>
            </marquee>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer-section">
    <div class="container">
        <div class="footer-top">
            <p> &copy; 2016 Smart Belgaum . All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                    href="http://jainbgm.in"> JCE</a>
            </p>
        </div>
    </div>
</div>