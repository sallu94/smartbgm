<?php
if (!isset($_SESSION['user'])) {
    ?>

    <div class="navbar" width="100%">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><?php echo $WEBSITE_NAME; ?></a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php"><span class="glyphicon glyphicon-home"></span></a></li>
                        <li><a href="">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="">Services</a></li>
                        <li><a href="admin/">Admin</a></li>
                        <li><a href="leader/">Leader</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="./signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                        <li><a href="./login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <?php
} else {


    ?>
    <div class="navbar" width="100%">
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><?php echo $WEBSITE_NAME; ?></a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li><a href="./homepage.php"><span class="glyphicon glyphicon-dashboard"></span></a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Contact</a></li>
                        <li><a href="">Services</a></li>
                    </ul>
                    <div class="nav navbar-nav navbar-right dropdown">

                        <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                            Look Here <?php echo $_SESSION['user']; ?> &nbsp;
                            <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="#">My Profile</a></li>
                            <li><a href="#">Update Password</a></li>
                            <li><a href="logout.php">Log out</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </nav>
    </div>
    <?php
}