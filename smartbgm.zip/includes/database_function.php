<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
error_reporting(E_ALL ^ E_NOTICE);

function connect()
{
    require_once 'strings.php';
    // connecting to mysql
    $con = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);
    // selecting database
    mysql_select_db(DB_DATABASE);

    // return database handler
    return $con;
}

// Closing database connection
function close()
{
    mysql_close();
}

function isUserExisted($table_name, $username, $password)
{
    $result = mysql_query("SELECT * from $table_name WHERE username = '$username' and password = '$password';");
    $no_of_rows = mysql_num_rows($result);
    if ($no_of_rows > 0) {
        // user existed
        return true;
    } else {
        // user not existed
        return false;
    }
}

function getTableData($table_name)
{
    $q = "SELECT * FROM " . $table_name . ";";
    $rs = mysql_query($q) or die(mysql_error());

    return $rs;
}

function isDataPresent($table_name, $query)
{
    $rs = mysql_query("SELECT * FROM $table_name " . $query);
    $no_of_rows = mysql_num_rows($rs) or die(mysql_error());
    if ($no_of_rows > 0) {
        // table existed
        return true;
    } else {
        // user not existed
        return false;
    }
}


function insert_Record($table_name, $col_name, $col_value, $num_of_records)
{
    $COLUMN_NAME = "";
    $string_EMPTY = "";
    $sql = mysql_query("SELECT COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME  = '$table_name' and COLUMN_NAME!='ID'") or die("<tt>problem with $sql : " . mysql_error() . "</tt>\n");
    $space = '';
    $num = mysql_num_rows($sql);
    while ($field = mysql_fetch_array($sql)) {
        $fieldname = explode('**', $col_name);
        $value = explode('**', $col_value);
        $field_name = $field['COLUMN_NAME'];
        if ($field['DATA_TYPE'] == 'char') {
            $empty_string = "' '";
        } elseif ($field['DATA_TYPE'] == 'datetime' || $field['DATA_TYPE'] == 'date') {
            $empty_string = "'1900-01-01 00:00:00.000'";
        } elseif ($field['DATA_TYPE'] == 'decimal') {
            $empty_string = "'0'";
        } elseif ($field['DATA_TYPE'] == 'text') {
            $empty_string = "' '";
        }
        for ($i = 0; $i < $num_of_records; $i++) {
            if (trim($field['COLUMN_NAME']) == $fieldname[$i]) {
                $field_name = $field['COLUMN_NAME'];
                $empty_string = "'" . $value[$i] . "'";
                break;
            }
        }

        $field_NM = $space . $field_name;
        $field_STR = $space . $empty_string;
        $space = ',';

        $COLUMN_NAME .= $field_NM;
        $string_EMPTY .= $field_STR;
    }

    //$sql =
    mysql_query("insert into $table_name ($COLUMN_NAME) VALUES ($string_EMPTY)");
    //return ($sql);
}


function showAlert($title, $msg, $btn)
{
    ?>
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo $title; ?></h4>
                </div>
                <div class="modal-body">
                    <p><?php echo $msg; ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $btn; ?></button>
                </div>
            </div>

        </div>
    </div>
    <script>$('#myModal').modal('show');</script><?php
}

function redirect($page)
{
    echo "<script>location.href='$page';</script>";
}

?>