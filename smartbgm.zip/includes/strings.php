<?php
/**
 * Created by PhpStorm.
 * User: Dalpat Singh Purohit
 * Date: 13-03-2016
 * Time: 11:01 00 PM
 */
$WEBSITE_NAME="Smart BGM";
$TAGLINE="";

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "smartbgm");


?>