<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>

    <title>Public Forum</title>

    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<!-- Navigation -->
<?php include_once "navbar.php"; ?>
<div class="">
    <div class="container">
        <!-- FlexSlider -->
    </div>

</div>
<br/>
<!-- end of Navigation -->

<!-- Main Content Area -->
<div class="OurLove-section">
    <div class="container">
        <h2>Smart Belagavi</h2>

        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <img src="images/banner2.jpg" class="img-responsive img-circle"/>
            </div>
            <div class="col-md-7 OurLove-grid1">
                <h4>Member Log in</h4>
                <hr/>
                <form class="form-horizontal" role="form" method="post" action="">
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="email">Username</label>

                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="username" name="username"
                                   placeholder="Enter Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="pwd">Password:</label>

                        <div class="col-sm-10">
                            <input type="password" class="form-control" name="password" id="password"
                                   placeholder="Enter password">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn  bg-primary" name="login" value="Log in"/>
                        </div>
                    </div>
                </form>
                <?php
                if (isset($_POST['login'])) {
                    include_once "includes/database_function.php";
                    connect();

                    $username = $_POST['username'];
                    $password = $_POST['password'];

                    if (isUserExisted("users", $username, $password)) {
                        $_SESSION['user'] = $username;
                        echo '<script>location.href="users/homepage.php";</script>';
                    } else {
                        echo "Invaild Username / Password ";
                    }
                }
                ?>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- End of Main Content Area -->
<br/>

<div class="indicate">
    <div class="container">
        <div class="indicate-grids">
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Belagavi, Karnataka India</p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>Telephone : +91 831 321 654
                </p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Email : <a
                        href=""> info@smartBelagavi.com</a></p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-send" aria-hidden="true"></span>FAX : +91 831 123 456</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer-section">
    <div class="container">
        <div class="footer-top">
            <p> &copy; 2016 Smart Belagavi . All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                    href="http://jainbgm.in"> JCE</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>
