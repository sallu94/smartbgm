<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <div class="container text-center col-md-8">
        <div class="list-group">
            <?php
            include_once "../includes/database_function.php";
            connect();

            $leader_id = $_GET['id'];
            $rs = getTableData("leader WHERE id = '$leader_id'");
            $leader = mysql_fetch_array($rs);
            ?>
            <h2 class="list-group-item list-group-item-info">
                <?php echo $leader['full_name']; ?>
            </h2>

            <?php
            $leader_name = $leader['username'];
            $rs = getTableData("area WHERE leader = '$leader_name'");
            $l_area = mysql_fetch_array($rs);

            ?>
            <span class="list-group-item text-left">Area - <?php echo $l_area['area_name']; ?></span>
            <span class="list-group-item text-left">Location - <?php echo $l_area['location']; ?></span>
                <span class="list-group-item list-group-item-text">
                <form action="" method="post" class="form-inline">
                    <?php

                    $ql = "SELECT * FROM leader_vote WHERE leader_id = '$leader_id' AND user_vote = 'yes';";
                    $get_votes = mysql_query($ql) or die(mysql_error());
                    $vote = mysql_num_rows($get_votes);

                    ?>
                    <span class="label label-success"><?php echo "" . $vote; ?></span>

                    <?php
                    $user = $_SESSION['user'];
                    $q2 = mysql_query("SELECT * FROM leader_vote WHERE leader_id = '$leader_id' AND user =
                    '$user';");
                    $is_voted = mysql_num_rows($q2);

                    if ($is_voted == 0) {
                        ?>
                        <button class="btn btn-info" name="like">
                            + <span class="glyphicon glyphicon-thumbs-up"></span>
                        </button>
                    <?php } else { ?>
                        <button class="btn btn-danger" name="like">
                            <big>- <span class="glyphicon glyphicon-thumbs-up"></span></big>
                        </button>
                    <?php } ?>


                    <input type="text" name="user_comment" class="form-control" placeholder="Write A Review"/>

                    <button class="btn btn-success" name="comment">
                        <span class="glyphicon glyphicon-upload"></span>
                    </button>
                </form>
                    <?php
                    if (isset($_POST['comment'])) {
                        include_once "../includes/database_function.php";
                        connect();

                        $leader_id = $_GET['id'];
                        $user = $_SESSION['user'];
                        $comment = $_POST['user_comment'];

                        include_once "../includes/badwords.php";
                        $badword = new badword();
                        $good_review = $badword->word_fliter("$comment");

                        $fieldNAME = (leader_id . '**' . user . '**' . review);
                        $value = ($leader_id . '**' . $user . '**' . $good_review);
                        $count = count(explode('**', $value));
                        insert_Record("leader_review", $fieldNAME, $value, $count);
                        redirect("view_leaders_details.php?id=$leader_id");
                    }

                    if (isset($_POST['like'])) {
                        $user = $_SESSION['user'];
                        $leader_id = $_GET['id'];

                        $q = mysql_query("SELECT * FROM leader_vote WHERE leader_id = '$leader_id' AND user =
                        '$user';");
                        $is_voted = mysql_num_rows($q);

                        if ($is_voted == 0) {
                            $vote = "yes";

                            $insert = "INSERT INTO leader_vote VALUES ('','$leader_id','$user','$vote');";
                            mysql_query($insert) or die(mysql_error());
                            redirect("view_leaders_details.php?id=$leader_id");
                        } else {
                            $remove = "DELETE FROM leader_vote WHERE user = '$user' AND leader_id = '$leader_id';";
                            mysql_query($remove) or die(mysql_error());
                            redirect("view_leaders_details.php?id=$leader_id");
                        }

                    }

                    ?>
                    </span>
        </div>

        <?php
        include_once "../includes/database_function.php";
        connect();
        $leader_id = $_GET['id'];
        $com = getTableData("leader_review WHERE leader_id = '$leader_id'");
        while ($display = mysql_fetch_array($com)) {
            ?>
            <p class="list-group-item list-group-item-warning text-left">
                <span class="label label-success"><?php echo $display['user']; ?></span>
                -
                <span class="text-primary"><?php echo $display['review']; ?></span>
            </p>
            <?php
        }
        ?>

    </div>
</div>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>