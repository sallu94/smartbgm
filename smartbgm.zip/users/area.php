<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart Belagavi</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <div class="container">
        <div class="container col-md-8 text-center">

            <div class="list-group">
                <h1><span class="list-group-item list-group-item-info">Choose one Region</span></h1>
                <a class="list-group-item"
                   href="post_queries.php?id=north">
                    <h1 class="img-circle">North<span class="glyphicon glyphicon-arrow-up"></span></h1>
                </a>
                <a class="list-group-item"
                   href="post_queries.php?id=south">
                    <h1 class="img-circle">South<span class="glyphicon glyphicon-arrow-down"></span></h1>
                </a>
                </a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include_once("../includes/footer.php"); ?>
</body>
</html>