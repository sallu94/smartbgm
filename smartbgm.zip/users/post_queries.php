<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <label class="label label-primary h3">Feel free to submit problems in your area :)</label>

    <ul class="list-group col-md-8 text-center">
        <li class="list-group-item">
            <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
                <?php
                if (isset($_GET['id'])) {
                    $area = $_GET['id'];
                    $_SESSION['user'];
                    ?>
                    <select name="user_area" class="form-control" required>
                        <option value="">Select Area</option>
                        <?php
                        include_once "../includes/database_function.php";
                        connect();
                        $res = getTableData("area WHERE location = '$area'");
                        while ($ar = mysql_fetch_array($res)) { ?>
                            <option value="<?php echo $ar['area_name']; ?>"><?php echo $ar['area_name']; ?></option>
                        <?php } ?>
                    </select><br/>
                <?php } ?>
                <input type="text" name="title" placeholder="Title" class="form-control" required/><br/>
                <textarea class="form-control" placeholder="Problem Description" name="problem_desc"
                          required></textarea><br/>
                <input type="file" name="imgfile" class="btn btn-default" required/><br/>
                <input type="submit" value="Submit" class="btn btn-primary" name="ask"/><br/>
            </form>
            <?php
            if (isset($_POST['ask'])) {
                include_once "../includes/database_function.php";
                connect();

                $uploadDir = 'users_images/';

                $file_name = $_FILES['imgfile']['name'];
                $file_size = $_FILES['imgfile']['size'];
                $file_tmp = $_FILES['imgfile']['tmp_name'];
                $file_type = $_FILES['imgfile']['type'];
                $file_ext = strtolower(end(explode('.', $_FILES['imgfile']['name'])));

                $file_path = $uploadDir . $file_name;

                $db_path = "users_images/" . $file_name;
                if (file_exists($uploadDir . $file_name)) {
                    echo '<script>alert("File Already Exist. Change file name and try again"); </script>';
                } else {
                    if ($file_size < 500000 && $file_size > 0) {

                        move_uploaded_file($file_tmp, $file_path);


                        $title = $_POST['title'];
                        $problem_desc = $_POST['problem_desc'];
                        $user_area = $_POST['user_area'];
                        $user = $_SESSION['user'];

                        $fieldNAME = (title . '**' . description . '**' . area . '**' . user . '**' . status . '**' . img_path);
                        $value = ($title . '**' . $problem_desc . '**' . $user_area . '**' . $user . '**' . 'pending'
                            . '**' . $db_path);
                        $count = count(explode('**', $value));
                        insert_Record('problem', $fieldNAME, $value, $count);
                        showAlert("Smart Belagavi", "Problem is reported successfully", "Okay");
                    }
                }
            }

            ?>
        </li>
    </ul>

</div>


<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>