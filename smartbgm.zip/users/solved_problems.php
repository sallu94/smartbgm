<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br />
<div class="container">
<?php include_once "sidebar.php"; ?>

<div class="container text-center col-md-8">
        <center>
            <table class="table-responsive table">
                <caption class="label label-primary h3">All Solved Problems</caption>
                <tr class="h3 bg-primary">
                    <th>Problem Title</th>
                    <th>Description</th>
                    <th>Raised By</th>
                    <th>Status</th>
                </tr>

                <?php

                include_once "../includes/database_function.php";
                connect();

                $user = $_SESSION['user'];

                $rs = getTableData("problem WHERE status = 'completed'");
                while ($data = mysql_fetch_array($rs)) {

                    ?>
                    <tr>
                        <td>
                        <span class="h4" style="color: #301b22">
                            <a href="view_comments.php?id=<?php echo $data['id']; ?>">
                                <?php echo $data['title']; ?>
                            </a>
                        </span>
                        </td>
                        <td>
                            <span style="color: #03bcfd;"><?php echo $data['description']; ?></span>
                        </td>
                        <td>
                            <span style="color: #03bcfd;"><?php echo $data['user']; ?></span>
                        </td>
                        <td>
                            <span style="color: #03bcfd;"><?php echo $data['status']; ?></span>
                        </td>
                    </tr>

                    <?php
                }
                ?>
                <tr class="bg-primary">
                    <td colspan="4">That is all</td>
                </tr>
            </table>
        </center>
    </div>
</div>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>