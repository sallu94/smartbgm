<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


    <!-- Pie Chart Imports -->
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <style type="text/css">
        ${demo.css}
    </style>
    <script type="text/javascript">
        $(function () {
            $(document).ready(function () {
                // Build the chart
                $('#pie_chart').highcharts({
                    chart: {
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        type: 'pie'
                    },
                    title: {
                        text: 'Problem Status Chart for Different Areas'
                    },
                    tooltip: {
                        pointFormat: '{series.name}: <b>{point.percentage:0.0f}%</b>'
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: false,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: false
                            },
                            showInLegend: false
                        }
                    },
                    series: [{
                        name: 'Status',
                        colorByPoint: true,
                        data: [
                            <?php
                            include_once "../includes/database_function.php";
                            connect();
                            $result = mysql_query("SELECT * FROM problem");
                            while ($row = mysql_fetch_array($result)) { ?>

                            {name: '<?php echo $row['area']; ?>', y: <?php echo $row['id']; ?>},

                            <?php } ?>
                        ]
                    }]
                });
            });
        });
    </script>

</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>
    <div class="container">
        <ul class="list-group col-md-8 text-center">
            <li class="list-group-item list-group-item-success">Dashboard</li>
            <li class="list-group-item">
                <a href="area.php">
                    <p>Add New Problem here</p>
                </a>
            </li>
            <li class="list-group-item">
                <a href="view_my_problems.php">
                    <p>View Problem status.</p>
                </a>
            </li>
            <li class="list-group-item">
                <a href="solved_problems.php">
                    <p>Resolved issues</p>
                </a>
            </li>
            <li class="list-group-item">
                <a href="view_all_problems.php">All reported Problems</a>
            </li>
            <li class="list-group-item">
                <a href="view_leaders.php">Leaders</a>
            </li>
        </ul>
        <!-- Pie Chart -->
        <ul class="list-group col-md-8 text-center">
            <li class="list-group-item">
                <div>
                    <script src="../js/highcharts.js"></script>
                    <script src="../js/exporting.js"></script>
                    <div id="pie_chart" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>
                </div>
            </li>
        </ul>
    </div>
</div>

<br/>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>