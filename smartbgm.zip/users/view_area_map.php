<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>
    <div class="container">
        <ul class="list-group col-md-8 text-center">

            <?php
            include_once "../includes/database_function.php";
            connect();

            $area_id = $_GET['id'];

            $rs = getTableData("area WHERE id = '$area_id'");
            $c = 1;
            $area = mysql_fetch_array($rs)
                ?>
            <li class="list-group-item list-group-item-success"><?php echo $area['area_name']; ?></li>
                <li class="list-group-item text-left">
                    <h3>Leader - <?php echo $area['leader']; ?> </h3>
                    <hr />
                    <iframe
                        src="<?php echo $area['map_url']; ?>"
                        width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                </li>
        </ul>
    </div>
</div>

<br/>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>