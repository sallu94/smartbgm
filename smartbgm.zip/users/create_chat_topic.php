<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>
    <div class="container">
        <ul class="list-group col-md-8 text-center">
            <li class="list-group-item list-group-item-success">Discussion Home</li>
            <li class="list-group-item text-left text-center">
                <form method="post" action="" >
                    <input type="text" placeholder="Topic Title" class="form-control" name="topic_title"/><br />
                    <textarea name="topic_desc" cols="30" rows="10" placeholder="Detailed Description about topic goes here ..." class="form-control"></textarea><br />
                    <button class="btn btn-success" name="create_topic">Create</button>
                </form>
                <?php
                if (isset($_POST['create_topic'])) {
                    include_once "../includes/database_function.php";
                    connect();

                    $topic = mysql_escape_string($_POST['topic_title']);
                    $topic_desc = mysql_escape_string($_POST['topic_desc']);
                    $user = $_SESSION['user'];

                    $topic_q = "INSERT INTO chat_topics VALUES ('','$topic','$topic_desc','$user');";
                    mysql_query($topic_q) or die(mysql_error());

                    echo "<br /><span class='label label-success'>You have created the chat topic.</span>";
                }

                ?>
            </li>
        </ul>
    </div>
</div>

<br/>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>