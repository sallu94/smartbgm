<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>
    <div class="container">
        <ul class="list-group col-md-8 text-center">
            <li class="list-group-item list-group-item-success">Locate Area on Google Map</li>
            <?php
            include_once "../includes/database_function.php";
            connect();

            $rs = getTableData("area");
            $c = 1;
            while ($area = mysql_fetch_array($rs)) {
            ?>
            <li class="list-group-item text-left">
                <a href="view_area_map.php?id=<?php echo $area['id']; ?>">
                    <p><?php echo $c++.". ".$area['area_name']." (".$area['location'].")"; ?></p>
                </a>
            </li>
            <?php } ?>
        </ul>
    </div>
</div>

<br/>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>