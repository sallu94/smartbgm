<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <div class="container text-center col-md-8">
        <div class="list-group">
            <?php
            include_once "../includes/database_function.php";
            connect();

            $problem_id = $_GET['id'];
            $rs = getTableData("problem WHERE id = '$problem_id'");
            $data = mysql_fetch_array($rs);
            ?>
            <h2 class="list-group-item list-group-item-info">
                <?php echo $data['title']; ?>
            </h2>
            <div class="progress">
                <div class="progress-bar progress-bar-info" role="progressbar"
                     aria-valuemin="0" aria-valuemax="100"
                     style="width:<?php echo $data['progress'] . '%'; ?>">
                    <?php echo $data['progress'] . '%'; ?>
                </div>
            </div>
                <span class="gallery-grd img-thumbnail">
                    <img src="<?php echo $data['img_path']; ?>" class="img-responsive small"/>
                </span>

            <p class="list-group-item list-group-item-text">
                <?php echo $data['description']; ?>
            </p>
                <span class="list-group-item list-group-item-text">
                <form action="" method="post" class="form-inline">
                    <?php
                    $ql = "SELECT * FROM comment_likes WHERE problem_id = '$problem_id' AND user_like = 'yes';";
                    $get_likes = mysql_query($ql) or die(mysql_error());
                    $like = mysql_num_rows($get_likes);

                    ?>
                    <span class="label label-success"><?php echo "" . $like; ?></span>

                    <?php
                    $user = $_SESSION['user'];
                    $q2 = mysql_query("SELECT * FROM comment_likes WHERE problem_id = '$problem_id' AND user =
                    '$user';");
                    $is_liked = mysql_num_rows($q2);

                    if ($is_liked == 0) {
                        ?>
                        <button class="btn btn-info" name="like">
                            <span class="glyphicon glyphicon-thumbs-up"></span>
                        </button>
                    <?php } else { ?>
                        <button class="btn btn-danger" name="like">
                            <span class="glyphicon glyphicon-thumbs-up"></span>
                        </button>
                    <?php } ?>


                    <input type="text" name="user_comment" class="form-control" placeholder="Write Comment here ..."/>

                    <button class="btn btn-success" name="comment">
                        <span class="glyphicon glyphicon-upload"></span>
                    </button>
                </form>
                    <?php
                    if (isset($_POST['comment'])) {
                        include_once "../includes/database_function.php";
                        connect();

                        $problem_id = $_GET['id'];
                        $user = $_SESSION['user'];
                        $comment = $_POST['user_comment'];

                        include_once "../includes/badwords.php";
                        $badword = new badword();
                        $good_comment = $badword->word_fliter("$comment");

                        $fieldNAME = (problem_id . '**' . user . '**' . comment);
                        $value = ($problem_id . '**' . $user . '**' . $good_comment);
                        $count = count(explode('**', $value));
                        insert_Record("problem_comments", $fieldNAME, $value, $count);
                        showAlert("Smart BGM", "You commented on the post", "Close");
                    }

                    if (isset($_POST['like'])) {
                        $user = $_SESSION['user'];
                        $problem_id = $_GET['id'];

                        $q = mysql_query("SELECT * FROM comment_likes WHERE problem_id = '$problem_id' AND user = '$user';");
                        $is_liked = mysql_num_rows($q);

                        if ($is_liked == 0) {
                            $like = "yes";

                            $insert = "INSERT INTO comment_likes VALUES ('','$problem_id','$user','$like');";
                            mysql_query($insert) or die(mysql_error());
                            redirect("view_comments.php?id=$problem_id");
                        } else {
                            $remove = "DELETE FROM comment_likes WHERE user = '$user' AND problem_id = '$problem_id';";
                            mysql_query($remove) or die(mysql_error());
                            redirect("view_comments.php?id=$problem_id");
                        }

                    }

                    ?>
                    </span>
        </div>

        <?php
        include_once "../includes/database_function.php";
        connect();
        $problem_id = $_GET['id'];
        $com = getTableData("problem_comments WHERE problem_id = '$problem_id'");
        while ($display = mysql_fetch_array($com)) {
            ?>
            <p class="list-group-item list-group-item-warning text-left">
                <span class="label label-success"><?php echo $display['user']; ?></span>
                -
                <span class="text-primary"><?php echo $display['comment']; ?></span>
            </p>
            <?php
        }
        ?>

    </div>
</div>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>