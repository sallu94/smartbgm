<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <div class="container text-center col-md-8">
        <div class="list-group">
            <?php
            include_once "../includes/database_function.php";
            connect();

            $topic_id = $_GET['id'];
            $rs = getTableData("chat_topics WHERE id = '$topic_id'");
            $data = mysql_fetch_array($rs);
            ?>
            <h2 class="list-group-item list-group-item-info">
                <?php echo $data['topic_title']; ?>
            </h2>

            <p class="list-group-item list-group-item-text">
                <?php echo $data['topic_desc']; ?>
            </p>
                <span class="list-group-item list-group-item-text">
                <form action="" method="post" class="form-inline">

                    <input type="text" name="user_comment" class="form-control" placeholder="What would you say about
                     this?"/>
                    <button class="btn btn-success" name="comment">
                        <span class="glyphicon glyphicon-upload"></span>
                    </button>
                </form>
                    <?php
                    if (isset($_POST['comment'])) {
                        include_once "../includes/database_function.php";
                        connect();

                        $topic_id = $_GET['id'];
                        $user = $_SESSION['user'];
                        $comment = $_POST['user_comment'];

                        include_once "../includes/badwords.php";
                        $badword = new badword();
                        $good_comment = $badword->word_fliter("$comment");

                        $fieldNAME = (topic_id . '**' . user . '**' . comment);
                        $value = ($topic_id . '**' . $user . '**' . $good_comment);
                        $count = count(explode('**', $value));
                        insert_Record("chat_discussion", $fieldNAME, $value, $count);
                        redirect("discuss_chat_topic.php?id=$topic_id");
                    }

                    ?>
                    </span>
        </div>

        <?php
        include_once "../includes/database_function.php";
        connect();
        $topic_id = $_GET['id'];
        $com = getTableData("chat_discussion WHERE topic_id = '$topic_id'");
        while ($display = mysql_fetch_array($com)) {
            ?>
            <p class="list-group-item list-group-item-warning text-left">
                <span class="label label-success"><?php echo $display['user']; ?></span>
                -
                <span class="text-primary"><?php echo $display['comment']; ?></span>
            </p>
            <?php
        }
        ?>

    </div>
</div>

<!-- Footer -->
<?php include_once("user_footer.php"); ?>
</body>
</html>