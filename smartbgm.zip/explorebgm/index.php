<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">
</head>
<body>

<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>
    <div class="container">
        <ul class="list-group col-md-8 text-center">
            <li class="list-group-item list-group-item-info"><h2>Explore Belgaum at a Glance</h2></li>
            <li class="list-group-item">
                <a href="">
                    <p>Education</p>

                    <h1 class="img-circle"><span class="glyphicon glyphicon-book" width="150"
                                                 height=""></span>
                    </h1>
                </a>
            </li>
            <li class="list-group-item list-group-item-heading">
                <a href="">
                    <p>Places to visit</p>
                    <h1 class="img-circle"><span class="glyphicon glyphicon-picture"></span>
                    </h1>
                </a>
            </li>
            <li class="list-group-item list-group-item-heading">
                <a href="">
                    <p>Food and Restaurant</p>

                    <h1 class="img-circle"><span class="glyphicon glyphicon-question-sign" width="150"
                                                 height=""></span>
                    </h1>
                </a>
            </li>
        </ul>
    </div>
</div>
<br/>
<!-- Footer -->
<?php include_once("../includes/footer.php"); ?>
</body>
</html>
