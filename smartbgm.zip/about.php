<?php session_start(); ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Public Forum</title>

    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>


    <link href="css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<!-- Navigation -->
<?php include_once "navbar.php"; ?>
<div class="">
    <div class="container">
        <!-- FlexSlider -->
    </div>

</div>
<!-- end of Navigation -->

<div class="OurLove-section">
    <div class="container">
        <h2>Welcome to SmartBGM family</h2>
        <div class="OurLove-grids">
            <div class="col-md-2 OurLove-grid">
                
            </div>

            <div class="col-md-8 OurLove-grid1">
                <div class="panel panel-default">
                    <div class="text-success h4">What are we</div>
                    <div class="panel-body">
                        <img src="images/banner2.jpg" class="img-responsive img-circle"/>
                        <span class="text-success h4">Introduction</span> <br/>
                       Belgaum, officially known as Belagavi (earlier known "Venugrama" or the "Bamboo Village"[4]) is a city in the Indian state of Karnataka. It is the administrative headquarters of the eponymous Belgaum division and Belgaum district. The Government of Karnataka has proposed making Belgaum the second capital of Karnataka, hence a second state administrative building Suvarna Vidhana Soudha was inaugurated on 11 October 2012<br><br>
					   Belgaum was chosen as the venue of the 39th session of the Indian National Congress in December 1924 under the presidency of Mahatma Gandhiji. The city served as a major military installation for the British Raj, primarily due to its proximity to Goa, which was then a Portuguese territory. Once the British left India, the Indian government continued and still continues to have armed forces installations in Belgaum. In 1961, the Indian government, under Prime Minister Jawaharlal Nehru, used forces from Belgaum to end Portuguese rule of Goa.<br><br>
					   Belgaum is located at 15.87°N 74.5°E.[12] It has an average elevation of 751 metres (2463 feet). The city is in the northwestern parts of Karnataka and lies at the border of two states, Maharashtra and Goa on the western ghats (50 km from the Goa state border). It is one of the oldest towns in the state, lying 502 km from Bangalore, 515 km from Hyderabad ,500 km from Mumbai , 75 km from Dharwad and 95 km from Hubli. The district comprises 1278 villages with an area of 13,415 km² and a population of around 4.8 million according to the census of 2011. Belgaum district is the biggest district of Karnataka. Situated near the foothills of the Sahyadri mountain range (Western Ghats) at an altitude of about 779 m, 100 km from the Arabian Sea with the Markandeya river flowing nearby, Belgaum exhibits swift and kaleidoscopic changes in topography, vegetation and climate.<br><br>
					   Belgaum is 502 km from Bangalore and 154 km from Panaji. Nestled in the foothills of the Western Ghats, it enjoys a cool, salubrious climate and is surrounded by natural beauty in the form of rivers, hills and dense evergreen forests. In the vicinity there are popular tourists places like Amboli, Sindhudurg district and Jamboti.<br><br>

A wide variety of historical sites, temples and churches exist in and around the city, most notably the Kamala Basti fort, Kapileshwar temple (South Kashi), the hills of Vaijyanath, Ramtirth waterfalls, Revan Siddeshwr Temple at Hunshevari in the valleys of Kakati, Siddeshwar Temple in Kanbargi, the aerodrome at Sambra,kittur fort,Suvarna soudha..<br>
                    </div>
                    <div class="panel-body">
                        <span class="text-success h4">Testimonial</span> <br/>
                        <?php include_once "testimonial.php"; ?>
                    </div>
					<div>
						&nbsp&nbsp&nbsp&nbsp&nbsp<span class="text-success h4">All about Belagavi</span> <br/>&nbsp&nbsp&nbsp&nbsp&nbsp<a href="http://allaboutbelgaum.com/">News all about Belagavi</a>
					</div>
                    <div class="panel-body">
                        <span class="text-success h4">Our Mission</span> <br/>
                       TO Build Belagavi City into a New and Smart City
                    </div>
                    <div class="panel-body">
                        <span class="text-success h4">Our Vision</span> <br/>
                        To have a smart city
                    </div>
                </div>
            </div>



            <div class="clearfix"></div>
        </div>
    </div>
</div>

<div class="indicate">
    <div class="container">
        <div class="indicate-grids">
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Belgaum, Karnataka India</p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>Telephone : +91 831 321 654
                </p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>Email : <a
                        href=""> info@smartbelgaum.com</a></p>
            </div>
            <div class="col-md-3 indicate-grid">
                <p><span class="glyphicon glyphicon-send" aria-hidden="true"></span>FAX : +91 831 123 456</p>
            </div>
            <div class="clearfix">
			</div>
        </div>
    </div>
</div>
<!-- Footer -->
<div class="footer-section">
    <div class="container">
        <div class="footer-top">
            <p> &copy; 2016 Smart Belgaum . All Rights Reserved | Developed by <span class="glyphicon
            glyphicon-hand-right"></span><a
                    href="http://jainbgm.in"> JCE</a>
            </p>
        </div>
    </div>
</div>
</body>
</html>