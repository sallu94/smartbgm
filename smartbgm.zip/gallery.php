<!DOCTYPE HTML>
<html>
<head>
    <title>SmartBGM</title>
    <link href="./css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="./css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);
        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <script src="./js/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="./css/flexslider.css" type="text/css" media="screen"/>
    <script src="./js/bootstrap.js"></script>
    <link rel="stylesheet" href="./css/swipebox.css">
    <script src="./js/jquery.swipebox.min.js"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            $(".swipebox").swipebox();
        });
    </script>


</head>
<body>
<!--header-->
<?php include_once "navbar.php"; ?> <br/>

<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <h2>Smart Belagavi Gallery</h2>
                <hr/>
                <?php
                include_once "./includes/database_function.php";
                connect();

                $rs = getTableData("gallery");
                $count = 1;
                while ($gallery = mysql_fetch_array($rs)) {

                    ?>
                    <div class="gallery-grids">
                        <div class="col-md-3 gallery-grid">
                            <div class="gallery-grd">

                                <a class="swipebox" href="<?php echo './' . $gallery['img_path']; ?>">
                                    <span class="label label-success"><?php echo $gallery['img_name']; ?></span> <br
                                        /><br/>
                                    <img src="<?php echo './' . $gallery['img_path']; ?>"
                                         class="img-circle img-responsive"/>
                                    <br/>
                                    <span class="label label-info"><?php echo $gallery['img_desc']; ?></span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <?php
                } ?>

            </div>
        </div>

    </div>

</div>

<!-- Footer -->
<?php include_once "includes/footer.php"; ?>
</body>
</html>