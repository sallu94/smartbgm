<?php
//Start session
session_start();

//Unset the variables stored in session (also session_destroy() can be used )
unset($_SESSION['admin']);

?>
<script>
    window.location = "./index.php";
</script>