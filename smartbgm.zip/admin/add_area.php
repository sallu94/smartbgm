<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>

                <div class="container">
                    <div class="container col-md-8 text-center">
                        <!-- Add area -->
                        <div class="row">
                            <div class="col-md-12">
                                <section class="panel">
                                    <div class="panel-body">

                                        <form class="form-inline" role="form" action="" method="post">
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Area Name</label>
                                                <input type="text" name="area_name" class="form-control"
                                                       id="exampleInputPassword2"
                                                       placeholder="Area Name" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Select Leader</label>
                                                <select class="form-control" name="leader">
                                                    <?php
                                                    include_once "../includes/database_function.php";
                                                    connect();
                                                    $rs = getTableData("leader");
                                                    while ($l = mysql_fetch_array($rs)) {
                                                        ?>

                                                        <option
                                                            value="<?php echo $l['username']; ?>"><?php echo $l['full_name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Location</label>
                                                <select class="form-control" name="location">
                                                    <option value="north">North</option>
                                                    <option value="south">South</option>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Map Url</label>                       
                                            </div>
                                            <br/><br/>
                                            <button type="submit" class="btn btn-success" name="add_area">Add Area
                                            </button>
                                        </form>
                                    </div>
                                </section>
                            </div>
                            <?php
                            if (isset($_POST['add_area'])) {

                                $area_name = $_POST['area_name'];
                                $leader = $_POST['leader'];
                                $location = $_POST['location'];
                                $map_url = mysql_escape_string($_POST['map_url']);

                                $q = "INSERT INTO area VALUES ('','$area_name','$leader','$location','$map_url');";
                                mysql_query($q) or die(mysql_error());

                                showAlert("Smart Belagavi", "New Area Added Successfully", "Ok");
                            }
                            ?>
                        </div>
                        <!-- Available Area -->
                        <div class="row">
                            <div class="panel-body">
                                <table class="table table-bordered">
                                    <tr class="bg-primary">
                                        <th style="width: 10px">#</th>
                                        <th>Area</th>
                                        <th>Area Leader</th>
                                        <th>Location</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php
                                    include_once "../includes/database_function.php";
                                    connect();
                                    $rs = getTableData("area");
                                    $i = 1;
                                    while ($ar = mysql_fetch_array($rs)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $ar['area_name']; ?></td>
                                            <td><?php echo $ar['leader']; ?></td>
                                            <td><?php echo $ar['location']; ?></td>
                                            <td><a href="update_area.php?area_id=<?php echo $ar['id']; ?>" class="btn
                            btn-default"> Update </a></td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td colspan="5" class="bg-primary"></td>
                                    </tr>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>