<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>
                <div class="container">
                    <div class="container col-md-8 text-center">
                        <span class="list-group-item list-group-item-success">Add Leader</span><br/>
                        <table class="table table-responsive">
                            <form action="" method="post">
                                <tr>
                                    <td>Leader Name :</td>
                                    <td>
                                        <input type="text" name="full_name" class="form-control"
                                               placeholder="Full Name" required/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Leader Username :</td>
                                    <td>
                                        <input type="text" name="username" class="form-control"
                                               placeholder="Username ID" required/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Leader Password :</td>
                                    <td><input type="password" name="password" class="form-control"
                                               placeholder="Password"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="submit" name="add_leader" value="Add Leader"
                                               class="btn btn-success"/>
                                    </td>
                                </tr>
                            </form>
                        </table>
                        <?php
                        if (isset($_POST['add_leader'])) {
                            include_once "../includes/database_function.php";
                            connect();

                            $full_name = $_POST['full_name'];
                            $username = $_POST['username'];
                            $password = $_POST['password'];

                            $q = "INSERT INTO leader (full_name,username,password) VALUES ('$full_name','$username','$password');";
                            mysql_query($q) or die(mysql_error());
                            showAlert("Smart Belagavi", "Leader Added", "Ok");
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>