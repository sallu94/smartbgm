<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>

                <div class="container">
                    <div class="container col-md-8 text-center">
                        <!-- Add area -->
                        <div class="row">
                            <div class="col-md-12">
                                <section class="panel">
                                    <div class="panel-body">

                                        <form class="form-inline" role="form" action="" method="post">
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Ad Name</label>
                                                <input type="text" name="ad_title" class="form-control"
                                                       id="exampleInputPassword2"
                                                       placeholder="Ad Title" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="sr-only" for="exampleInputPassword2">Ad Name</label>
                                                <input type="text" name="ad_desc" class="form-control"
                                                       id="exampleInputPassword2"
                                                       placeholder="Ad Description" required>
                                            </div>
                                            <button type="submit" class="btn btn-success" name="add_ad">
                                                <span class="glyphicon glyphicon-plus"></span>
                                            </button>
                                        </form>
                                    </div>
                                </section>
                            </div>
                            <?php
                            if (isset($_POST['add_ad'])) {

                                include_once "../includes/database_function.php";
                                connect();

                                $ad_title = $_POST['ad_title'];
                                $ad_desc = $_POST['ad_desc'];

                                $q = "INSERT INTO ads VALUES ('','$ad_title','$ad_desc');";
                                mysql_query($q) or die(mysql_error());

                                showAlert("Success", "New Ad Added to database", "Ok");
                            }
                            ?>
                        </div>
                        <!-- Available Area -->
                        <div class="row">
                            <div class="panel-body">
                                <table class="table table-bordered">
                                    <tr class="bg-primary">
                                        <th style="width: 10px">#</th>
                                        <th>Ad Title</th>
                                        <th>Ad Description</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php
                                    include_once "../includes/database_function.php";
                                    connect();
                                    $rs = getTableData("ads");
                                    $i = 1;
                                    while ($ad = mysql_fetch_array($rs)) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $ad['ad_title']; ?></td>
                                            <td><?php echo $ad['ad_desc']; ?></td>
                                            <td><a href="update_ad.php?ad_id=<?php echo $ad['id']; ?>" class="btn
                            btn-default"> Update </a></td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td colspan="5" class="bg-primary"></td>
                                    </tr>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>