<?php session_start();
if (isset($_SESSION['admin'])) {
    echo '<script>window.location="./homepage.php";</script>';
} ?>
<!DOCTYPE html>
<html lang="eng">
<head>

    <title>Smart Belagavi</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">


</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<div class="OurLove-section">
    <div class="container">
        <h2>Smart Belagavi</h2>

        <div class="OurLove-grids">
            <div class="col-md-5 OurLove-grid">
                <img src="../images/g2.jpg" class="img-responsive img-circle"/>
            </div>
            <div class="col-md-7 OurLove-grid1">
                <h4>Admin Log in</h4>
                <hr/>
                <form class="form-horizontal" role="form" method="post" action="">
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="email">Username</label>

                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="username" name="username"
                                   placeholder="Enter Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="pwd">Password:</label>

                        <div class="col-sm-10">
                            <input type="password" class="form-control" name="password" id="password"
                                   placeholder="Enter password">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <input type="submit" class="btn  bg-primary" name="login" value="Log in"/>
                        </div>
                    </div>
                </form>
                <?php
                if (isset($_POST['login'])) {
                    include_once "../includes/database_function.php";
                    connect();

                    $username = $_POST['username'];
                    $password = $_POST['password'];

                    if (isUserExisted("admin", $username, $password)) {
                        $_SESSION['admin'] = $username;
                        echo '<script>location.href="homepage.php";</script>';
                    } else {
                        echo "Invalid Username / Password ";
                    }
                }
                ?>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<br/>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>
