<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>
                <div class="container">
                    <div class="container col-md-8 text-center">

                        <!-- Available Area -->
                        <div class="row">
                            <div class="panel-body">
                                <form action="" method="post">
                                    <table class="table table-bordered">
                                        <tr class="bg-primary">
                                            <th style="width: 10px">#</th>
                                            <th>Ad Title</th>
                                            <th>Ad Description</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php
                                        include_once "../includes/database_function.php";
                                        connect();

                                        $ad_id = $_GET['ad_id'];
                                        $rs = getTableData("ads WHERE id = '$ad_id'");
                                        $i = 1;
                                        while ($ad = mysql_fetch_array($rs)) {
                                            ?>
                                            <input type="hidden" value="<?php echo $ad_id; ?>" name="ad_id"/>
                                            <tr>
                                                <td><?php echo $i++; ?></td>
                                                <td><input type="text" value="<?php echo $ad['ad_title']; ?>"
                                                           name="ad_title"
                                                           class="form-control" required></td>
                                                <td><input type="text" value="<?php echo $ad['ad_desc']; ?>"
                                                           name="ad_desc"
                                                           class="form-control" required></td>

                                                <td>
                                                    <input type="submit" value="Update" class="btn btn-success"
                                                           name="update"/>
                                                    <input type="submit" value="Remove" class="btn btn-danger"
                                                           name="remove"/>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        <tr>
                                            <td colspan="5" class="bg-primary"></td>
                                        </tr>
                                    </table>
                                </form>
                                <?php
                                if (isset($_POST['update'])) {
                                    include_once "../includes/database_function.php";
                                    connect();

                                    $ad_id = $_POST['ad_id'];
                                    $ad_title = $_POST['ad_title'];
                                    $ad_desc = $_POST['ad_desc'];

                                    $u = "UPDATE ads SET ad_title='$ad_title', ad_desc='$ad_desc' WHERE id = '$ad_id';";
                                    mysql_query($u) or die(mysql_error());
                                    showAlert("Success", "Ad Updated Successfully", "Close");
                                }
                                ?>
                                <?php
                                if (isset($_POST['remove'])) {
                                    include_once "../includes/database_function.php";
                                    connect();

                                    $ad_id = $_POST['ad_id'];

                                    $u = "DELETE FROM ads WHERE id = '$ad_id';";
                                    mysql_query($u) or die(mysql_error());
                                    showAlert("Success", "Ad Removed Successfully", "Close");
                                }
                                ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>