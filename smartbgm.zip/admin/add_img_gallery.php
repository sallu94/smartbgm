<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">


    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>
                <div class="container">
                    <label class="label label-primary">Add new images to gallery</label>

                    <ul class="list-group col-md-8 text-center">
                        <li class="list-group-item">
                            <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
                                <input type="text" name="img_name" placeholder="Image Name" class="form-control"
                                       required/><br/>
                <textarea class="form-control" placeholder="Image Description" name="img_desc"
                          required></textarea><br/>
                                <input type="file" name="imgfile" class="btn btn-default" required/><br/>
                                <input type="submit" value="Submit" class="btn btn-primary" name="upload"/><br/>
                            </form>
                            <?php
                            if (isset($_POST['upload'])) {
                                include_once "../includes/database_function.php";
                                connect();

                                $uploadDir = '../gallery_img/';

                                $file_name = $_POST['img_name'];
                                $file_size = $_FILES['imgfile']['size'];
                                $file_tmp = $_FILES['imgfile']['tmp_name'];
                                $file_type = $_FILES['imgfile']['type'];
                                $file_ext = strtolower(end(explode('.', $_FILES['imgfile']['name'])));

                                $file_path = $uploadDir . $file_name . "." . $file_ext;

                                $db_path = "gallery_img/" . $file_name . "." . $file_ext;
                                if (file_exists($uploadDir . $file_name)) {
                                    echo '<script>alert("File Already Exist. Change file name and try again"); </script>';
                                } else {
                                    if ($file_size < 500000 && $file_size > 0) {

                                        move_uploaded_file($file_tmp, $file_path);

                                        $img_desc = $_POST['img_desc'];

                                        $fieldNAME = (img_path . '**' . img_name . '**' . img_desc);
                                        $value = ($db_path . '**' . $file_name . '**' . $img_desc);
                                        $count = count(explode('**', $value));
                                        insert_Record('gallery', $fieldNAME, $value, $count);
                                        showAlert("Success", "Image uploaded", "Okay");
                                    }
                                }
                            }

                            ?>
                        </li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</div>
<?php include_once("admin_footer.php"); ?>
</body>
</html>