<?php include_once "session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("../includes/strings.php"); ?>
<?php include_once("navbar.php"); ?>
<br/>

<div class="container">
    <?php include_once "sidebar.php"; ?>

    <div class="container">
        <div class="container col-md-8 text-center">

            <div class="list-group">
                <h1><span class="list-group-item list-group-item-info">Update Password</span></h1>
                <hr/>
                <form action="" method="post">
                    <input type="text" name="newusername" placeholder="New Username" class="form-control"/><br/>
                    <input type="password" name="newpassword" placeholder="New Password" class="form-control"/><br/>
                    <input type="submit" name="update" value="Update" class="btn btn-success"/>
                </form>
                <?php
                if (isset($_POST['update'])) {
                    include_once "../includes/database_function.php";
                    connect();

                    $old_username = $_SESSION['admin'];
                    $new_username = $_POST['newusername'];
                    $new_password = $_POST['newpassword'];

                    $uq = "UPDATE admin SET username = '$new_username', password = '$new_password' WHERE username = '$old_username';";
                    mysql_query($uq) or die(mysql_error());
                    echo '<script>alert("Updated Successfully. Please login again");</script>';
                    redirect("logout.php");
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include_once("admin_footer.php"); ?>
</body>
</html>