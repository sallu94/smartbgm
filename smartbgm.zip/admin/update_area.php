<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>


    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>
                <div class="container">
                    <div class="container col-md-8 text-center">

                        <!-- Available Area -->
                        <div class="row">
                            <div class="panel-body">
                                <form action="" method="post">
                                    <table class="table table-bordered">
                                        <tr class="bg-primary">
                                            <th style="width: 10px">#</th>
                                            <th>Area</th>
                                            <th>Area Leader</th>
                                            <th>Location</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php
                                        include_once "../includes/database_function.php";
                                        connect();

                                        $area_id = $_GET['area_id'];
                                        $rs = getTableData("area WHERE id = '$area_id'");
                                        $i = 1;
                                        while ($ar = mysql_fetch_array($rs)) {
                                            ?>
                                            <input type="hidden" value="<?php echo $area_id; ?>" name="area_id"/>
                                            <tr>
                                                <td><?php echo $i++; ?></td>
                                                <td><input type="text" value="<?php echo $ar['area_name']; ?>"
                                                           name="area_name"
                                                           class="form-control" required></td>
                                                <td>
                                                    <select class="form-control" name="leader" required>
                                                        <option value="">Choose Leader</option>
                                                        <?php
                                                        include_once "../includes/database_function.php";
                                                        connect();
                                                        $rs = getTableData("leader");
                                                        while ($l = mysql_fetch_array($rs)) {
                                                            ?>

                                                            <option
                                                                value="<?php echo $l['username']; ?>"><?php echo $l['full_name']; ?></option>
                                                        <?php } ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <select class="form-control" name="location" required>
                                                        <option value="">Choose Area</option>
                                                        <option value="north">North</option>
                                                        <option value="south">South</option>
                                                    </select>
                                                </td>
                                                <td><input type="submit" value="Update" class="btn btn-success"
                                                           name="update"/></td>
                                            </tr>
                                        <?php } ?>
                                        <tr>
                                            <td colspan="5" class="bg-primary"></td>
                                        </tr>
                                    </table>
                                </form>
                                <?php
                                if (isset($_POST['update'])) {
                                    include_once "../includes/database_function.php";
                                    connect();

                                    $area_id = $_POST['area_id'];
                                    $area_name = $_POST['area_name'];
                                    $leader = $_POST['leader'];
                                    $location = $_POST['location'];

                                    $u = "UPDATE area SET area_name='$area_name', leader='$leader', location='$location' WHERE id = '$area_id';";
                                    mysql_query($u) or die(mysql_error());
                                    showAlert("Smart BGM", "Area Updated Successfully", "Close");
                                }
                                ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>