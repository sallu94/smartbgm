<?php include_once "./session_authentication.php"; ?>
<!DOCTYPE html>
<html lang="eng">
<head>
    <title>Smart BGM</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen"/>
    <script src="../js/jquery-1.11.1.min.js"></script>
    <script src="../js/bootstrap.js"></script>

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link rel="icon" type="image/png" href="images/favicon.png"/>
    <meta name=viewport content="width=device-width, initial-scale=1">

</head>
<body>
<?php include_once("navbar.php"); ?>
<?php include_once("../includes/strings.php"); ?>
<div class="container">
    <div class="content">
        <div class="wedding-section">
            <div class="container">
                <?php include_once "sidebar.php"; ?>
                <div class="container">
                    <div class="container col-md-8 text-center">
                        <span
                            class="list-group-item list-group-item-success">Hello <?php echo $_SESSION['admin']; ?></span><br/>

                        <div class="row">
                            <div class="list-group-item">
                                <a href="add_leader.php" class="thumbnail">
                                    <p>Leader Section</p>

                                    <h1 class="img-circle"><span class="glyphicon glyphicon-user"></span></h1>
                                </a>
                            </div>

                            <div class="list-group-item">
                                <a href="add_area.php" class="thumbnail">
                                    <p>Area Section</p>

                                    <h1 class="img-circle"><span class="glyphicon glyphicon-zoom-in"></span></h1>
                                </a>
                            </div>
                            <div class="list-group-item">
                                <a href="gallery_section.php" class="thumbnail">
                                    <p>Gallery Section</p>

                                    <h1 class="img-circle"><span class="glyphicon glyphicon-picture"></span></h1>
                                </a>
                            </div>
                            <div class="list-group-item">
                                <a href="ad_section.php" class="thumbnail">
                                    <p>Ad Section</p>

                                    <h1 class="img-circle"><span class="glyphicon glyphicon-flash"></span></h1>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer -->
<?php include_once("admin_footer.php"); ?>
</body>
</html>